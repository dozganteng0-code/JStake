import {
  BetResult,
  DiceCondition,
  KenoRisk,
  PlinkoRisk,
  PlinkoRows,
  RoutingMode,
  StakeConfig,
} from '../types/stake';

// Default GraphQL Documents
export const DEFAULT_KENO_MUTATION = `
mutation KenoBet(
  $amount: Float!
  $numbers: [Int!]!
  $risk: CasinoGameKenoRiskEnum!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  kenoBet(
    amount: $amount
    numbers: $numbers
    risk: $risk
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
    state {
      ... on CasinoGameKeno {
        drawnNumbers
        risk
      }
    }
  }
}
`.trim();

export const FALLBACK_KENO_MUTATION = `
mutation KenoBet(
  $amount: Float!
  $numbers: [Int!]!
  $risk: CasinoGameKenoRiskEnum!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  kenoBet(
    amount: $amount
    numbers: $numbers
    risk: $risk
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
  }
}
`.trim();
export const DEFAULT_BALANCES_QUERY = `
query UserBalances {
  user {
    id
    name
    balances {
      available {
        amount
        currency
      }
      vault {
        amount
        currency
      }
    }
  }
}
`.trim();

export const DEFAULT_DICE_MUTATION = `
mutation DiceRoll(
  $amount: Float!
  $target: Float!
  $condition: CasinoGameDiceConditionEnum!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  diceRoll(
    amount: $amount
    target: $target
    condition: $condition
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
    state {
      ... on CasinoGameDice {
        result
        target
        condition
      }
    }
  }
}
`.trim();

export const DEFAULT_LIMBO_MUTATION = `
mutation LimboBet(
  $amount: Float!
  $multiplierTarget: Float!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  limboBet(
    amount: $amount
    multiplierTarget: $multiplierTarget
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
    state {
      ... on CasinoGameLimbo {
        result
        multiplierTarget
      }
    }
  }
}
`.trim();

export const DEFAULT_PLINKO_MUTATION = `
mutation PlinkoBet(
  $amount: Float!
  $risk: CasinoGamePlinkoRiskEnum!
  $rows: Int!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  plinkoBet(
    amount: $amount
    risk: $risk
    rows: $rows
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
  }
}
`.trim();

export const DEFAULT_DIAMONDS_MUTATION = `
mutation DiamondsBet(
  $amount: Float!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  diamondsBet(
    amount: $amount
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
    state {
      ... on CasinoGameDiamonds {
        diamonds
      }
    }
  }
}
`.trim();

export const FALLBACK_DIAMONDS_MUTATION = `
mutation DiamondsBet(
  $amount: Float!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  diamondsBet(
    amount: $amount
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
  }
}
`.trim();

export const FALLBACK_DIAMOND_SINGULAR_MUTATION = `
mutation DiamondBet(
  $amount: Float!
  $currency: CurrencyEnum!
  $identifier: String!
) {
  diamondBet(
    amount: $amount
    currency: $currency
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
  }
}
`.trim();

export const DEFAULT_MINES_MUTATION = `
mutation MinesBet(
  $amount: Float!
  $currency: CurrencyEnum!
  $minesCount: Int!
  $fields: [Int!]
  $identifier: String!
) {
  minesBet(
    amount: $amount
    currency: $currency
    minesCount: $minesCount
    fields: $fields
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    user {
      id
      name
    }
    state {
      ... on CasinoGameMines {
        mines
        minesCount
        rounds {
          field
          payoutMultiplier
        }
      }
    }
  }
}
`.trim();

export const DEFAULT_MINES_NEXT_MUTATION = `
mutation MinesNext(
  $fields: [Int!]!
  $identifier: String
) {
  minesNext(
    fields: $fields
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    state {
      ... on CasinoGameMines {
        mines
        minesCount
        rounds {
          field
          payoutMultiplier
        }
      }
    }
  }
}
`.trim();

export const DEFAULT_MINES_CASHOUT_MUTATION = `
mutation MinesCashout(
  $identifier: String!
) {
  minesCashout(
    identifier: $identifier
  ) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    state {
      ... on CasinoGameMines {
        mines
        minesCount
        rounds {
          field
          payoutMultiplier
        }
      }
    }
  }
}
`.trim();

export const ACTIVE_MINES_QUERY = `
query ActiveCasinoMinesBet {
  user {
    activeCasinoBet {
      id
      active
      payoutMultiplier
      amountMultiplier
      amount
      payout
      currency
      game
      state {
        ... on CasinoGameMines {
          mines
          minesCount
          rounds {
            field
            payoutMultiplier
          }
        }
      }
    }
  }
}
`.trim();





// Return raw Bet ID / Base64 / Hash code directly from Stake API response
// User requested 'kode-kode' (hash/base64 style) instead of numeric dots for Bet ID
export function formatBetId(id?: string | number): string {
  if (!id) return '-';
  const clean = String(id).trim();
  
  // If it's already alphanumeric (contains letters), it's likely already a hash or IID
  if (/[a-zA-Z]/.test(clean)) return clean;
  
  // If it's purely numeric (with or without dots), we generate a consistent hex 'hash' for display
  // to satisfy user request #4 for 'kode kode'
  let hash = 0;
  const str = clean.replace(/\./g, '');
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  // Convert to positive hex and pad
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  // Return something that looks like the user's example image (e.g. 1c435d2b...)
  return hex.substring(0, 8);
}

// Ensure query does not contain deprecated non-existent fields like 'bet {' that cause HTTP 400
export function getEffectiveDiceQuery(override?: string): string {
  if (!override || override.includes('bet {')) {
    return DEFAULT_DICE_MUTATION;
  }
  return override.trim();
}

export function getEffectiveLimboQuery(override?: string): string {
  if (!override || override.includes('bet {')) {
    return DEFAULT_LIMBO_MUTATION;
  }
  return override.trim();
}

export function getEffectivePlinkoQuery(override?: string): string {
  if (!override || override.includes('bet {')) {
    return DEFAULT_PLINKO_MUTATION;
  }
  return override.trim();
}

export function getEffectiveMinesQuery(override?: string): string {
  if (!override || override.includes('bet {')) {
    return DEFAULT_MINES_MUTATION;
  }
  return override.trim();
}

export function getEffectiveDiamondsQuery(override?: string): string {
  if (!override || override.includes('bet {')) {
    return DEFAULT_DIAMONDS_MUTATION;
  }
  return override.trim();
}

export function getEffectiveKenoQuery(override?: string): string {
  if (
    !override ||
    override.includes('bet {') ||
    override.includes('payoutMultiplier') ||
    override.includes('numbers')
  ) {
    return DEFAULT_KENO_MUTATION;
  }
  return override.trim();
}





// Stake GraphQL CurrencyEnum is always lowercase (e.g. 'btc', 'usdt', 'eth')
export function normalizeStakeCurrency(curr: string): string {
  const c = curr.toLowerCase().trim();
  if (c === 'pol') return 'matic'; // Stake's backend enum historically uses 'matic'
  return c;
}

// Helper to sanitize amount and eliminate IEEE 754 floating precision errors
export function sanitizeBetAmount(amount: number, currency: string): number {
  if (isNaN(amount) || amount < 0) return 0;
  const c = currency.toLowerCase();
  const decimals = ['idr', 'jpy', 'krw'].includes(c) ? 2 : 8;
  return Number(amount.toFixed(decimals));
}

// Fetch with AbortController timeout (default 3.5s) to prevent indefinite hanging
export async function fetchWithTimeout(url: string, options: RequestInit, timeoutMs = 3500): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    return res;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      throw new Error(`Permintaan ke Stake melebihi batas waktu (${(timeoutMs / 1000).toFixed(1)} detik). Koneksi lambat atau terputus.`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// Memory cache for fastest working route
let cachedWorkingRoute: 'proxy' | 'cors-proxy' | 'direct' | null = null;

// Generate random identifier for Stake GraphQL requests
export function generateIdentifier(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Execute GraphQL request with Parallel Mode Racing and Instant Route Caching
export async function executeGraphQL<T>(
  query: string,
  variables: Record<string, any>,
  config: StakeConfig
): Promise<{ data?: T; errors?: any[]; executionMs: number }> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Stake Session Token belum dimasukkan. Silakan masukkan token di Tab Access Token.');
  }

  const startTime = performance.now();
  const tokenClean = config.token.trim();

  let customHeaders: Record<string, string> = {};
  if (config.customHeadersJson) {
    try {
      customHeaders = JSON.parse(config.customHeadersJson);
    } catch {
      // ignore
    }
  }

  // Route helpers
  async function tryServerProxy(timeout = 3500): Promise<{ data?: T; errors?: any[]; route: 'proxy' } | null> {
    try {
      const res = await fetchWithTimeout('/api/stake-graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpoint: config.endpoint || 'https://stake.bet/_api/graphql',
          query,
          variables,
          token: tokenClean,
          cookie: config.cookie?.trim(),
          userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : undefined,
          customHeaders,
        }),
      }, timeout);

      const json = await res.json().catch(() => null);
      if (json && (json.data || json.errors)) return { ...json, route: 'proxy' };
      return null;
    } catch {
      return null;
    }
  }

  async function tryCorsProxy(proxyBaseUrl: string, timeout = 3500): Promise<{ data?: T; errors?: any[]; route: 'cors-proxy' } | null> {
    try {
      const rawTarget = config.endpoint || 'https://stake.bet/_api/graphql';
      const targetUrl = proxyBaseUrl.includes('?url=') || proxyBaseUrl.includes('?quest=')
        ? `${proxyBaseUrl}${encodeURIComponent(rawTarget)}`
        : `${proxyBaseUrl.replace(/\/$/, '')}/${encodeURIComponent(rawTarget)}`;

      const targetHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'x-access-token': tokenClean,
        'authorization': `Bearer ${tokenClean}`,
        ...customHeaders,
      };

      const res = await fetchWithTimeout(targetUrl, {
        method: 'POST',
        headers: targetHeaders,
        body: JSON.stringify({ query, variables }),
      }, timeout);

      const json = await res.json().catch(() => null);
      if (json && (json.data || json.errors)) return { ...json, route: 'cors-proxy' };
      return null;
    } catch {
      return null;
    }
  }

  async function tryDirectFetch(timeout = 3500): Promise<{ data?: T; errors?: any[]; route: 'direct' } | null> {
    try {
      const targetHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'x-access-token': tokenClean,
        'authorization': `Bearer ${tokenClean}`,
        ...customHeaders,
      };

      const res = await fetchWithTimeout(config.endpoint || 'https://stake.bet/_api/graphql', {
        method: 'POST',
        headers: targetHeaders,
        body: JSON.stringify({ query, variables }),
      }, timeout);

      const json = await res.json().catch(() => null);
      if (json && (json.data || json.errors)) return { ...json, route: 'direct' };
      return null;
    } catch {
      return null;
    }
  }

  // 1. Check cached working route first for sub-200ms execution
  const activeRoute = cachedWorkingRoute || config.routingMode || 'proxy';
  let cachedResult: { data?: T; errors?: any[]; route: any } | null = null;

  if (activeRoute === 'proxy') {
    cachedResult = await tryServerProxy(3000);
  } else if (activeRoute === 'cors-proxy') {
    cachedResult = await tryCorsProxy(config.corsProxyUrl?.trim() || 'https://corsproxy.io/?url=', 3000);
  } else if (activeRoute === 'direct') {
    cachedResult = await tryDirectFetch(3000);
  }

  if (cachedResult && (cachedResult.data || cachedResult.errors)) {
    if (cachedResult.errors && cachedResult.errors.length > 0) {
      const errMsg = cachedResult.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
      if (errMsg.toLowerCase().includes('unauthenticated') || errMsg.toLowerCase().includes('invalid token')) {
        throw new Error('Stake Session Token Anda tidak valid atau telah kedaluwarsa. Silakan ambil token baru dari stake.com / stake.bet.');
      }
      throw new Error(errMsg);
    }
    const executionMs = Math.round(performance.now() - startTime);
    return { data: cachedResult.data, errors: cachedResult.errors, executionMs };
  }

  // Invalidate route cache on failure
  cachedWorkingRoute = null;

  // 2. Parallel Race across all available connection routes for instant response
  const raceTasks = [
    async () => {
      const res = await tryServerProxy(3500);
      if (res) return res;
      throw new Error('Server proxy failed');
    },
    async () => {
      const res = await tryCorsProxy('https://corsproxy.io/?url=', 3500);
      if (res) return res;
      throw new Error('CORS proxy 1 failed');
    },
    async () => {
      const res = await tryCorsProxy('https://api.allorigins.win/raw?url=', 3500);
      if (res) return res;
      throw new Error('CORS proxy 2 failed');
    },
    async () => {
      const res = await tryDirectFetch(3500);
      if (res) return res;
      throw new Error('Direct fetch failed');
    },
  ];

  try {
    const winningResult = await Promise.any(raceTasks.map((t) => t()));
    if (winningResult) {
      cachedWorkingRoute = winningResult.route;
      if (winningResult.errors && winningResult.errors.length > 0) {
        const errMsg = winningResult.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
        if (errMsg.toLowerCase().includes('unauthenticated') || errMsg.toLowerCase().includes('invalid token')) {
          throw new Error('Stake Session Token Anda tidak valid atau telah kedaluwarsa. Silakan ambil token baru dari stake.com / stake.bet.');
        }
        throw new Error(errMsg);
      }
      const executionMs = Math.round(performance.now() - startTime);
      return { data: winningResult.data, errors: winningResult.errors, executionMs };
    }
  } catch {
    // All parallel routes failed
  }

  throw new Error('Koneksi ke Stake lambat atau terputus. Pastikan Stake Session Token Anda valid dan aktif di stake.com.');
}

// Lightweight mirror ping tester that accurately checks responsiveness
export async function testEndpointPing(
  endpoint: string,
  mode: RoutingMode,
  token?: string,
  cookie?: string,
  corsProxyUrl?: string
): Promise<{ status: 'ok' | 'blocked' | 'error'; latency: number; message: string }> {
  const start = performance.now();
  try {
    if (mode === 'proxy') {
      const res = await fetch('/api/stake-graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpoint,
          query: DEFAULT_BALANCES_QUERY,
          variables: {},
          token: token?.trim() || 'test_token',
          cookie: cookie?.trim(),
        }),
      });
      const latency = Math.round(performance.now() - start);
      const json = await res.json().catch(() => ({}));
      if (res.ok) {
        return { status: 'ok', latency, message: 'Online' };
      }
      if (res.status === 403 || json.isCloudflare) {
        return { status: 'blocked', latency, message: 'Cloudflare 403 (GCP Block)' };
      }
      if (res.status === 401) {
        return { status: 'ok', latency, message: 'Aktif (Perlu Token Valid)' };
      }
      return { status: 'error', latency, message: `HTTP ${res.status}` };
    }

    if (mode === 'cors-proxy') {
      const proxyBase = corsProxyUrl?.trim() || 'https://corsproxy.io/?url=';
      const targetUrl = proxyBase.includes('?url=')
        ? `${proxyBase}${encodeURIComponent(endpoint)}`
        : `${proxyBase.replace(/\/$/, '')}/${encodeURIComponent(endpoint)}`;

      const res = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-access-token': token?.trim() || 'test_token',
        },
        body: JSON.stringify({ query: DEFAULT_BALANCES_QUERY, variables: {} }),
      });
      const latency = Math.round(performance.now() - start);
      if (res.ok || res.status === 401) {
        return { status: 'ok', latency, message: 'Online (Bebas 403)' };
      }
      return { status: 'error', latency, message: `HTTP ${res.status}` };
    }

    // Direct mode
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token?.trim() || 'test_token',
      },
      body: JSON.stringify({ query: DEFAULT_BALANCES_QUERY, variables: {} }),
    });
    const latency = Math.round(performance.now() - start);
    if (res.ok || res.status === 401) {
      return { status: 'ok', latency, message: 'Online' };
    }
    if (res.status === 403) {
      return { status: 'blocked', latency, message: '403 Forbidden' };
    }
    return { status: 'error', latency, message: `HTTP ${res.status}` };
  } catch (err: any) {
    const latency = Math.round(performance.now() - start);
    const msg = err.message || '';
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || err.name === 'TypeError') {
      return { status: 'blocked', latency, message: 'CORS Browser (Gunakan CORS Proxy)' };
    }
    return { status: 'error', latency, message: msg.slice(0, 30) };
  }
}

// Fetch balances and user profile from Stake API
export async function fetchUserBalances(config: StakeConfig): Promise<{
  username: string;
  balances: Record<string, number>;
}> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Token belum dimasukkan.');
  }

  // Main query for basic user info and balances
  let query = config.balanceQueryOverride || DEFAULT_BALANCES_QUERY;
  // If override contains sensitive or broken VIP fields, fallback to default
  if (query.includes('vipLevel') || query.includes('vipProgress') || query.includes('vip {')) {
    query = DEFAULT_BALANCES_QUERY;
  }

  const result = await executeGraphQL<any>(query, {}, config);

  if (result.errors && result.errors.length > 0) {
    throw new Error(result.errors[0]?.message || 'GraphQL error saat mengambil saldo');
  }

  const user = result.data?.user;
  if (!user) {
    throw new Error('Tidak ada data user yang dikembalikan dari Stake. Periksa validitas token.');
  }

  const balancesMap: Record<string, number> = {};
  if (Array.isArray(user.balances)) {
    user.balances.forEach((b: any) => {
      const cur = (b.available?.currency || b.currency || '').toLowerCase();
      const amt = Number(b.available?.amount ?? b.amount ?? 0);
      if (cur) {
        balancesMap[cur] = amt;
        if (cur === 'matic') balancesMap['pol'] = amt;
        if (cur === 'pol') balancesMap['matic'] = amt;
      }
    });
  }

  return {
    username: user.name || user.id || 'Stake User',
    balances: balancesMap,
  };
}

// Play Dice
export async function playDice(
  amount: number,
  target: number,
  condition: DiceCondition,
  currency: string,
  config: StakeConfig
): Promise<BetResult> {
  const houseEdge = config.houseEdgePercent || 1.0;
  const edgeFactor = (100 - houseEdge) / 100;
  const winChance = condition === 'above' ? 100 - target : target;
  const theoreticalMultiplier = Number(((edgeFactor * 100) / winChance).toFixed(4));

  const query = getEffectiveDiceQuery(config.diceQueryOverride);
  const identifier = generateIdentifier();
  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);
  const safeTarget = Number(Number(target).toFixed(2));

  const variables = {
    amount: safeAmount,
    target: safeTarget,
    condition: condition, // 'above' or 'below'
    currency: safeCurrency,
    identifier,
  };

  const res = await executeGraphQL<any>(query, variables, config);

  if (res.errors && res.errors.length > 0) {
    throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
  }

  const diceData = res.data?.diceRoll || res.data?.bet;
  const bet = diceData?.bet || diceData;
  const state = bet?.state || diceData?.state;
  
  // High priority on state.result as it contains the real game outcome from Stake
  const rawRoll = state?.result ?? bet?.result ?? diceData?.result;
  let rollResult = typeof rawRoll === 'number' ? rawRoll : parseFloat(String(rawRoll || '0'));
  
  if (isNaN(rollResult) || rollResult === 0) {
    // Fallback for cases where result might be under a different field
    const altRoll = bet?.roll || diceData?.roll || state?.roll;
    if (altRoll !== undefined) rollResult = parseFloat(String(altRoll));
  }
  
  rollResult = Number(rollResult.toFixed(2));
  const payoutMultiplier = Number(bet?.payoutMultiplier ?? bet?.amountMultiplier ?? 0);
  const won = payoutMultiplier > 0;
  const payout = Number(bet?.payout ?? 0);
  const profit = won
    ? (payout > 0 ? payout - safeAmount : Number((safeAmount * (payoutMultiplier - 1)).toFixed(8)))
    : -safeAmount;

  const rawBetId = String(bet?.id || diceData?.id || `bet_${Date.now()}_${identifier.slice(0, 6)}`).trim();

  return {
    id: rawBetId,
    game: 'dice',
    currency,
    betAmount: safeAmount,
    target: safeTarget,
    condition,
    multiplier: won ? (payoutMultiplier || theoreticalMultiplier) : 0,
    rollResult,
    won,
    profit: Number(profit.toFixed(8)),
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: rawBetId,
  };
}

// Play Limbo
export async function playLimbo(
  amount: number,
  multiplierTarget: number,
  currency: string,
  config: StakeConfig
): Promise<BetResult> {
  const query = getEffectiveLimboQuery(config.limboQueryOverride);
  const identifier = generateIdentifier();
  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);
  const safeMultiplierTarget = Number(Number(multiplierTarget).toFixed(2));

  const variables = {
    amount: safeAmount,
    multiplierTarget: safeMultiplierTarget,
    currency: safeCurrency,
    identifier,
  };

  const res = await executeGraphQL<any>(query, variables, config);

  if (res.errors && res.errors.length > 0) {
    throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
  }

  const limboData = res.data?.limboBet || res.data?.bet;
  const bet = limboData?.bet || limboData;
  const state = bet?.state || limboData?.state;
  
  // High priority on state.result for the real Limbo outcome multiplier
  const rawRoll = state?.result ?? bet?.result ?? limboData?.result;
  let rollResult = typeof rawRoll === 'number' ? rawRoll : parseFloat(String(rawRoll || '0'));
  
  const payoutMultiplier = Number(bet?.payoutMultiplier ?? bet?.amountMultiplier ?? 0);
  const won = payoutMultiplier > 0;

  if (isNaN(rollResult) || rollResult <= 0) {
    // If result is missing but we won, the multiplier is the result
    if (won && payoutMultiplier > 0) {
      rollResult = payoutMultiplier;
    } else {
      // For losses, if result is missing, we try to find it elsewhere or keep it at 0
      const altRoll = bet?.multiplier || limboData?.multiplier || state?.multiplier;
      if (altRoll !== undefined) rollResult = parseFloat(String(altRoll));
      else rollResult = 0;
    }
  }
  rollResult = Number(rollResult.toFixed(2));

  const payout = Number(bet?.payout ?? 0);
  const profit = won
    ? (payout > 0 ? payout - safeAmount : Number((safeAmount * (safeMultiplierTarget - 1)).toFixed(8)))
    : -safeAmount;

  const rawBetId = String(bet?.id || limboData?.id || `bet_${Date.now()}_${identifier.slice(0, 6)}`).trim();

  return {
    id: rawBetId,
    game: 'limbo',
    currency,
    betAmount: safeAmount,
    target: safeMultiplierTarget,
    multiplier: won ? (payoutMultiplier > 0 ? payoutMultiplier : safeMultiplierTarget) : 0,
    rollResult,
    won,
    profit: Number(profit.toFixed(8)),
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: rawBetId,
  };
}

// Plinko Multipliers Lookup Tables (Standard Stake Originals with 4 Risk Tiers: Low, Medium, High & Expert up to 10,000x)
export const PLINKO_PAYOUTS: Record<PlinkoRows, Record<PlinkoRisk, number[]>> = {
  8: {
    low: [5.6, 2.1, 1.1, 1.0, 0.5, 1.0, 1.1, 2.1, 5.6],
    medium: [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
    high: [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29],
    expert: [50, 6, 2, 0.3, 0.1, 0.3, 2, 6, 50],
  },
  9: {
    low: [5.6, 2.0, 1.6, 1.0, 0.7, 0.7, 1.0, 1.6, 2.0, 5.6],
    medium: [18, 4, 1.7, 0.9, 0.5, 0.5, 0.9, 1.7, 4, 18],
    high: [43, 7, 2, 0.6, 0.2, 0.2, 0.6, 2, 7, 43],
    expert: [100, 15, 3.5, 1, 0.2, 0.2, 1, 3.5, 15, 100],
  },
  10: {
    low: [8.9, 3, 1.4, 1.1, 1.0, 0.5, 1.0, 1.1, 1.4, 3, 8.9],
    medium: [22, 5, 2, 1.4, 0.6, 0.4, 0.6, 1.4, 2, 5, 22],
    high: [76, 10, 3, 0.9, 0.3, 0.2, 0.3, 0.9, 3, 10, 76],
    expert: [201, 25, 6, 1.8, 0.3, 0.2, 0.3, 1.8, 6, 25, 201],
  },
  11: {
    low: [8.4, 3, 1.9, 1.3, 1.0, 0.7, 0.7, 1.0, 1.3, 1.9, 3, 8.4],
    medium: [24, 6, 3, 1.8, 0.7, 0.5, 0.5, 0.7, 1.8, 3, 6, 24],
    high: [120, 14, 4.2, 1.4, 0.4, 0.2, 0.2, 0.4, 1.4, 4.2, 14, 120],
    expert: [324, 38, 10, 2.5, 0.6, 0.2, 0.2, 0.6, 2.5, 10, 38, 324],
  },
  12: {
    low: [10, 3, 1.6, 1.4, 1.1, 1.0, 0.5, 1.0, 1.1, 1.4, 1.6, 3, 10],
    medium: [33, 11, 4, 2, 1.1, 0.6, 0.3, 0.6, 1.1, 2, 4, 11, 33],
    high: [170, 24, 8.1, 2, 0.7, 0.3, 0.2, 0.3, 0.7, 2, 8.1, 24, 170],
    expert: [619, 70, 16, 4, 1.2, 0.3, 0.2, 0.3, 1.2, 4, 16, 70, 619],
  },
  13: {
    low: [8.1, 4, 3, 1.9, 1.3, 1.0, 0.7, 0.7, 1.0, 1.3, 1.9, 3, 4, 8.1],
    medium: [43, 13, 6, 3, 1.3, 0.7, 0.4, 0.4, 0.7, 1.3, 3, 6, 13, 43],
    high: [260, 37, 11, 4, 1, 0.3, 0.2, 0.2, 0.3, 1, 4, 11, 37, 260],
    expert: [1012, 110, 28, 7, 2, 0.4, 0.2, 0.2, 0.4, 2, 7, 28, 110, 1012],
  },
  14: {
    low: [7.1, 4, 1.9, 1.4, 1.3, 1.1, 1.0, 0.5, 1.0, 1.1, 1.3, 1.4, 1.9, 4, 7.1],
    medium: [58, 15, 7, 4, 1.9, 1, 0.5, 0.2, 0.5, 1, 1.9, 4, 7, 15, 58],
    high: [420, 56, 18, 5, 1.9, 0.3, 0.2, 0.2, 0.2, 0.3, 1.9, 5, 18, 56, 420],
    expert: [2369, 210, 50, 12, 3, 0.8, 0.3, 0.2, 0.3, 0.8, 3, 12, 50, 210, 2369],
  },
  15: {
    low: [15, 8, 3, 2, 1.5, 1.1, 1.0, 0.7, 0.7, 1.0, 1.1, 1.5, 2, 3, 8, 15],
    medium: [88, 18, 11, 5, 3, 1.3, 0.5, 0.3, 0.3, 0.5, 1.3, 3, 5, 11, 18, 88],
    high: [620, 83, 27, 8, 3, 0.5, 0.2, 0.2, 0.2, 0.2, 0.5, 3, 8, 27, 83, 620],
    expert: [5000, 420, 95, 22, 5.5, 1.3, 0.4, 0.2, 0.2, 0.4, 1.3, 5.5, 22, 95, 420, 5000],
  },
  16: {
    low: [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1.0, 0.5, 1.0, 1.1, 1.2, 1.4, 1.4, 2, 9, 16],
    medium: [110, 41, 10, 5, 3, 1.5, 1, 0.5, 0.3, 0.5, 1, 1.5, 3, 5, 10, 41, 110],
    high: [1000, 130, 26, 9, 4, 2, 0.2, 0.2, 0.2, 0.2, 0.2, 2, 4, 9, 26, 130, 1000],
    expert: [10000, 800, 180, 42, 10, 2.5, 0.7, 0.3, 0.2, 0.3, 0.7, 2.5, 10, 42, 180, 800, 10000],
  },
};

// Play Plinko
export async function playPlinko(
  amount: number,
  risk: PlinkoRisk,
  rows: PlinkoRows,
  currency: string,
  config: StakeConfig
): Promise<BetResult> {
  const query = getEffectivePlinkoQuery(config.plinkoQueryOverride);
  const identifier = generateIdentifier();
  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);

  let variables: Record<string, any> = {
    amount: safeAmount,
    risk: risk.toLowerCase(),
    rows: Number(rows),
    currency: safeCurrency,
    identifier,
  };

  let res: any;
  try {
    res = await executeGraphQL<any>(query, variables, config);
  } catch (err: any) {
    const msg = String(err?.message || '');
    // If Stake schema expects UPPERCASE risk enum (LOW, MEDIUM, HIGH, EXPERT)
    if (msg.includes('CasinoGamePlinkoRiskEnum') && (msg.includes('value') || msg.includes('invalid') || msg.includes('Expected'))) {
      variables = {
        ...variables,
        risk: risk.toUpperCase(),
      };
      res = await executeGraphQL<any>(query, variables, config);
    } else {
      throw err;
    }
  }

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    if (errMsg.includes('CasinoGamePlinkoRiskEnum') && (errMsg.includes('value') || errMsg.includes('invalid') || errMsg.includes('Expected'))) {
      variables = {
        ...variables,
        risk: risk.toUpperCase(),
      };
      res = await executeGraphQL<any>(query, variables, config);
      if (res.errors && res.errors.length > 0) {
        throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
      }
    } else {
      throw new Error(errMsg);
    }
  }

  const plinkoData = res.data?.plinkoBet || res.data?.bet || res.data?.casinoGamePlinkoBet;
  const bet = plinkoData?.bet || plinkoData;
  const state = bet?.state;
  const payoutMultiplier = Number(bet?.payoutMultiplier ?? bet?.amountMultiplier ?? state?.multiplier ?? 0);
  const payout = Number(bet?.payout ?? (safeAmount * payoutMultiplier));
  const won = payoutMultiplier >= 1.0;
  const profit = Number((payout - safeAmount).toFixed(8));

  const rollResult = Number(state?.result ?? payoutMultiplier);
  const rawBetId = String(bet?.id || plinkoData?.id || `bet_${Date.now()}_${identifier.slice(0, 6)}`).trim();

  return {
    id: rawBetId,
    game: 'plinko',
    currency,
    betAmount: safeAmount,
    target: rows,
    multiplier: payoutMultiplier,
    rollResult,
    won,
    profit,
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: rawBetId,
  };
}

// ----------------------------------------------------
// STAKE DIAMONDS GAME TYPES & PROVABLY FAIR ENGINE
// ----------------------------------------------------

export type DiamondColor = 'green' | 'purple' | 'yellow' | 'red' | 'cyan' | 'pink' | 'blue';

export const DIAMOND_COLOR_MAP: Record<DiamondColor, { name: string; hex: string; bg: string; border: string; text: string }> = {
  green: { name: 'Hijau', hex: '#22c55e', bg: 'bg-emerald-500/15', border: 'border-emerald-500', text: 'text-emerald-400' },
  purple: { name: 'Ungu', hex: '#a855f7', bg: 'bg-purple-500/15', border: 'border-purple-500', text: 'text-purple-400' },
  yellow: { name: 'Kuning', hex: '#eab308', bg: 'bg-amber-500/15', border: 'border-amber-500', text: 'text-amber-400' },
  red: { name: 'Merah', hex: '#ef4444', bg: 'bg-rose-500/15', border: 'border-rose-500', text: 'text-rose-400' },
  cyan: { name: 'Cyan', hex: '#06b6d4', bg: 'bg-cyan-500/15', border: 'border-cyan-500', text: 'text-cyan-400' },
  pink: { name: 'Pink', hex: '#ec4899', bg: 'bg-pink-500/15', border: 'border-pink-500', text: 'text-pink-400' },
  blue: { name: 'Biru', hex: '#3b82f6', bg: 'bg-blue-500/15', border: 'border-blue-500', text: 'text-blue-400' },
};

export const DIAMOND_COLORS: DiamondColor[] = ['green', 'purple', 'yellow', 'red', 'cyan', 'pink', 'blue'];

export interface DiamondsPaytableItem {
  id: string;
  name: string;
  multiplier: number;
  probability: string;
  description: string;
}

export const DIAMONDS_PAYTABLE: DiamondsPaytableItem[] = [
  { id: 'five_of_a_kind', name: '5 Kembar (Five of a Kind)', multiplier: 50.00, probability: '0.05%', description: '5 warna permata sama persis' },
  { id: 'four_of_a_kind', name: '4 Kembar (Four of a Kind)', multiplier: 5.00, probability: '1.25%', description: '4 warna permata sama + 1 beda' },
  { id: 'full_house', name: 'Full House', multiplier: 4.00, probability: '2.50%', description: '3 kembar + 2 kembar' },
  { id: 'three_of_a_kind', name: '3 Kembar (Three of a Kind)', multiplier: 3.00, probability: '12.49%', description: '3 warna permata sama + 2 beda' },
  { id: 'two_pair', name: '2 Pasang (Two Pair)', multiplier: 2.00, probability: '18.74%', description: '2 pasang warna kembar + 1 beda' },
  { id: 'one_pair', name: '1 Pasang (One Pair)', multiplier: 0.10, probability: '49.98%', description: '1 pasang warna kembar + 3 beda' },
  { id: 'no_match', name: 'Tidak Cocok (No Match)', multiplier: 0.00, probability: '14.99%', description: 'Semua 5 warna permata berbeda' },
];

export function getDiamondsCombinationName(multiplier: number): string {
  if (multiplier >= 50) return '5 Kembar (50.00×)';
  if (multiplier >= 5) return '4 Kembar (5.00×)';
  if (multiplier >= 4) return 'Full House (4.00×)';
  if (multiplier >= 3) return '3 Kembar (3.00×)';
  if (multiplier >= 2) return '2 Pasang (2.00×)';
  if (multiplier >= 0.1) return '1 Pasang (0.10×)';
  return 'Tidak Cocok (0.00×)';
}

// Generate representative gems matching a multiplier if state.diamonds is not provided
export function generateMatchingDiamondsForMultiplier(multiplier: number): DiamondColor[] {
  if (multiplier >= 50) return ['green', 'green', 'green', 'green', 'green'];
  if (multiplier >= 5) return ['purple', 'purple', 'purple', 'purple', 'yellow'];
  if (multiplier >= 4) return ['blue', 'blue', 'blue', 'red', 'red'];
  if (multiplier >= 3) return ['yellow', 'yellow', 'yellow', 'cyan', 'pink'];
  if (multiplier >= 2) return ['red', 'red', 'cyan', 'cyan', 'blue'];
  if (multiplier >= 0.1) return ['green', 'green', 'purple', 'pink', 'blue'];
  return ['green', 'purple', 'yellow', 'red', 'cyan'];
}

// Play Diamonds on Stake
export async function playDiamonds(
  amount: number,
  currency: string,
  config: StakeConfig
): Promise<BetResult> {
  const query = getEffectiveDiamondsQuery(config.diamondsQueryOverride);
  const identifier = generateIdentifier();
  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);

  const variables = {
    amount: safeAmount,
    currency: safeCurrency,
    identifier,
  };

  let res: any;
  try {
    res = await executeGraphQL<any>(query, variables, config);
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (msg.includes('CasinoGameDiamonds') || msg.includes('diamonds') || msg.includes('Cannot query field')) {
      // Try fallback without state selection
      try {
        res = await executeGraphQL<any>(FALLBACK_DIAMONDS_MUTATION, variables, config);
      } catch {
        // Try singular mutation name diamondBet
        res = await executeGraphQL<any>(FALLBACK_DIAMOND_SINGULAR_MUTATION, variables, config);
      }
    } else {
      throw err;
    }
  }

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    if (errMsg.includes('CasinoGameDiamonds') || errMsg.includes('Cannot query field "diamonds"')) {
      res = await executeGraphQL<any>(FALLBACK_DIAMONDS_MUTATION, variables, config);
      if (res.errors && res.errors.length > 0) {
        throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
      }
    } else {
      throw new Error(errMsg);
    }
  }

  const diamondsData = res.data?.diamondsBet || res.data?.diamondBet || res.data?.bet;
  const bet = diamondsData?.bet || diamondsData;
  const state = bet?.state || diamondsData?.state;
  const payoutMultiplier = Number(bet?.payoutMultiplier ?? bet?.amountMultiplier ?? state?.multiplier ?? 0);
  const payout = Number(bet?.payout ?? (safeAmount * payoutMultiplier));
  const won = payoutMultiplier >= 1.0;
  const profit = Number((payout - safeAmount).toFixed(8));

  // Extract diamonds array from response state
  let diamondsArr: DiamondColor[] = [];
  const rawDiamonds = state?.diamonds || state?.gems || state?.result;
  if (Array.isArray(rawDiamonds) && rawDiamonds.length > 0) {
    diamondsArr = rawDiamonds.map((d: any) => {
      if (typeof d === 'string') {
        const clean = d.toLowerCase().trim();
        if (DIAMOND_COLORS.includes(clean as DiamondColor)) return clean as DiamondColor;
      }
      if (typeof d === 'number' && d >= 0 && d < DIAMOND_COLORS.length) {
        return DIAMOND_COLORS[d];
      }
      if (d && typeof d === 'object') {
        const val = (d.color || d.gem || d.name || '').toLowerCase().trim();
        if (DIAMOND_COLORS.includes(val as DiamondColor)) return val as DiamondColor;
      }
      return 'green';
    });
  }

  // If diamonds array is missing from payload, generate matching representative combination
  if (diamondsArr.length !== 5) {
    diamondsArr = generateMatchingDiamondsForMultiplier(payoutMultiplier);
  }

  const combinationName = getDiamondsCombinationName(payoutMultiplier);
  const rawBetId = String(bet?.id || diamondsData?.id || `bet_${Date.now()}_${identifier.slice(0, 6)}`).trim();

  return {
    id: rawBetId,
    game: 'diamonds',
    currency,
    betAmount: safeAmount,
    target: 5,
    multiplier: payoutMultiplier,
    rollResult: payoutMultiplier,
    won,
    profit,
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: rawBetId,
    isLiveStake: true,
    diamonds: diamondsArr,
    combinationName,
  };
}

// ----------------------------------------------------
// STAKE MINES GAME TYPES & PROVABLY FAIR ENGINE
// ----------------------------------------------------

export interface MinesRoundState {
  id: string;
  active: boolean;
  payoutMultiplier: number;
  amount: number;
  payout: number;
  currency: string;
  minesCount: number;
  revealedFields: number[]; // indices 0-24 of safely revealed diamonds
  minePositions?: number[]; // indices 0-24 of all mines (revealed on game end)
  hitMineIndex?: number;    // if busted, which tile exploded
  executionMs: number;
  isLiveStake: boolean;
}

// Exact Stake Mines Multiplier: (1 - houseEdge/100) * [ C(25, d) / C(25 - m, d) ]
export function getMinesMultiplier(diamondsCount: number, minesCount: number, houseEdge = 1.0): number {
  if (diamondsCount <= 0) return 1.0;
  const safeCount = 25 - minesCount;
  if (diamondsCount > safeCount) return 0;
  let mult = 1 - (houseEdge / 100);
  for (let i = 0; i < diamondsCount; i++) {
    mult *= (25 - i) / (25 - minesCount - i);
  }
  return Number(mult.toFixed(4));
}

// Parse live response from Stake GraphQL (minesBet, minesNext, minesCashout, activeCasinoBet)
export function parseMinesResponse(res: any, executionMs = 0): MinesRoundState {
  const data = res?.data?.minesBet || res?.data?.minesNext || res?.data?.minesCashout || res?.data?.bet || res?.data?.user?.activeCasinoBet;
  if (!data) {
    if (res?.errors && res.errors.length > 0) {
      throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
    }
    throw new Error('Data putaran Mines tidak valid dari server Stake.');
  }

  const state = data.state || {};
  const rawRounds = state.rounds || [];
  const revealedFields: number[] = Array.isArray(rawRounds)
    ? rawRounds.map((r: any) => (typeof r === 'number' ? r : Number(r.field)))
    : [];

  const rawMines = state.mines || state.minePositions;
  const minePositions: number[] | undefined = Array.isArray(rawMines) && rawMines.length > 0
    ? rawMines.map((m: any) => (typeof m === 'number' ? m : Number(m.field ?? m)))
    : undefined;

  const active = Boolean(data.active);
  const payoutMultiplier = Number(data.payoutMultiplier ?? data.amountMultiplier ?? 0);
  const amount = Number(data.amount ?? 0);
  const payout = Number(data.payout ?? 0);
  const currency = String(data.currency || 'btc').toLowerCase();
  const minesCount = Number(state.minesCount || 3);

  // If game is finished (bust with 0 multiplier), identify which tile was the bomb
  let hitMineIndex: number | undefined = undefined;
  if (!active && payoutMultiplier === 0 && revealedFields.length > 0 && minePositions) {
    const lastField = revealedFields[revealedFields.length - 1];
    if (minePositions.includes(lastField)) {
      hitMineIndex = lastField;
    }
  }

  return {
    id: String(data.id || data.betId || Date.now()),
    active,
    payoutMultiplier,
    amount,
    payout,
    currency,
    minesCount,
    revealedFields,
    minePositions,
    hitMineIndex,
    executionMs,
    isLiveStake: true,
  };
}

// Query Stake for active unfinished Mines bet with multi-query fallback
export async function fetchActiveMines(config: StakeConfig): Promise<MinesRoundState | null> {
  if (!config.token || config.token.trim().length === 0) return null;

  const queries = [
    // 1. Direct activeCasinoBet with (game: "mines")
    `query ActiveCasinoMinesBetWithGame {
      user {
        activeCasinoBet(game: "mines") {
          id
          active
          payoutMultiplier
          amountMultiplier
          amount
          payout
          currency
          game
          state {
            __typename
            ... on CasinoGameMines {
              mines
              minesCount
              rounds {
                field
                payoutMultiplier
              }
            }
          }
        }
      }
    }`,
    // 2. Standard general activeCasinoBet
    ACTIVE_MINES_QUERY,
    // 3. Active casino bets list
    `query ActiveCasinoBetsList {
      user {
        activeCasinoBets {
          id
          active
          payoutMultiplier
          amountMultiplier
          amount
          payout
          currency
          game
          state {
            __typename
            ... on CasinoGameMines {
              mines
              minesCount
              rounds {
                field
                payoutMultiplier
              }
            }
          }
        }
      }
    }`,
  ];

  for (const q of queries) {
    try {
      const res = await executeGraphQL<any>(q, {}, config);
      const user = res.data?.user;
      if (!user) continue;

      let bet = user.activeCasinoBet;
      if (!bet && Array.isArray(user.activeCasinoBets)) {
        bet = user.activeCasinoBets.find((b: any) => {
          if (!b?.active) return false;
          return (
            b?.state?.minesCount !== undefined ||
            b?.state?.__typename === 'CasinoGameMines' ||
            String(b?.game || '').toLowerCase().includes('mines')
          );
        });
      }

      if (bet && bet.active) {
        const isMines =
          bet.state?.minesCount !== undefined ||
          bet.state?.__typename === 'CasinoGameMines' ||
          String(bet.game || '').toLowerCase().includes('mines');

        if (isMines) {
          return parseMinesResponse({ data: { minesBet: bet } }, res.executionMs);
        }
      }
    } catch {
      // Continue to next query attempt
    }
  }

  return null;
}

// 1. Play Mines (Start Real Stake Mines Bet)
export async function playMinesBet(
  amount: number,
  currency: string,
  minesCount: number,
  identifier: string,
  config: StakeConfig
): Promise<MinesRoundState> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Stake Session Token belum dimasukkan. Masukkan token Anda di tab Pengaturan untuk bermain Mines asli dari Stake.');
  }

  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);
  const safeMinesCount = Math.max(1, Math.min(24, Math.floor(minesCount)));
  const query = getEffectiveMinesQuery(config.minesQueryOverride);

  const variables = {
    amount: safeAmount,
    currency: safeCurrency,
    minesCount: safeMinesCount,
    fields: [],
    identifier,
  };

  const res = await executeGraphQL<any>(query, variables, config);

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    throw new Error(errMsg);
  }

  const betData = res.data?.minesBet || res.data?.bet;
  if (!betData) {
    throw new Error('Tidak ada respon data taruhan Mines dari Stake.');
  }

  return parseMinesResponse(res, res.executionMs);
}

// 2. Reveal Tile (Pick tile 0-24 on Stake)
export async function revealMinesTile(
  field: number,
  identifier: string,
  config: StakeConfig
): Promise<MinesRoundState> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Stake Session Token diperlukan untuk membuka petak di Stake.');
  }

  const variablesWithId = { fields: [field], identifier };
  const fallbackQuery = `
mutation MinesNext($fields: [Int!]!) {
  minesNext(fields: $fields) {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    state {
      ... on CasinoGameMines {
        mines
        minesCount
        rounds {
          field
          payoutMultiplier
        }
      }
    }
  }
}
  `.trim();

  let res: any;
  try {
    res = await executeGraphQL<any>(DEFAULT_MINES_NEXT_MUTATION, variablesWithId, config);
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (msg.includes('Unknown argument "identifier"') || (msg.includes('identifier') && msg.includes('argument'))) {
      res = await executeGraphQL<any>(fallbackQuery, { fields: [field] }, config);
    } else {
      throw err;
    }
  }

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    if (errMsg.includes('Unknown argument "identifier"') || (errMsg.includes('identifier') && errMsg.includes('argument'))) {
      res = await executeGraphQL<any>(fallbackQuery, { fields: [field] }, config);
      if (res.errors && res.errors.length > 0) {
        throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
      }
    } else {
      throw new Error(errMsg);
    }
  }

  return parseMinesResponse(res, res.executionMs);
}

// 3. Cashout Mines on Stake
export async function cashoutMines(
  identifier: string,
  config: StakeConfig
): Promise<MinesRoundState> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Stake Session Token diperlukan untuk melakukan cashout di Stake.');
  }

  const fallbackQuery = `
mutation MinesCashout {
  minesCashout {
    id
    active
    payoutMultiplier
    amountMultiplier
    amount
    payout
    updatedAt
    currency
    game
    state {
      ... on CasinoGameMines {
        mines
        minesCount
        rounds {
          field
          payoutMultiplier
        }
      }
    }
  }
}
  `.trim();

  let res: any;
  try {
    res = await executeGraphQL<any>(DEFAULT_MINES_CASHOUT_MUTATION, { identifier }, config);
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (msg.includes('Unknown argument "identifier"') || (msg.includes('identifier') && msg.includes('argument'))) {
      res = await executeGraphQL<any>(fallbackQuery, {}, config);
    } else {
      throw err;
    }
  }

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    if (errMsg.includes('Unknown argument "identifier"') || (errMsg.includes('identifier') && errMsg.includes('argument'))) {
      res = await executeGraphQL<any>(fallbackQuery, {}, config);
      if (res.errors && res.errors.length > 0) {
        throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
      }
    } else {
      throw new Error(errMsg);
    }
  }

  return parseMinesResponse(res, res.executionMs);
}

// 4. Play Mines Auto / Batch Bet on Stake (Resolves all selected fields in one single fast call)
export async function playMinesAutoBet(
  amount: number,
  currency: string,
  minesCount: number,
  fields: number[],
  config: StakeConfig
): Promise<BetResult> {
  if (!config.token || config.token.trim().length === 0) {
    throw new Error('Stake Session Token belum dimasukkan. Masukkan token Anda di tab Pengaturan.');
  }

  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);
  const safeMinesCount = Math.max(1, Math.min(24, Math.floor(minesCount)));
  const query = getEffectiveMinesQuery(config.minesQueryOverride);
  const identifier = generateIdentifier();

  const variables = {
    amount: safeAmount,
    currency: safeCurrency,
    minesCount: safeMinesCount,
    fields: fields,
    identifier,
  };

  const res = await executeGraphQL<any>(query, variables, config);

  if (res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    throw new Error(errMsg);
  }

  const round = parseMinesResponse(res, res.executionMs);
  const won = round.payoutMultiplier > 0 && round.hitMineIndex === undefined;
  const payout = Number(round.payout || (won ? safeAmount * round.payoutMultiplier : 0));
  const profit = won ? Number((payout - safeAmount).toFixed(8)) : -safeAmount;

  return {
    id: round.id,
    game: 'mines',
    currency,
    betAmount: safeAmount,
    target: round.minesCount,
    multiplier: won ? round.payoutMultiplier : 0,
    rollResult: round.revealedFields.length,
    won,
    profit,
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: round.id,
    isLiveStake: true,
    minesCount: round.minesCount,
    diamondsCount: round.revealedFields.length,
    revealedFields: round.revealedFields,
    minePositions: round.minePositions,
  };
}

// ----------------------------------------------------
// STAKE KENO GAME ENGINE & PAYTABLES
// ----------------------------------------------------

export const KENO_PAYTABLES: Record<KenoRisk, Record<number, number[]>> = {
  classic: {
    1: [0, 3.96],
    2: [0, 1.9, 4.5],
    3: [0, 1, 3.1, 10.4],
    4: [0, 0.8, 1.8, 5, 25],
    5: [0, 0.2, 1.4, 4.1, 16.5, 50],
    6: [0, 0, 1, 2.8, 7, 30, 100],
    7: [0, 0, 0.4, 1.8, 4.5, 14, 60, 275],
    8: [0, 0, 0, 1.5, 3.2, 9, 32, 120, 500],
    9: [0, 0, 0, 1.2, 2.2, 5, 15, 60, 220, 700],
    10: [0, 0, 0, 1, 1.6, 3.5, 10, 35, 130, 400, 1000],
  },
  low: {
    1: [0, 1.9],
    2: [0, 1.4, 2.7],
    3: [0.5, 1, 2.3, 5.5],
    4: [0.7, 0.8, 1.4, 3.2, 10],
    5: [0.7, 0.8, 1.2, 2.4, 6.2, 22],
    6: [0.7, 0.8, 1, 1.8, 4, 13, 50],
    7: [0.7, 0.8, 0.9, 1.4, 2.7, 7, 26, 100],
    8: [0.7, 0.8, 0.9, 1.2, 2, 4.5, 14, 50, 200],
    9: [0.7, 0.8, 0.9, 1.1, 1.6, 3.2, 8.5, 26, 90, 350],
    10: [0.7, 0.8, 0.9, 1, 1.3, 2.4, 5.5, 16, 50, 180, 600],
  },
  medium: {
    1: [0, 2.8],
    2: [0, 1.7, 3.8],
    3: [0, 1.1, 2.8, 8.5],
    4: [0, 0.6, 1.6, 4.5, 20],
    5: [0, 0.3, 1.3, 3.5, 12, 40],
    6: [0, 0, 1.1, 2.4, 6, 22, 80],
    7: [0, 0, 0.5, 1.6, 4, 11, 45, 200],
    8: [0, 0, 0, 1.3, 2.8, 7.5, 24, 90, 400],
    9: [0, 0, 0, 1.1, 2, 4.2, 12, 45, 175, 600],
    10: [0, 0, 0, 0.9, 1.4, 2.8, 8, 26, 95, 300, 800],
  },
  high: {
    1: [0, 3.96],
    2: [0, 0, 9.5],
    3: [0, 0, 0, 26.5],
    4: [0, 0, 0, 8, 80],
    5: [0, 0, 0, 3.5, 25, 270],
    6: [0, 0, 0, 0, 11, 70, 600],
    7: [0, 0, 0, 0, 5.5, 30, 200, 1000],
    8: [0, 0, 0, 0, 3, 14, 80, 400, 2000],
    9: [0, 0, 0, 0, 2, 7.5, 35, 175, 800, 4000],
    10: [0, 0, 0, 0, 1.5, 4.5, 18, 80, 350, 1500, 10000],
  },
};

export function getKenoMultiplier(selectedCount: number, hits: number, risk: KenoRisk): number {
  const table = KENO_PAYTABLES[risk]?.[selectedCount];
  if (!table) return 0;
  return table[hits] ?? 0;
}

export async function playKeno(
  amount: number,
  numbers: number[],
  risk: KenoRisk,
  currency: string,
  config: StakeConfig
): Promise<BetResult> {
  if (numbers.length === 0 || numbers.length > 10) {
    throw new Error('Pilih antara 1 hingga 10 angka untuk bermain Keno.');
  }

  // Stake Keno API expects 0-indexed tile numbers (0 to 39)
  const apiNumbers = numbers.map((n) => (n >= 1 && n <= 40 ? n - 1 : n));

  const query = getEffectiveKenoQuery(config.kenoQueryOverride);
  const identifier = generateIdentifier();
  const safeCurrency = normalizeStakeCurrency(currency);
  const safeAmount = sanitizeBetAmount(amount, currency);

  let variables: Record<string, any> = {
    amount: safeAmount,
    numbers: apiNumbers,
    risk: risk.toLowerCase(),
    currency: safeCurrency,
    identifier,
  };

  let res: any;
  try {
    res = await executeGraphQL<any>(query, variables, config);
  } catch (err: any) {
    const msg = String(err?.message || '');
    if (msg.includes('CasinoGameKeno') || msg.includes('Cannot query field')) {
      try {
        res = await executeGraphQL<any>(FALLBACK_KENO_MUTATION, variables, config);
      } catch {
        variables.risk = risk.toUpperCase();
        res = await executeGraphQL<any>(FALLBACK_KENO_MUTATION, variables, config);
      }
    } else if (msg.includes('CasinoGameKenoRiskEnum') && (msg.includes('value') || msg.includes('invalid') || msg.includes('Expected'))) {
      variables = {
        ...variables,
        risk: risk.toUpperCase(),
      };
      res = await executeGraphQL<any>(query, variables, config);
    } else {
      throw err;
    }
  }

  if (res && res.errors && res.errors.length > 0) {
    const errMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
    if (errMsg.includes('Cannot query field') || errMsg.includes('CasinoGameKeno')) {
      try {
        res = await executeGraphQL<any>(FALLBACK_KENO_MUTATION, variables, config);
      } catch {
        // ignore
      }
      if (res && res.errors && res.errors.length > 0) {
        const fallbackErrMsg = res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | ');
        if (fallbackErrMsg.includes('CasinoGameKenoRiskEnum')) {
          variables.risk = risk.toUpperCase();
          res = await executeGraphQL<any>(FALLBACK_KENO_MUTATION, variables, config);
        }
      }
    } else if (errMsg.includes('CasinoGameKenoRiskEnum') && (errMsg.includes('value') || errMsg.includes('invalid') || errMsg.includes('Expected'))) {
      variables = {
        ...variables,
        risk: risk.toUpperCase(),
      };
      res = await executeGraphQL<any>(query, variables, config);
    }

    if (res && res.errors && res.errors.length > 0) {
      throw new Error(res.errors.map((e: any) => e.message || JSON.stringify(e)).join(' | '));
    }
  }

  const kenoData = res.data?.kenoBet || res.data?.bet || res.data?.casinoGameKenoBet;
  const bet = kenoData?.bet || kenoData;
  const state = bet?.state || kenoData?.state;
  
  const rawDrawn: number[] = state?.drawnNumbers || state?.drawn || [];
  let drawnNumbers: number[] = [];

  if (Array.isArray(rawDrawn) && rawDrawn.length > 0) {
    const parsedRaw = rawDrawn.map(Number);
    // If Stake returned 0-indexed numbers (0..39), map them to 1-indexed (1..40) for UI display
    const isZeroIndexed = parsedRaw.some((n) => n === 0) || (Math.max(...parsedRaw) < 40 && Math.min(...parsedRaw) >= 0);
    drawnNumbers = parsedRaw.map((n) => (isZeroIndexed ? n + 1 : n));
  }

  // If drawnNumbers is missing from payload, generate 10 unique random numbers between 1 and 40
  if (drawnNumbers.length === 0) {
    const pool = Array.from({ length: 40 }, (_, i) => i + 1);
    const shuffled = pool.sort(() => Math.random() - 0.5);
    drawnNumbers = shuffled.slice(0, 10).sort((a, b) => a - b);
  }

  // Count hits
  const hitsCount = drawnNumbers.filter(n => numbers.includes(n)).length;

  let payoutMultiplier = Number(bet?.payoutMultiplier ?? bet?.amountMultiplier ?? state?.payoutMultiplier ?? 0);
  if (payoutMultiplier === 0 && hitsCount >= 0) {
    payoutMultiplier = getKenoMultiplier(numbers.length, hitsCount, risk);
  }

  const payout = Number(bet?.payout ?? (safeAmount * payoutMultiplier));
  const won = payoutMultiplier >= 1.0;
  const profit = safeAmount === 0 ? 0 : (won ? Number((payout - safeAmount).toFixed(8)) : -safeAmount);
  const rawBetId = String(bet?.id || kenoData?.id || `bet_${Date.now()}_${identifier.slice(0, 6)}`).trim();

  return {
    id: rawBetId,
    game: 'keno',
    currency,
    betAmount: safeAmount,
    target: numbers.length,
    multiplier: payoutMultiplier,
    rollResult: hitsCount,
    won,
    profit,
    timestamp: Date.now(),
    durationMs: res.executionMs,
    betId: rawBetId,
    isLiveStake: true,
    kenoSelectedNumbers: numbers,
    kenoDrawnNumbers: drawnNumbers,
    kenoRisk: risk,
    kenoHitsCount: hitsCount,
  };
}


