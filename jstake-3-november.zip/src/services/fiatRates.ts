// Exchange rates & currency list service for Stake Client

export interface CurrencyMetadata {
  code: string;
  name: string;
  symbol: string;
  decimals: number;
}

// Exactly the user's requested crypto list on Stake
export const STAKE_CRYPTO_LIST: CurrencyMetadata[] = [
  { code: 'btc', name: 'Bitcoin', symbol: 'BTC', decimals: 8 },
  { code: 'eth', name: 'Ethereum', symbol: 'ETH', decimals: 8 },
  { code: 'ltc', name: 'Litecoin', symbol: 'LTC', decimals: 8 },
  { code: 'sol', name: 'Solana', symbol: 'SOL', decimals: 6 },
  { code: 'doge', name: 'Dogecoin', symbol: 'DOGE', decimals: 2 },
  { code: 'bch', name: 'Bitcoin Cash', symbol: 'BCH', decimals: 8 },
  { code: 'xrp', name: 'Ripple', symbol: 'XRP', decimals: 4 },
  { code: 'trx', name: 'TRON', symbol: 'TRX', decimals: 4 },
  { code: 'eos', name: 'EOS', symbol: 'EOS', decimals: 4 },
  { code: 'bnb', name: 'Binance Coin', symbol: 'BNB', decimals: 6 },
  { code: 'usdt', name: 'Tether', symbol: 'USDT', decimals: 4 },
  { code: 'usdc', name: 'USD Coin', symbol: 'USDC', decimals: 4 },
  { code: 'ape', name: 'ApeCoin', symbol: 'APE', decimals: 4 },
  { code: 'busd', name: 'Binance USD', symbol: 'BUSD', decimals: 4 },
  { code: 'cro', name: 'Cronos', symbol: 'CRO', decimals: 4 },
  { code: 'dai', name: 'Dai', symbol: 'DAI', decimals: 4 },
  { code: 'link', name: 'Chainlink', symbol: 'LINK', decimals: 4 },
  { code: 'sand', name: 'The Sandbox', symbol: 'SAND', decimals: 4 },
  { code: 'shib', name: 'Shiba Inu', symbol: 'SHIB', decimals: 0 },
  { code: 'uni', name: 'Uniswap', symbol: 'UNI', decimals: 4 },
  { code: 'pol', name: 'Polygon Ecosystem', symbol: 'POL', decimals: 4 },
  { code: 'trump', name: 'Official Trump', symbol: 'TRUMP', decimals: 4 },
];

// Fiat currencies supported on Stake
export const STAKE_FIAT_LIST: CurrencyMetadata[] = [
  { code: 'idr', name: 'Indonesian Rupiah', symbol: 'Rp', decimals: 0 },
  { code: 'usd', name: 'US Dollar', symbol: '$', decimals: 2 },
  { code: 'eur', name: 'Euro', symbol: '€', decimals: 2 },
  { code: 'jpy', name: 'Japanese Yen', symbol: '¥', decimals: 0 },
  { code: 'brl', name: 'Brazilian Real', symbol: 'R$', decimals: 2 },
  { code: 'cad', name: 'Canadian Dollar', symbol: 'CA$', decimals: 2 },
  { code: 'inr', name: 'Indian Rupee', symbol: '₹', decimals: 2 },
  { code: 'php', name: 'Philippine Peso', symbol: '₱', decimals: 2 },
  { code: 'ars', name: 'Argentine Peso', symbol: 'ARS$', decimals: 0 },
  { code: 'clp', name: 'Chilean Peso', symbol: 'CLP$', decimals: 0 },
  { code: 'pen', name: 'Peruvian Sol', symbol: 'S/.', decimals: 2 },
  { code: 'mxn', name: 'Mexican Peso', symbol: 'MX$', decimals: 2 },
  { code: 'try', name: 'Turkish Lira', symbol: '₺', decimals: 2 },
];

export function isCryptoCode(code: string): boolean {
  return STAKE_CRYPTO_LIST.some((c) => c.code.toLowerCase() === code.toLowerCase());
}

export function isFiatCode(code: string): boolean {
  return STAKE_FIAT_LIST.some((c) => c.code.toLowerCase() === code.toLowerCase());
}

// Fallback Crypto prices in USD
const BASE_USD_PRICES: Record<string, number> = {
  usdt: 1.0,
  usdc: 1.0,
  busd: 1.0,
  dai: 1.0,
  usd: 1.0,
  btc: 89000.0,
  eth: 2950.0,
  sol: 185.0,
  bnb: 625.0,
  ltc: 85.0,
  doge: 0.175,
  trx: 0.205,
  xrp: 0.88,
  bch: 420.0,
  pol: 0.45,
  link: 14.5,
  shib: 0.000022,
  uni: 8.5,
  eos: 0.65,
  ape: 1.1,
  cro: 0.12,
  sand: 0.35,
  trump: 16.5,
};

// Rates from 1 USD to Target Fiat
const BASE_FIAT_RATES_FROM_USD: Record<string, number> = {
  usd: 1.0,
  idr: 16100.0,
  eur: 0.925,
  jpy: 152.0,
  brl: 5.8,
  cad: 1.39,
  inr: 84.5,
  php: 58.5,
  ars: 1020.0,
  clp: 970.0,
  pen: 3.75,
  mxn: 20.3,
  try: 34.5,
};

class FiatRatesManager {
  private cryptoPricesInUsd: Record<string, number> = { ...BASE_USD_PRICES };
  private fiatRatesFromUsd: Record<string, number> = { ...BASE_FIAT_RATES_FROM_USD };
  private lastFetchTime: number = 0;

  constructor() {
    this.refreshRates().catch(() => {});
  }

  async refreshRates() {
    if (Date.now() - this.lastFetchTime < 10 * 60 * 1000) return;
    try {
      const res = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,litecoin,tether,dogecoin,ripple,binancecoin,solana,tron,usd-coin,cardano,chainlink,uniswap,bitcoin-cash,maga&vs_currencies=usd,idr,eur,jpy,brl,cad,inr,php'
      );
      if (res.ok) {
        const data = await res.json();
        if (data.bitcoin?.usd) this.cryptoPricesInUsd.btc = data.bitcoin.usd;
        if (data.ethereum?.usd) this.cryptoPricesInUsd.eth = data.ethereum.usd;
        if (data.litecoin?.usd) this.cryptoPricesInUsd.ltc = data.litecoin.usd;
        if (data.dogecoin?.usd) this.cryptoPricesInUsd.doge = data.dogecoin.usd;
        if (data.solana?.usd) this.cryptoPricesInUsd.sol = data.solana.usd;
        if (data.ripple?.usd) this.cryptoPricesInUsd.xrp = data.ripple.usd;
        if (data.binancecoin?.usd) this.cryptoPricesInUsd.bnb = data.binancecoin.usd;
        if (data.tron?.usd) this.cryptoPricesInUsd.trx = data.tron.usd;
        if (data['bitcoin-cash']?.usd) this.cryptoPricesInUsd.bch = data['bitcoin-cash'].usd;
        if (data.maga?.usd) this.cryptoPricesInUsd.trump = data.maga.usd;

        // Fetch USD to Fiat ratios via USDT
        if (data.tether?.idr) this.fiatRatesFromUsd.idr = data.tether.idr;
        if (data.tether?.eur) this.fiatRatesFromUsd.eur = data.tether.eur;
        if (data.tether?.jpy) this.fiatRatesFromUsd.jpy = data.tether.jpy;
        if (data.tether?.brl) this.fiatRatesFromUsd.brl = data.tether.brl;
        if (data.tether?.cad) this.fiatRatesFromUsd.cad = data.tether.cad;
        if (data.tether?.inr) this.fiatRatesFromUsd.inr = data.tether.inr;
        if (data.tether?.php) this.fiatRatesFromUsd.php = data.tether.php;

        this.lastFetchTime = Date.now();
      }
    } catch {
      // Use fallback base rates
    }
  }

  getFiatValue(amount: number, cryptoCurrency: string, targetFiat: string): number {
    const cur = cryptoCurrency.toLowerCase();
    const target = targetFiat.toLowerCase();

    // Value in USD
    let valueInUsd = amount;
    if (this.cryptoPricesInUsd[cur] !== undefined) {
      valueInUsd = amount * this.cryptoPricesInUsd[cur];
    } else if (this.fiatRatesFromUsd[cur] !== undefined) {
      // If current coin is already a fiat, convert fiat to USD
      valueInUsd = amount / this.fiatRatesFromUsd[cur];
    }

    if (target === 'usd') {
      return valueInUsd;
    }

    const rate = this.fiatRatesFromUsd[target] ?? 1.0;
    return valueInUsd * rate;
  }

  getCryptoFromFiat(fiatAmount: number, targetFiat: string, cryptoCurrency: string): number {
    if (!fiatAmount || fiatAmount <= 0) return 0;
    const cur = cryptoCurrency.toLowerCase();
    const target = targetFiat.toLowerCase();

    // If both are the exact same currency (e.g. user selected IDR or USD as their Stake balance)
    if (cur === target) return fiatAmount;

    // Convert target fiat to USD
    const fiatRateFromUsd = this.fiatRatesFromUsd[target] ?? 1.0;
    const valueInUsd = fiatAmount / fiatRateFromUsd;

    // Convert USD to crypto
    const cryptoPriceInUsd = this.cryptoPricesInUsd[cur] ?? 1.0;
    const cryptoAmount = valueInUsd / cryptoPriceInUsd;

    // Format with maximum precision up to 8 decimals
    const cryptoMeta = STAKE_CRYPTO_LIST.find((c) => c.code.toLowerCase() === cur);
    const decimals = cryptoMeta ? Math.max(cryptoMeta.decimals, 8) : 8;
    return Number(cryptoAmount.toFixed(decimals));
  }

  formatFiat(
    amount: number,
    cryptoCurrency: string,
    targetFiat: string,
    enabled: boolean = true
  ): string {
    if (!enabled || !amount) return '';
    const cur = cryptoCurrency.toLowerCase();
    const target = targetFiat.toLowerCase();

    const targetMeta = STAKE_FIAT_LIST.find((f) => f.code.toLowerCase() === target) || {
      code: target,
      name: target.toUpperCase(),
      symbol: target.toUpperCase(),
      decimals: 2,
    };

    // If currency is already target fiat, format directly
    if (cur === target) {
      if (target === 'idr') {
        return `Rp ${Math.round(amount).toLocaleString('id-ID')}`;
      }
      return `${targetMeta.symbol} ${amount.toLocaleString(undefined, {
        minimumFractionDigits: targetMeta.decimals,
        maximumFractionDigits: targetMeta.decimals,
      })}`;
    }

    const val = this.getFiatValue(amount, cryptoCurrency, target);

    if (target === 'idr') {
      return `≈ Rp ${Math.round(val).toLocaleString('id-ID')}`;
    }

    if (targetMeta.decimals === 0) {
      return `≈ ${targetMeta.symbol} ${Math.round(val).toLocaleString()}`;
    }

    return `≈ ${targetMeta.symbol} ${val.toLocaleString(undefined, {
      minimumFractionDigits: targetMeta.decimals,
      maximumFractionDigits: val < 1 ? 4 : targetMeta.decimals,
    })}`;
  }
}

export const fiatRates = new FiatRatesManager();

export function getEstimatedFiatValue(
  amount: number,
  cryptoCurrency: string,
  targetFiat: string
): string {
  return fiatRates.formatFiat(amount, cryptoCurrency, targetFiat, true);
}
