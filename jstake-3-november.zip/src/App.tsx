/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Header } from './components/Header';
import { DiceGame } from './components/DiceGame';
import { LimboGame } from './components/LimboGame';
import { PlinkoGame } from './components/PlinkoGame';
import { MinesGame } from './components/MinesGame';
import { DiamondsGame } from './components/DiamondsGame';
import { KenoGame } from './components/KenoGame';

import { LiveTriggers } from './components/LiveTriggers';
import { LiveResultCard } from './components/LiveResultCard';
import { BetHistory } from './components/BetHistory';
import { SettingsModal } from './components/SettingsModal';
import { SeedModal } from './components/SeedModal';
import { TokenRequiredScreen } from './components/TokenRequiredScreen';
import { GameLobby } from './components/GameLobby';
import { ToastContainer, ToastData } from './components/Toast';
import { AutobetConfig, BatchProgress, BetResult, DiceCondition, GameType, KenoRisk, PlinkoRisk, PlinkoRows, RoutingMode, SessionStats, StakeConfig, StrategySwitchRule, DiceSavedStrategy, LimboSavedStrategy, PlinkoSavedStrategy, MinesSavedStrategy, KenoSavedStrategy, SavedStrategy } from './types/stake';
import {
  fetchUserBalances,
  playDice,
  playLimbo,
  playPlinko,
  playDiamonds,
  playKeno,
  playMinesAutoBet,
  sanitizeBetAmount,
} from './services/stakeApi';
import { AlertCircle, X, ChevronLeft, Gem, Dices, Rocket, CircleDot, Bomb, Grid } from 'lucide-react';

const CONFIG_STORAGE_KEY = 'stake_client_config';
const HISTORY_STORAGE_KEY = 'stake_client_bet_history';
const STATS_STORAGE_KEY = 'stake_client_session_stats';
const CHART_STORAGE_KEY = 'stake_client_chart_history';
const TRIGGERS_STORAGE_KEY = 'stake_client_triggers';

const DEFAULT_SESSION_STATS: SessionStats = {
  totalBets: 0,
  wins: 0,
  losses: 0,
  totalWagered: 0,
  totalWonCurrency: 0,
  totalLostCurrency: 0,
  netProfit: 0,
  winRate: 0,
};

const DEFAULT_CONFIG: StakeConfig = {
  token: '',
  endpoint: 'https://stake.bet/_api/graphql',
  cookie: '',
  currency: 'btc',
  routingMode: 'cors-proxy',
  corsProxyUrl: 'https://corsproxy.io/?url=',
  houseEdgePercent: 1.0,
  hideZeroBalances: false,
};

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

type ViewMode = 'token-gate' | 'lobby' | 'dice' | 'limbo' | 'plinko' | 'mines' | 'diamonds' | 'keno' | 'dragontower';

export default function App() {
  const [config, setConfig] = useState<StakeConfig>(() => {
    try {
      const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.diceQueryOverride && (parsed.diceQueryOverride.includes('bet {') || parsed.diceQueryOverride.includes('iid'))) {
          delete parsed.diceQueryOverride;
        }
        if (parsed.limboQueryOverride && (parsed.limboQueryOverride.includes('bet {') || parsed.limboQueryOverride.includes('iid'))) {
          delete parsed.limboQueryOverride;
        }
        if (parsed.balanceQueryOverride && (parsed.balanceQueryOverride.includes('vipLevel') || parsed.balanceQueryOverride.includes('vipProgress') || parsed.balanceQueryOverride.includes('vip {'))) {
          delete parsed.balanceQueryOverride;
        }
        if (parsed.kenoQueryOverride && (parsed.kenoQueryOverride.includes('payoutMultiplier') || parsed.kenoQueryOverride.includes('numbers') || parsed.kenoQueryOverride.includes('bet {'))) {
          delete parsed.kenoQueryOverride;
        }

        return { ...DEFAULT_CONFIG, ...parsed };
      }
    } catch {
      // fallback
    }
    return DEFAULT_CONFIG;
  });

  const hasToken = Boolean(config.token && config.token.trim().length > 0);

  // View state mode
  const [selectedGame, setSelectedGame] = useState<GameType | null>(null);

  const [currency, setCurrency] = useState<string>(() => (config.currency || 'btc').toLowerCase());
  const [userBalances, setUserBalances] = useState<Record<string, number>>({});
  const [username, setUsername] = useState<string>('');
  const [isRefreshingBalance, setIsRefreshingBalance] = useState<boolean>(false);

  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [lastBet, setLastBet] = useState<BetResult | null>(null);

  // Toast notification state
  const [toasts, setToasts] = useState<ToastData[]>([]);

  const addToast = useCallback((title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newToast: ToastData = { id, title, status, message };
    setToasts((prev) => {
      const next = [...prev, newToast];
      // Batasi hanya ada maksimal 2 notifikasi bersamaan agar web tetap ringan
      return next.slice(-2);
    });

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const [historyLimit, setHistoryLimit] = useState<10 | 20>(() => config.historyLimit ?? 20);

  const [history, setHistory] = useState<BetResult[]>(() => {
    try {
      const stored = localStorage.getItem(HISTORY_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          return parsed.slice(0, 1000);
        }
      }
    } catch {
      // fallback
    }
    return [];
  });

  const [sessionStats, setSessionStats] = useState<SessionStats>(() => {
    try {
      const stored = localStorage.getItem(STATS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed.totalBets === 'number') {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return DEFAULT_SESSION_STATS;
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isSeedModalOpen, setIsSeedModalOpen] = useState<boolean>(false);
  const [clientSeed, setClientSeed] = useState<string>(() => {
    try {
      return localStorage.getItem('stake_client_seed') || 'jstkbot_client_seed_x9a82';
    } catch {
      return 'jstkbot_client_seed_x9a82';
    }
  });
  const [serverSeedHash, setServerSeedHash] = useState<string>(() => {
    try {
      return localStorage.getItem('stake_server_seed_hash') || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
    } catch {
      return 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
    }
  });
  const [seedNonce, setSeedNonce] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('stake_seed_nonce') || '1', 10);
    } catch {
      return 1;
    }
  });

  const handleSaveNewClientSeed = (newSeed: string) => {
    setClientSeed(newSeed);
    try {
      localStorage.setItem('stake_client_seed', newSeed);
    } catch {}
    addToast('Seed Provably Fair', 'ON', `Client seed baru disimpan: ${newSeed}`);
  };

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [chartHistory, setChartHistory] = useState<number[]>(() => {
    try {
      const stored = localStorage.getItem(CHART_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // fallback
    }
    return [0];
  });

  // Quick Stop Triggers (Real-time live toggleable at any time)
  const [stopOnWin, setStopOnWin] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(TRIGGERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return !!parsed.stopOnWin;
      }
    } catch {}
    return false;
  });
  const [stopOnLoss, setStopOnLoss] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(TRIGGERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return !!parsed.stopOnLoss;
      }
    } catch {}
    return false;
  });
  const stopOnWinRef = useRef<boolean>(stopOnWin);
  stopOnWinRef.current = stopOnWin;
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  stopOnLossRef.current = stopOnLoss;

  // Lose streak & win streak trigger states
  const [stopLoseStreak, setStopLoseStreak] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(TRIGGERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return typeof parsed.stopLoseStreak === 'number' ? parsed.stopLoseStreak : 0;
      }
    } catch {}
    return 0;
  });
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);
  stopLoseStreakRef.current = stopLoseStreak;

  const [stopWinStreak, setStopWinStreak] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(TRIGGERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return typeof parsed.stopWinStreak === 'number' ? parsed.stopWinStreak : 0;
      }
    } catch {}
    return 0;
  });
  const stopWinStreakRef = useRef<number>(stopWinStreak);
  stopWinStreakRef.current = stopWinStreak;

  // Dedicated Triggers State for Switch Strategy Mode
  const [switchStopOnWin, setSwitchStopOnWin] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('stake_switch_triggers_config');
      if (stored) {
        const parsed = JSON.parse(stored);
        return !!parsed.stopOnWin;
      }
    } catch {}
    return false;
  });
  const [switchStopOnLoss, setSwitchStopOnLoss] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('stake_switch_triggers_config');
      if (stored) {
        const parsed = JSON.parse(stored);
        return !!parsed.stopOnLoss;
      }
    } catch {}
    return false;
  });
  const switchStopOnWinRef = useRef<boolean>(switchStopOnWin);
  switchStopOnWinRef.current = switchStopOnWin;
  const switchStopOnLossRef = useRef<boolean>(switchStopOnLoss);
  switchStopOnLossRef.current = switchStopOnLoss;

  const [switchStopLoseStreak, setSwitchStopLoseStreak] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('stake_switch_triggers_config');
      if (stored) {
        const parsed = JSON.parse(stored);
        return typeof parsed.stopLoseStreak === 'number' ? parsed.stopLoseStreak : 0;
      }
    } catch {}
    return 0;
  });
  const switchStopLoseStreakRef = useRef<number>(switchStopLoseStreak);
  switchStopLoseStreakRef.current = switchStopLoseStreak;

  const [switchStopWinStreak, setSwitchStopWinStreak] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('stake_switch_triggers_config');
      if (stored) {
        const parsed = JSON.parse(stored);
        return typeof parsed.stopWinStreak === 'number' ? parsed.stopWinStreak : 0;
      }
    } catch {}
    return 0;
  });
  const switchStopWinStreakRef = useRef<number>(switchStopWinStreak);
  switchStopWinStreakRef.current = switchStopWinStreak;

  useEffect(() => {
    localStorage.setItem(
      'stake_switch_triggers_config',
      JSON.stringify({
        stopOnWin: switchStopOnWin,
        stopOnLoss: switchStopOnLoss,
        stopLoseStreak: switchStopLoseStreak,
        stopWinStreak: switchStopWinStreak,
      })
    );
  }, [switchStopOnWin, switchStopOnLoss, switchStopLoseStreak, switchStopWinStreak]);

  // Live streak tracker (e.g. 5x lose or 3x win)
  const [currentStreak, setCurrentStreak] = useState<{ type: 'win' | 'loss' | 'none'; count: number }>({
    type: 'none',
    count: 0,
  });

  // Live Batch / Multi-bet progress tracker
  const [batchProgress, setBatchProgress] = useState<BatchProgress | null>(null);

  const [autobetRunning, setAutobetRunning] = useState<boolean>(false);
  const autobetRunningRef = useRef<boolean>(false);
  autobetRunningRef.current = autobetRunning;


  const currentBalance = userBalances[currency.toLowerCase()] ?? 0;
  const currentBalanceRef = useRef<number>(currentBalance);
  currentBalanceRef.current = currentBalance;

  // Sync mutex lock to prevent accidental double-bet clicks on manual rolls
  const isExecutingManualBetRef = useRef<boolean>(false);

  // Unload protection while autobet is running to protect active sessions
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (autobetRunningRef.current) {
        e.preventDefault();
        e.returnValue = 'Auto bet sedang berjalan! Apakah Anda yakin ingin keluar atau me-refresh halaman?';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  // Compute view mode cleanly
  const viewMode: ViewMode = !hasToken ? 'token-gate' : selectedGame === null ? 'lobby' : selectedGame;

  // Explicitly scroll to top when switching games to prevent auto-scrolling to bottom on mobile
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [selectedGame]);

  // Toggle History & Statistics box
  const [showHistoryStats, setShowHistoryStats] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('stake_client_show_stats');
      return stored === 'true';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('stake_client_show_stats', String(showHistoryStats));
    } catch {}
  }, [showHistoryStats]);

  const handleToggleShowStats = useCallback(() => {
    setShowHistoryStats((prev) => !prev);
  }, []);

  const handleCurrencyChange = (newCurrency: string) => {
    const cur = newCurrency.toLowerCase();
    setCurrency(cur);
    const updated: StakeConfig = { ...config, currency: cur };
    setConfig(updated);
    try {
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleSaveConfig = (newConfig: StakeConfig) => {
    const activeCurrency = (newConfig.currency || currency).toLowerCase();
    const finalConfig: StakeConfig = {
      ...newConfig,
      currency: activeCurrency,
    };
    setConfig(finalConfig);
    setCurrency(activeCurrency);
    try {
      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(finalConfig));
    } catch {
      // ignore
    }
  };

  const handleInitialTokenSave = (token: string, endpoint: string, routingMode: RoutingMode) => {
    const updated: StakeConfig = {
      ...config,
      token,
      endpoint,
      routingMode,
      currency,
    };
    handleSaveConfig(updated);
    addToast('Koneksi Stake', 'ON', 'Berhasil menghubungkan token API');
    setSelectedGame(null);
  };

  const handleDisconnect = () => {
    stopAutobet();
    const cleared: StakeConfig = {
      ...config,
      token: '',
      currency,
    };
    handleSaveConfig(cleared);
    setUserBalances({});
    setUsername('');
    setLastBet(null);
    setSelectedGame(null);
    addToast('Koneksi Stake', 'OFF', 'Token berhasil diputuskan');
  };

  const handleHistoryLimitChange = (newLimit: 10 | 20) => {
    setHistoryLimit(newLimit);
    setHistory((prev) => {
      const trimmed = prev.slice(0, newLimit);
      try {
        localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(trimmed));
      } catch {
        // ignore
      }
      return trimmed;
    });
    const updated: StakeConfig = { ...config, historyLimit: newLimit };
    handleSaveConfig(updated);
    addToast('Batas Riwayat', 'ON', `Riwayat dibatasi maks ${newLimit} data untuk menjaga memori tetap ringan.`);
  };

  // Quick toggle: Sembunyikan saldo nol
  const handleToggleHideZeroBalances = () => {
    const next = !(config.hideZeroBalances ?? false);
    const updated: StakeConfig = {
      ...config,
      currency,
      hideZeroBalances: next,
    };
    handleSaveConfig(updated);
    addToast(
      'Sembunyikan Saldo Nol',
      next ? 'ON' : 'OFF',
      next ? 'Hanya mata uang dengan saldo > 0 yang ditampilkan' : 'Semua mata uang ditampilkan'
    );
  };

  const loadBalances = useCallback(async () => {
    if (!config.token || config.token.trim().length === 0) return;
    setIsRefreshingBalance(true);
    try {
      const data = await fetchUserBalances(config);
      setUserBalances(data.balances);
      setUsername(data.username);
      setErrorMessage(null);
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal memuat saldo dari Stake');
    } finally {
      setIsRefreshingBalance(false);
    }
  }, [config]);

  useEffect(() => {
    if (hasToken) {
      loadBalances();
    }
  }, [hasToken, loadBalances]);

  // Persist triggers
  useEffect(() => {
    localStorage.setItem(
      TRIGGERS_STORAGE_KEY,
      JSON.stringify({
        stopOnWin,
        stopOnLoss,
        stopLoseStreak,
        stopWinStreak,
      })
    );
  }, [stopOnWin, stopOnLoss, stopLoseStreak, stopWinStreak]);

  const handleToggleStopOnWin = (val: boolean) => {
    setStopOnWin(val);
    addToast('Stop on Win', val ? 'ON' : 'OFF', val ? 'Pemicu aktif: Berhenti saat menang.' : 'Pemicu dinonaktifkan.');
  };

  const handleToggleStopOnLoss = (val: boolean) => {
    setStopOnLoss(val);
    addToast('Stop on Loss', val ? 'ON' : 'OFF', val ? 'Pemicu aktif: Berhenti saat kalah.' : 'Pemicu dinonaktifkan.');
  };

  const handleStopLoseStreakChange = (val: number) => {
    setStopLoseStreak(val);
    if (val > 0) {
      addToast('Stop Lose Streak', 'ON', `Berhenti otomatis setelah ${val}× kalah beruntun.`);
    } else {
      addToast('Stop Lose Streak', 'OFF', 'Pemicu dinonaktifkan.');
    }
  };

  const isSwitchActive = useMemo(() => {
    if (!selectedGame) return false;
    try {
      return localStorage.getItem(`jstkbot_${selectedGame}_switch_rules_enabled`) === 'true';
    } catch {
      return false;
    }
  }, [selectedGame, autobetRunning]);

  const activeStopOnWin = isSwitchActive ? switchStopOnWin : stopOnWin;
  const activeStopOnLoss = isSwitchActive ? switchStopOnLoss : stopOnLoss;
  const activeStopLoseStreak = isSwitchActive ? switchStopLoseStreak : stopLoseStreak;

  const handleActiveToggleStopOnWin = (val: boolean) => {
    if (isSwitchActive) {
      setSwitchStopOnWin(val);
      switchStopOnWinRef.current = val;
      addToast('Switch Stop on Win', val ? 'ON' : 'OFF', val ? 'Pemicu Switch aktif: Berhenti saat menang.' : 'Pemicu Switch dinonaktifkan.');
    } else {
      handleToggleStopOnWin(val);
    }
  };

  const handleActiveToggleStopOnLoss = (val: boolean) => {
    if (isSwitchActive) {
      setSwitchStopOnLoss(val);
      switchStopOnLossRef.current = val;
      addToast('Switch Stop on Loss', val ? 'ON' : 'OFF', val ? 'Pemicu Switch aktif: Berhenti saat kalah.' : 'Pemicu Switch dinonaktifkan.');
    } else {
      handleToggleStopOnLoss(val);
    }
  };

  const handleActiveStopLoseStreakChange = (val: number) => {
    if (isSwitchActive) {
      setSwitchStopLoseStreak(val);
      switchStopLoseStreakRef.current = val;
      if (val > 0) {
        addToast('Switch Stop Lose Streak', 'ON', `Berhenti otomatis setelah ${val}× kalah beruntun pada mode Switch.`);
      } else {
        addToast('Switch Stop Lose Streak', 'OFF', 'Pemicu Switch dinonaktifkan.');
      }
    } else {
      handleStopLoseStreakChange(val);
    }
  };

  const handleUpdateSingleTriggers = (t: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => {
    if (t.stopOnWin !== undefined) {
      setStopOnWin(t.stopOnWin);
      stopOnWinRef.current = t.stopOnWin;
    }
    if (t.stopOnLoss !== undefined) {
      setStopOnLoss(t.stopOnLoss);
      stopOnLossRef.current = t.stopOnLoss;
    }
    if (t.stopLoseStreak !== undefined) {
      setStopLoseStreak(t.stopLoseStreak);
      stopLoseStreakRef.current = t.stopLoseStreak;
    }
    if (t.stopWinStreak !== undefined) {
      setStopWinStreak(t.stopWinStreak);
      stopWinStreakRef.current = t.stopWinStreak;
    }
  };


  const lastLocalStorageSaveRef = useRef<number>(0);
  const lastUiUpdateRef = useRef<number>(0);

  const recordBet = (bet: BetResult) => {
    setLastBet(bet);

    // Update real-time live streak
    setCurrentStreak((prev) => {
      if (bet.won) {
        return {
          type: 'win',
          count: prev.type === 'win' ? prev.count + 1 : 1,
        };
      } else {
        return {
          type: 'loss',
          count: prev.type === 'loss' ? prev.count + 1 : 1,
        };
      }
    });

    // Optimistic balance update for instant responsiveness
    setUserBalances((prev) => {
      const cur = bet.currency.toLowerCase();
      const prevBal = prev[cur] ?? 0;
      const updatedBal = Math.max(0, Number((prevBal + bet.profit).toFixed(8)));
      return { ...prev, [cur]: updatedBal };
    });

    const now = Date.now();
    const shouldSaveStorage = !autobetRunningRef.current || now - lastLocalStorageSaveRef.current > 1000;
    if (shouldSaveStorage) {
      lastLocalStorageSaveRef.current = now;
    }

    setHistory((prev) => {
      // Buffer larger history (1000) in RAM to allow better filtering (Menang/Kalah)
      // This satisfies user request #7/8 where filtering resulted in too few items
      const maxToBuffer = 1000;
      const updated = [bet, ...prev].slice(0, maxToBuffer);

      if (shouldSaveStorage) {
        try {
          // Save up to 40 latest bets to localStorage for better cross-session persistence
          localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated.slice(0, 40)));
        } catch {
          // ignore
        }
      }
      return updated;
    });

    setChartHistory((prev) => {
      const lastVal = prev[prev.length - 1] || 0;
      const newVal = Number((lastVal + bet.profit).toFixed(8));
      // Capped at 500 points to keep sparkline SVG lightweight and eliminate memory leaks
      const updated = [...prev, newVal].slice(-500);
      if (shouldSaveStorage) {
        try {
          localStorage.setItem(CHART_STORAGE_KEY, JSON.stringify(updated));
        } catch {
          // ignore
        }
      }
      return updated;
    });

    // Update cumulative session stats so stats are NEVER lost when history items are trimmed
    setSessionStats((prev) => {
      const totalBets = prev.totalBets + 1;
      const wins = prev.wins + (bet.won ? 1 : 0);
      const losses = prev.losses + (bet.won ? 0 : 1);
      const totalWagered = Number((prev.totalWagered + bet.betAmount).toFixed(8));
      const totalWonCurrency = Number((prev.totalWonCurrency + (bet.won ? bet.profit : 0)).toFixed(8));
      const totalLostCurrency = Number((prev.totalLostCurrency + (bet.won ? 0 : bet.betAmount)).toFixed(8));
      const netProfit = Number((prev.netProfit + bet.profit).toFixed(8));
      const winRate = Number(((wins / totalBets) * 100).toFixed(1));

      const updated: SessionStats = {
        totalBets,
        wins,
        losses,
        totalWagered,
        totalWonCurrency,
        totalLostCurrency,
        netProfit,
        winRate,
      };

      if (shouldSaveStorage) {
        try {
          localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(updated));
        } catch {
          // ignore
        }
      }

      return updated;
    });

    // Only make additional network request to Stake if not in high-speed autobet AND bet was live on Stake
    if (!autobetRunningRef.current && bet.isLiveStake !== false) {
      loadBalances();
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    setSessionStats(DEFAULT_SESSION_STATS);
    setChartHistory([0]);
    try {
      localStorage.removeItem(HISTORY_STORAGE_KEY);
      localStorage.removeItem(STATS_STORAGE_KEY);
      localStorage.removeItem(CHART_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const handleResetStats = () => {
    setSessionStats(DEFAULT_SESSION_STATS);
    setChartHistory([0]);
    try {
      localStorage.removeItem(STATS_STORAGE_KEY);
      localStorage.removeItem(CHART_STORAGE_KEY);
    } catch {
      // ignore
    }
    addToast('Statistik Direset', 'INFO', 'Live statistik sesi berhasil direset ke 0.');
  };

  const executeDiceBet = async (
    amount: number,
    target: number,
    condition: DiceCondition
  ): Promise<boolean> => {
    if (isRolling || isExecutingManualBetRef.current) return false;

    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return false;
    }

    if (amount > 0 && amount > currentBalanceRef.current) {
      setErrorMessage(`Saldo tidak cukup: Tersedia ${currentBalanceRef.current} ${currency.toUpperCase()}`);
      return false;
    }

    isExecutingManualBetRef.current = true;
    setIsRolling(true);
    setErrorMessage(null);

    try {
      const bet = await playDice(amount, target, condition, currency, config);
      recordBet(bet);
      setIsRolling(false);
      return bet.won;
    } catch (err: any) {
      setIsRolling(false);
      const msg = err.message || 'Dice roll gagal';
      setErrorMessage(msg);
      addToast('Taruhan Gagal', 'OFF', msg);
      return false;
    } finally {
      isExecutingManualBetRef.current = false;
    }
  };

  const executeLimboBet = async (
    amount: number,
    targetMultiplier: number
  ): Promise<boolean> => {
    if (isRolling || isExecutingManualBetRef.current) return false;

    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return false;
    }

    if (amount > 0 && amount > currentBalanceRef.current) {
      setErrorMessage(`Saldo tidak cukup: Tersedia ${currentBalanceRef.current} ${currency.toUpperCase()}`);
      return false;
    }

    isExecutingManualBetRef.current = true;
    setIsRolling(true);
    setErrorMessage(null);

    try {
      const bet = await playLimbo(amount, targetMultiplier, currency, config);
      recordBet(bet);
      setIsRolling(false);
      return bet.won;
    } catch (err: any) {
      setIsRolling(false);
      const msg = err.message || 'Limbo bet gagal';
      setErrorMessage(msg);
      addToast('Taruhan Gagal', 'OFF', msg);
      return false;
    } finally {
      isExecutingManualBetRef.current = false;
    }
  };

  const executePlinkoBet = async (
    amount: number,
    risk: PlinkoRisk,
    rows: PlinkoRows
  ): Promise<boolean> => {
    if (isRolling || isExecutingManualBetRef.current) return false;

    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return false;
    }

    if (amount > 0 && amount > currentBalanceRef.current) {
      setErrorMessage(`Saldo tidak cukup: Tersedia ${currentBalanceRef.current} ${currency.toUpperCase()}`);
      return false;
    }

    isExecutingManualBetRef.current = true;
    setIsRolling(true);
    setErrorMessage(null);

    try {
      const bet = await playPlinko(amount, risk, rows, currency, config);
      recordBet(bet);
      setIsRolling(false);
      return bet.won;
    } catch (err: any) {
      setIsRolling(false);
      const msg = err.message || 'Plinko bet gagal';
      setErrorMessage(msg);
      addToast('Taruhan Gagal', 'OFF', msg);
      return false;
    } finally {
      isExecutingManualBetRef.current = false;
    }
  };

  const executeDiamondsBet = async (amount: number): Promise<boolean> => {
    if (isRolling || isExecutingManualBetRef.current) return false;

    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return false;
    }

    if (amount > 0 && amount > currentBalanceRef.current) {
      setErrorMessage(`Saldo tidak cukup: Tersedia ${currentBalanceRef.current} ${currency.toUpperCase()}`);
      return false;
    }

    isExecutingManualBetRef.current = true;
    setIsRolling(true);
    setErrorMessage(null);

    try {
      const bet = await playDiamonds(amount, currency, config);
      recordBet(bet);
      setIsRolling(false);
      return bet.won;
    } catch (err: any) {
      setIsRolling(false);
      const msg = err.message || 'Diamonds bet gagal';
      setErrorMessage(msg);
      addToast('Taruhan Gagal', 'OFF', msg);
      return false;
    } finally {
      isExecutingManualBetRef.current = false;
    }
  };

  const executeKenoBet = async (
    amount: number,
    numbers: number[],
    risk: KenoRisk
  ): Promise<boolean> => {
    if (isRolling || isExecutingManualBetRef.current) return false;

    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return false;
    }

    if (amount > 0 && amount > currentBalanceRef.current) {
      setErrorMessage(`Saldo tidak cukup: Tersedia ${currentBalanceRef.current} ${currency.toUpperCase()}`);
      return false;
    }

    isExecutingManualBetRef.current = true;
    setIsRolling(true);
    setErrorMessage(null);

    try {
      const bet = await playKeno(amount, numbers, risk, currency, config);
      recordBet(bet);
      setIsRolling(false);
      return bet.won;
    } catch (err: any) {
      setIsRolling(false);
      const msg = err.message || 'Keno bet gagal';
      setErrorMessage(msg);
      addToast('Taruhan Gagal', 'OFF', msg);
      return false;
    } finally {
      isExecutingManualBetRef.current = false;
    }
  };

  const stopAutobet = () => {
    autobetRunningRef.current = false;
    setAutobetRunning(false);
    loadBalances();
  };

  interface StrategySwitchCheckParams {
    switchRulesEnabled?: boolean;
    switchRules?: StrategySwitchRule[];
    savedStrategies?: any[];
    strategyProfit: number;
    strategyLoss: number;
    strategyWagered: number;
    strategyBets: number;
    consecutiveWins: number;
    consecutiveLosses: number;
  }

  interface SwitchRuleResult {
    matchedRule: StrategySwitchRule;
    targetStrategy: any;
    conditionLabel: string;
  }

  const evaluateStrategySwitch = (params: StrategySwitchCheckParams): SwitchRuleResult | null => {
    if (
      !params.switchRulesEnabled ||
      !params.switchRules ||
      params.switchRules.length === 0 ||
      !params.savedStrategies ||
      params.savedStrategies.length === 0
    ) {
      return null;
    }

    const matched = params.switchRules.find((r) => {
      if (r.enabled === false) return false;
      const thresh = Number(r.threshold) || 0;
      if (thresh <= 0) return false;
      switch (r.conditionType) {
        case 'profit_gte':
          return params.strategyProfit >= thresh;
        case 'loss_gte':
          return params.strategyProfit <= -thresh || params.strategyLoss >= thresh;
        case 'win_streak_gte':
          return params.consecutiveWins >= thresh;
        case 'loss_streak_gte':
          return params.consecutiveLosses >= thresh;
        case 'bets_count_gte':
          return params.strategyBets >= thresh;
        case 'wager_gte':
          return params.strategyWagered >= thresh;
        default:
          return false;
      }
    });

    if (!matched) return null;

    const targetStrat = params.savedStrategies.find((s) => s.id === matched.targetStrategyId);
    if (!targetStrat) return null;

    const conditionLabel =
      matched.conditionType === 'profit_gte'
        ? `Profit ≥ ${matched.threshold}`
        : matched.conditionType === 'loss_gte'
        ? `Drawdown ≥ ${matched.threshold}`
        : matched.conditionType === 'win_streak_gte'
        ? `Win Streak ≥ ${matched.threshold}×`
        : matched.conditionType === 'loss_streak_gte'
        ? `Lose Streak ≥ ${matched.threshold}×`
        : matched.conditionType === 'bets_count_gte'
        ? `Jumlah Bet ≥ ${matched.threshold}`
        : `Total Wager ≥ ${matched.threshold}`;

    return {
      matchedRule: matched,
      targetStrategy: targetStrat,
      conditionLabel,
    };
  };

  const startDiceAutobet = async (
    autoConfig: AutobetConfig,
    target: number,
    condition: DiceCondition
  ) => {
    setAutobetRunning(true);
    autobetRunningRef.current = true;

    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    const maxBetCapInit = autoConfig.maxBetCap || 0;
    if (maxBetCapInit > 0 && currentBetAmount > maxBetCapInit) {
      currentBetAmount = maxBetCapInit;
    }
    let roundsPlayed = 0;
    let runningBalance = currentBalanceRef.current;
    let runningProfit = 0;
    let peakRunningProfit = 0;
    let totalWagered = 0;
    let consecutiveLosses = 0;
    let consecutiveWins = 0;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentTarget = target;
    let currentCondition = condition;
    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: 0,
      totalWagered: 0,
    });

    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: stopOnWinRef.current,
          stopOnLoss: stopOnLossRef.current,
          stopLoseStreak: stopLoseStreakRef.current,
          stopWinStreak: stopWinStreakRef.current,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Live Manual Strategy Switch Detection (User clicked Strategy B while Autobet is running)
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const nextStrat = live.activeStrategy as DiceSavedStrategy;
          currentActiveStrategyId = nextStrat.id;
          activeStrategyName = nextStrat.name;
          currentBaseAmount = sanitizeBetAmount(parseFloat(nextStrat.betAmount) || 0, currency);
          currentBetAmount = currentBaseAmount;
          if (nextStrat.target !== undefined) currentTarget = nextStrat.target;
          if (nextStrat.condition !== undefined) currentCondition = nextStrat.condition;
          currentOnWinAction = nextStrat.onWinAction || 'reset';
          currentOnWinPercent = parseFloat(String(nextStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(nextStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = nextStrat.onLossAction || 'reset';
          currentOnLossPercent = parseFloat(String(nextStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(nextStrat.onLossEveryCount || '1'), 10) || 1;
          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;
          consecutiveWins = 0;
          consecutiveLosses = 0;
          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress((prev) => prev ? { ...prev, activeStrategyName: nextStrat.name } : null);
          addToast('Beralih Strategi', 'ON', `Berpindah ke: "${nextStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : (autoConfig.stopProfit);

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : (autoConfig.stopLoss);

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalanceMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
          addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()} (Batas Saldo: ${stopBalanceMinVal})`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playDice(currentBetAmount, currentTarget, currentCondition, currency, config);
          recordBet(bet);
          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakRunningProfit) {
            peakRunningProfit = runningProfit;
          }
          runningBalance = Math.max(0, Number((runningBalance + bet.profit).toFixed(8)));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit: peakRunningProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops (Always take precedence)
          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
            stopOnWin: stopOnWinRef.current,
            stopOnLoss: stopOnLossRef.current,
            stopLoseStreak: stopLoseStreakRef.current,
            stopWinStreak: stopWinStreakRef.current,
            maxBetCap: autoConfig.maxBetCap,
            maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
            trailingStop: autoConfig.trailingStop,
            stopProfit: 0,
            stopLoss: 0,
          };

          const postTargetProfit = (livePost.stopProfit !== undefined && livePost.stopProfit > 0)
            ? livePost.stopProfit
            : (autoConfig.stopProfit);

          const postTargetLoss = (livePost.stopLoss !== undefined && livePost.stopLoss > 0)
            ? livePost.stopLoss
            : (autoConfig.stopLoss);

          if (postTargetProfit > 0 && runningProfit >= postTargetProfit) {
            addToast(
              'Target Profit Tercapai!',
              'ON',
              `Berhenti: Profit sesi mencapai +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${postTargetProfit})`
            );
            break;
          }

          if (postTargetLoss > 0 && runningProfit <= -postTargetLoss) {
            addToast(
              'Batas Stop Loss Tercapai!',
              'OFF',
              `Berhenti: Drawdown sesi mencapai -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${postTargetLoss})`
            );
            break;
          }

          // Trailing Stop Protection
          const trailingStopVal = (livePost.trailingStop !== undefined && livePost.trailingStop > 0)
            ? livePost.trailingStop
            : (autoConfig.trailingStop || 0);

          if (trailingStopVal > 0 && peakRunningProfit > 0) {
            const drawdownFromPeak = Number((peakRunningProfit - runningProfit).toFixed(8));
            if (drawdownFromPeak >= trailingStopVal) {
              addToast(
                'Trailing Stop: Profit Dikunci!',
                'ON',
                `Keuntungan diamankan! Puncak sesi: +${peakRunningProfit.toFixed(8)}, turun -${drawdownFromPeak.toFixed(8)} (Batas: ${trailingStopVal}). Sisa profit: +${runningProfit.toFixed(8)} ${currency.toUpperCase()}`
              );
              break;
            }
          }

          if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
            addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
            addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          const limitLoseStreak = livePost.stopLoseStreak > 0
            ? livePost.stopLoseStreak
            : ((autoConfig.stopLoseStreak && autoConfig.stopLoseStreak > 0)
              ? autoConfig.stopLoseStreak
              : (autoConfig.maxConsecutiveLosses || 0));

          if (!bet.won && limitLoseStreak > 0 && consecutiveLosses >= limitLoseStreak) {
            addToast(
              'Batas Kalah Beruntun Tercapai!',
              'OFF',
              `Berhenti: Mengalami ${consecutiveLosses}× kekalahan beruntun (Batas: ${limitLoseStreak}×).`
            );
            break;
          }

          const limitWinStreak = livePost.stopWinStreak > 0 ? livePost.stopWinStreak : (autoConfig.stopWinStreak || 0);
          if (bet.won && limitWinStreak > 0 && consecutiveWins >= limitWinStreak) {
            addToast(
              'Pemicu Win Streak Tercapai!',
              'ON',
              `Berhenti: Mencapai ${consecutiveWins}× kemenangan berturut-turut (Batas: ${limitWinStreak}×).`
            );
            break;
          }

          if (bet.won && (stopOnWinRef.current || livePost.stopOnWin)) {
            addToast('Pemicu Win', 'ON', 'Berhenti karena pemicu "Stop on Win" aktif.');
            break;
          }

          if (!bet.won && (stopOnLossRef.current || livePost.stopOnLoss)) {
            addToast('Pemicu Loss', 'OFF', 'Berhenti karena pemicu "Stop on Loss" aktif.');
            break;
          }

          // Evaluate Dynamic Strategy Switch Rules
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast(
              'Pindah Strategi Otomatis',
              'ON',
              `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`
            );

            currentActiveStrategyId = targetStrategy.id;
            activeStrategyName = targetStrategy.name;
            if (targetStrategy.target !== undefined) currentTarget = targetStrategy.target;
            if (targetStrategy.condition !== undefined) currentCondition = targetStrategy.condition;
            currentOnWinAction = targetStrategy.onWinAction || 'reset';
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction || 'reset';
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            currentBaseAmount = sanitizeBetAmount(parseFloat(targetStrategy.betAmount) || 0, currency);
            currentBetAmount = currentBaseAmount;
            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);

            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          // Normal progression if not switched
          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const startLimboAutobet = async (
    autoConfig: AutobetConfig,
    targetMultiplier: number
  ) => {
    setAutobetRunning(true);
    autobetRunningRef.current = true;

    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    const maxBetCapInit = autoConfig.maxBetCap || 0;
    if (maxBetCapInit > 0 && currentBetAmount > maxBetCapInit) {
      currentBetAmount = maxBetCapInit;
    }
    let roundsPlayed = 0;
    let runningBalance = currentBalanceRef.current;
    let runningProfit = 0;
    let peakRunningProfit = 0;
    let totalWagered = 0;
    let consecutiveLosses = 0;
    let consecutiveWins = 0;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentTargetMultiplier = targetMultiplier;
    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: 0,
      totalWagered: 0,
    });

    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: stopOnWinRef.current,
          stopOnLoss: stopOnLossRef.current,
          stopLoseStreak: stopLoseStreakRef.current,
          stopWinStreak: stopWinStreakRef.current,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Live Manual Strategy Switch Detection (User clicked Strategy B while Autobet is running)
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const nextStrat = live.activeStrategy as LimboSavedStrategy;
          currentActiveStrategyId = nextStrat.id;
          activeStrategyName = nextStrat.name;
          currentBaseAmount = sanitizeBetAmount(parseFloat(nextStrat.betAmount) || 0, currency);
          currentBetAmount = currentBaseAmount;
          if (nextStrat.targetMultiplier !== undefined) currentTargetMultiplier = nextStrat.targetMultiplier;
          currentOnWinAction = nextStrat.onWinAction || 'reset';
          currentOnWinPercent = parseFloat(String(nextStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(nextStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = nextStrat.onLossAction || 'reset';
          currentOnLossPercent = parseFloat(String(nextStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(nextStrat.onLossEveryCount || '1'), 10) || 1;
          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;
          consecutiveWins = 0;
          consecutiveLosses = 0;
          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress((prev) => prev ? { ...prev, activeStrategyName: nextStrat.name } : null);
          addToast('Beralih Strategi', 'ON', `Berpindah ke: "${nextStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : (autoConfig.stopProfit);

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : (autoConfig.stopLoss);

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalanceMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
          addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()} (Batas Saldo: ${stopBalanceMinVal})`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playLimbo(currentBetAmount, currentTargetMultiplier, currency, config);
          recordBet(bet);
          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakRunningProfit) {
            peakRunningProfit = runningProfit;
          }
          runningBalance = Math.max(0, Number((runningBalance + bet.profit).toFixed(8)));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit: peakRunningProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops
          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
            stopOnWin: stopOnWinRef.current,
            stopOnLoss: stopOnLossRef.current,
            stopLoseStreak: stopLoseStreakRef.current,
            stopWinStreak: stopWinStreakRef.current,
            maxBetCap: autoConfig.maxBetCap,
            maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
            trailingStop: autoConfig.trailingStop,
            stopProfit: 0,
            stopLoss: 0,
          };

          const postTargetProfit = (livePost.stopProfit !== undefined && livePost.stopProfit > 0)
            ? livePost.stopProfit
            : (autoConfig.stopProfit);

          const postTargetLoss = (livePost.stopLoss !== undefined && livePost.stopLoss > 0)
            ? livePost.stopLoss
            : (autoConfig.stopLoss);

          if (postTargetProfit > 0 && runningProfit >= postTargetProfit) {
            addToast(
              'Target Profit Tercapai!',
              'ON',
              `Berhenti: Profit sesi mencapai +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${postTargetProfit})`
            );
            break;
          }

          if (postTargetLoss > 0 && runningProfit <= -postTargetLoss) {
            addToast(
              'Batas Stop Loss Tercapai!',
              'OFF',
              `Berhenti: Drawdown sesi mencapai -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${postTargetLoss})`
            );
            break;
          }

          // Trailing Stop Protection
          const trailingStopVal = (livePost.trailingStop !== undefined && livePost.trailingStop > 0)
            ? livePost.trailingStop
            : (autoConfig.trailingStop || 0);

          if (trailingStopVal > 0 && peakRunningProfit > 0) {
            const drawdownFromPeak = Number((peakRunningProfit - runningProfit).toFixed(8));
            if (drawdownFromPeak >= trailingStopVal) {
              addToast(
                'Trailing Stop: Profit Dikunci!',
                'ON',
                `Keuntungan diamankan! Puncak sesi: +${peakRunningProfit.toFixed(8)}, turun -${drawdownFromPeak.toFixed(8)} (Batas: ${trailingStopVal}). Sisa profit: +${runningProfit.toFixed(8)} ${currency.toUpperCase()}`
              );
              break;
            }
          }

          if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
            addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
            addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          const limitLoseStreak = livePost.stopLoseStreak > 0
            ? livePost.stopLoseStreak
            : ((autoConfig.stopLoseStreak && autoConfig.stopLoseStreak > 0)
              ? autoConfig.stopLoseStreak
              : (autoConfig.maxConsecutiveLosses || 0));

          if (!bet.won && limitLoseStreak > 0 && consecutiveLosses >= limitLoseStreak) {
            addToast(
              'Batas Kalah Beruntun Tercapai!',
              'OFF',
              `Berhenti: Mengalami ${consecutiveLosses}× kekalahan beruntun (Batas: ${limitLoseStreak}×).`
            );
            break;
          }

          const limitWinStreak = livePost.stopWinStreak > 0 ? livePost.stopWinStreak : (autoConfig.stopWinStreak || 0);
          if (bet.won && limitWinStreak > 0 && consecutiveWins >= limitWinStreak) {
            addToast(
              'Pemicu Win Streak Tercapai!',
              'ON',
              `Berhenti: Mencapai ${consecutiveWins}× kemenangan berturut-turut (Batas: ${limitWinStreak}×).`
            );
            break;
          }

          if (bet.won && (stopOnWinRef.current || livePost.stopOnWin)) {
            addToast('Pemicu Win', 'ON', 'Berhenti karena pemicu "Stop on Win" aktif.');
            break;
          }

          if (!bet.won && (stopOnLossRef.current || livePost.stopOnLoss)) {
            addToast('Pemicu Loss', 'OFF', 'Berhenti karena pemicu "Stop on Loss" aktif.');
            break;
          }

          // Evaluate Strategy Switch
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast(
              'Pindah Strategi Otomatis',
              'ON',
              `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`
            );

            currentActiveStrategyId = targetStrategy.id;
            activeStrategyName = targetStrategy.name;
            if (targetStrategy.targetMultiplier !== undefined) currentTargetMultiplier = targetStrategy.targetMultiplier;
            currentOnWinAction = targetStrategy.onWinAction || 'reset';
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction || 'reset';
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            currentBaseAmount = sanitizeBetAmount(parseFloat(targetStrategy.betAmount) || 0, currency);
            currentBetAmount = currentBaseAmount;
            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);

            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const startPlinkoAutobet = async (
    autoConfig: AutobetConfig,
    risk: PlinkoRisk,
    rows: PlinkoRows
  ) => {
    setAutobetRunning(true);
    autobetRunningRef.current = true;

    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    const maxBetCapInit = autoConfig.maxBetCap || 0;
    if (maxBetCapInit > 0 && currentBetAmount > maxBetCapInit) {
      currentBetAmount = maxBetCapInit;
    }
    let roundsPlayed = 0;
    let runningBalance = currentBalanceRef.current;
    let runningProfit = 0;
    let peakRunningProfit = 0;
    let totalWagered = 0;
    let consecutiveLosses = 0;
    let consecutiveWins = 0;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentRisk = risk;
    let currentRows = rows;
    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: 0,
      totalWagered: 0,
    });

    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran Plinko berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: stopOnWinRef.current,
          stopOnLoss: stopOnLossRef.current,
          stopLoseStreak: stopLoseStreakRef.current,
          stopWinStreak: stopWinStreakRef.current,
          stopHitMultiplier: autoConfig.stopHitMultiplier,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Live Manual Strategy Switch Detection (User clicked Strategy B while Autobet is running)
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const nextStrat = live.activeStrategy as PlinkoSavedStrategy;
          currentActiveStrategyId = nextStrat.id;
          activeStrategyName = nextStrat.name;
          currentBaseAmount = sanitizeBetAmount(parseFloat(nextStrat.betAmount) || 0, currency);
          currentBetAmount = currentBaseAmount;
          if (nextStrat.risk) currentRisk = nextStrat.risk;
          if (nextStrat.rows) currentRows = nextStrat.rows;
          currentOnWinAction = nextStrat.onWinAction || 'reset';
          currentOnWinPercent = parseFloat(String(nextStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(nextStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = nextStrat.onLossAction || 'reset';
          currentOnLossPercent = parseFloat(String(nextStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(nextStrat.onLossEveryCount || '1'), 10) || 1;
          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;
          consecutiveWins = 0;
          consecutiveLosses = 0;
          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress((prev) => prev ? { ...prev, activeStrategyName: nextStrat.name } : null);
          addToast('Beralih Strategi', 'ON', `Berpindah ke: "${nextStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : (autoConfig.stopProfit);

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : (autoConfig.stopLoss);

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalanceMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
          addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()} (Batas Saldo: ${stopBalanceMinVal})`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playPlinko(currentBetAmount, currentRisk, currentRows, currency, config);
          recordBet(bet);
          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakRunningProfit) {
            peakRunningProfit = runningProfit;
          }
          runningBalance = Math.max(0, Number((runningBalance + bet.profit).toFixed(8)));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit: peakRunningProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops
          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
            stopOnWin: stopOnWinRef.current,
            stopOnLoss: stopOnLossRef.current,
            stopLoseStreak: stopLoseStreakRef.current,
            stopWinStreak: stopWinStreakRef.current,
            stopHitMultiplier: autoConfig.stopHitMultiplier,
            maxBetCap: autoConfig.maxBetCap,
            maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
            trailingStop: autoConfig.trailingStop,
            stopProfit: 0,
            stopLoss: 0,
          };

          const postTargetProfit = (livePost.stopProfit !== undefined && livePost.stopProfit > 0)
            ? livePost.stopProfit
            : (autoConfig.stopProfit);

          const postTargetLoss = (livePost.stopLoss !== undefined && livePost.stopLoss > 0)
            ? livePost.stopLoss
            : (autoConfig.stopLoss);

          if (postTargetProfit > 0 && runningProfit >= postTargetProfit) {
            addToast(
              'Target Profit Tercapai!',
              'ON',
              `Berhenti: Profit sesi mencapai +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${postTargetProfit})`
            );
            break;
          }

          if (postTargetLoss > 0 && runningProfit <= -postTargetLoss) {
            addToast(
              'Batas Stop Loss Tercapai!',
              'OFF',
              `Berhenti: Drawdown sesi mencapai -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${postTargetLoss})`
            );
            break;
          }

          // Trailing Stop Protection
          const trailingStopVal = (livePost.trailingStop !== undefined && livePost.trailingStop > 0)
            ? livePost.trailingStop
            : (autoConfig.trailingStop || 0);

          if (trailingStopVal > 0 && peakRunningProfit > 0) {
            const drawdownFromPeak = Number((peakRunningProfit - runningProfit).toFixed(8));
            if (drawdownFromPeak >= trailingStopVal) {
              addToast(
                'Trailing Stop: Profit Dikunci!',
                'ON',
                `Keuntungan diamankan! Puncak sesi: +${peakRunningProfit.toFixed(8)}, turun -${drawdownFromPeak.toFixed(8)} (Batas: ${trailingStopVal}). Sisa profit: +${runningProfit.toFixed(8)} ${currency.toUpperCase()}`
              );
              break;
            }
          }

          if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
            addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
            addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          const limitLoseStreak = livePost.stopLoseStreak > 0
            ? livePost.stopLoseStreak
            : ((autoConfig.stopLoseStreak && autoConfig.stopLoseStreak > 0)
              ? autoConfig.stopLoseStreak
              : (autoConfig.maxConsecutiveLosses || 0));

          if (!bet.won && limitLoseStreak > 0 && consecutiveLosses >= limitLoseStreak) {
            addToast(
              'Batas Kalah Beruntun Tercapai!',
              'OFF',
              `Berhenti: Mengalami ${consecutiveLosses}× kekalahan beruntun (Batas: ${limitLoseStreak}×).`
            );
            break;
          }

          const limitWinStreak = livePost.stopWinStreak > 0 ? livePost.stopWinStreak : (autoConfig.stopWinStreak || 0);
          if (bet.won && limitWinStreak > 0 && consecutiveWins >= limitWinStreak) {
            addToast(
              'Pemicu Win Streak Tercapai!',
              'ON',
              `Berhenti: Mencapai ${consecutiveWins}× kemenangan berturut-turut (Batas: ${limitWinStreak}×).`
            );
            break;
          }

          const targetHitMult = Number(livePost.stopHitMultiplier ?? autoConfig.stopHitMultiplier ?? 0);
          if (targetHitMult > 0 && bet.multiplier >= targetHitMult) {
            const formattedHit = bet.multiplier >= 1000 ? `${bet.multiplier.toLocaleString()}×` : `${bet.multiplier}×`;
            const formattedTarget = targetHitMult >= 1000 ? `${targetHitMult.toLocaleString()}×` : `${targetHitMult}×`;
            addToast(
              'Target Multiplier Tercapai!',
              'ON',
              `Berhenti: Plinko berhasil menghit multiplier ${formattedHit}! (Target: ${formattedTarget})`
            );
            break;
          }

          if (bet.won && (stopOnWinRef.current || live.stopOnWin)) {
            addToast('Pemicu Win', 'ON', 'Berhenti karena pemicu "Stop on Win" aktif.');
            break;
          }

          if (!bet.won && (stopOnLossRef.current || live.stopOnLoss)) {
            addToast('Pemicu Loss', 'OFF', 'Berhenti karena pemicu "Stop on Loss" aktif.');
            break;
          }

          // Evaluate Strategy Switch
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast(
              'Pindah Strategi Otomatis',
              'ON',
              `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`
            );

            currentActiveStrategyId = targetStrategy.id;
            activeStrategyName = targetStrategy.name;
            if (targetStrategy.risk !== undefined) currentRisk = targetStrategy.risk;
            if (targetStrategy.rows !== undefined) currentRows = targetStrategy.rows;
            currentOnWinAction = targetStrategy.onWinAction || 'reset';
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction || 'reset';
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            currentBaseAmount = sanitizeBetAmount(parseFloat(targetStrategy.betAmount) || 0, currency);
            currentBetAmount = currentBaseAmount;
            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);

            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const startMinesAutobet = async (
    autoConfig: AutobetConfig,
    minesCount: number,
    fields: number[]
  ) => {
    setAutobetRunning(true);
    autobetRunningRef.current = true;

    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    const maxBetCapInit = autoConfig.maxBetCap || 0;
    if (maxBetCapInit > 0 && currentBetAmount > maxBetCapInit) {
      currentBetAmount = maxBetCapInit;
    }
    let roundsPlayed = 0;
    let runningBalance = currentBalanceRef.current;
    let runningProfit = 0;
    let peakRunningProfit = 0;
    let totalWagered = 0;
    let consecutiveLosses = 0;
    let consecutiveWins = 0;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentMinesCount = minesCount;
    let currentFields = fields;
    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: currentStrategyProfit,
      totalWagered: 0,
    });

    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: stopOnWinRef.current,
          stopOnLoss: stopOnLossRef.current,
          stopLoseStreak: stopLoseStreakRef.current,
          stopWinStreak: stopWinStreakRef.current,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Live Manual Strategy Switch Detection (User clicked Strategy B while Autobet is running)
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const nextStrat = live.activeStrategy as MinesSavedStrategy;
          currentActiveStrategyId = nextStrat.id;
          activeStrategyName = nextStrat.name;
          currentBaseAmount = sanitizeBetAmount(parseFloat(nextStrat.betAmount) || 0, currency);
          currentBetAmount = currentBaseAmount;
          if (nextStrat.minesCount !== undefined) currentMinesCount = nextStrat.minesCount;
          if (Array.isArray(nextStrat.autoFields) && nextStrat.autoFields.length > 0) currentFields = nextStrat.autoFields;
          currentOnWinAction = nextStrat.onWinAction || 'reset';
          currentOnWinPercent = parseFloat(String(nextStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(nextStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = nextStrat.onLossAction || 'reset';
          currentOnLossPercent = parseFloat(String(nextStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(nextStrat.onLossEveryCount || '1'), 10) || 1;
          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;
          consecutiveWins = 0;
          consecutiveLosses = 0;
          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress((prev) => prev ? { ...prev, activeStrategyName: nextStrat.name } : null);
          addToast('Beralih Strategi', 'ON', `Berpindah ke: "${nextStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : (autoConfig.stopProfit);

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : (autoConfig.stopLoss);

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalanceMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
          addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()} (Batas Saldo: ${stopBalanceMinVal})`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playMinesAutoBet(currentBetAmount, currency, currentMinesCount, currentFields, config);
          recordBet(bet);
          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakRunningProfit) {
            peakRunningProfit = runningProfit;
          }
          runningBalance = Math.max(0, Number((runningBalance + bet.profit).toFixed(8)));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit: peakRunningProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops
          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
            stopOnWin: stopOnWinRef.current,
            stopOnLoss: stopOnLossRef.current,
            stopLoseStreak: stopLoseStreakRef.current,
            stopWinStreak: stopWinStreakRef.current,
            maxBetCap: autoConfig.maxBetCap,
            maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
            trailingStop: autoConfig.trailingStop,
            stopProfit: 0,
            stopLoss: 0,
          };

          const postTargetProfit = (livePost.stopProfit !== undefined && livePost.stopProfit > 0)
            ? livePost.stopProfit
            : (autoConfig.stopProfit);

          const postTargetLoss = (livePost.stopLoss !== undefined && livePost.stopLoss > 0)
            ? livePost.stopLoss
            : (autoConfig.stopLoss);

          if (postTargetProfit > 0 && runningProfit >= postTargetProfit) {
            addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          if (postTargetLoss > 0 && runningProfit <= -postTargetLoss) {
            addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          // Trailing Stop Protection
          const trailingStopVal = (livePost.trailingStop !== undefined && livePost.trailingStop > 0)
            ? livePost.trailingStop
            : (autoConfig.trailingStop || 0);

          if (trailingStopVal > 0 && peakRunningProfit > 0) {
            const drawdownFromPeak = Number((peakRunningProfit - runningProfit).toFixed(8));
            if (drawdownFromPeak >= trailingStopVal) {
              addToast(
                'Trailing Stop: Profit Dikunci!',
                'ON',
                `Keuntungan diamankan! Puncak sesi: +${peakRunningProfit.toFixed(8)}, turun -${drawdownFromPeak.toFixed(8)} (Batas: ${trailingStopVal}). Sisa profit: +${runningProfit.toFixed(8)} ${currency.toUpperCase()}`
              );
              break;
            }
          }

          if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
            addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
            addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()}`);
            break;
          }

          const limitLoseStreak = livePost.stopLoseStreak > 0
            ? livePost.stopLoseStreak
            : ((autoConfig.stopLoseStreak && autoConfig.stopLoseStreak > 0)
              ? autoConfig.stopLoseStreak
              : (autoConfig.maxConsecutiveLosses || 0));

          if (!bet.won && limitLoseStreak > 0 && consecutiveLosses >= limitLoseStreak) {
            addToast(
              'Batas Kalah Beruntun Tercapai!',
              'OFF',
              `Berhenti: Mengalami ${consecutiveLosses}× kekalahan beruntun (Batas: ${limitLoseStreak}×).`
            );
            break;
          }

          const limitWinStreak = livePost.stopWinStreak ?? autoConfig.stopWinStreak ?? 0;
          if (limitWinStreak > 0 && consecutiveWins >= limitWinStreak) {
            addToast('Pemicu Win Streak Tercapai!', 'ON', `Berhenti: Mencapai ${consecutiveWins}× kemenangan berturut-turut (Batas: ${limitWinStreak}×).`);
            break;
          }

          if (bet.won && (stopOnWinRef.current || livePost.stopOnWin)) {
            addToast('Pemicu Win', 'ON', 'Berhenti karena pemicu "Stop on Win" aktif.');
            break;
          }

          if (!bet.won && (stopOnLossRef.current || livePost.stopOnLoss)) {
            addToast('Pemicu Loss', 'OFF', 'Berhenti karena pemicu "Stop on Loss" aktif.');
            break;
          }

          // Evaluate Strategy Switch
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast(
              'Pindah Strategi Otomatis',
              'ON',
              `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`
            );

            currentActiveStrategyId = targetStrategy.id;
            activeStrategyName = targetStrategy.name;
            if (targetStrategy.minesCount !== undefined) currentMinesCount = targetStrategy.minesCount;
            if (targetStrategy.autoFields !== undefined) currentFields = targetStrategy.autoFields;
            currentOnWinAction = targetStrategy.onWinAction || 'reset';
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction || 'reset';
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            currentBaseAmount = sanitizeBetAmount(parseFloat(targetStrategy.betAmount) || 0, currency);
            currentBetAmount = currentBaseAmount;
            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);

            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const startDiamondsAutobet = async (autoConfig: AutobetConfig) => {
    if (autobetRunningRef.current) return;
    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return;
    }

    autobetRunningRef.current = true;
    setAutobetRunning(true);
    setErrorMessage(null);

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    let roundsPlayed = 0;
    let runningProfit = 0;
    let peakProfit = 0;
    let consecutiveWins = 0;
    let consecutiveLosses = 0;
    let totalWagered = 0;
    let runningBalance = currentBalanceRef.current;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: 0,
      totalWagered: 0,
    });

    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const isSwitch = !!autoConfig.switchRulesEnabled;
        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: isSwitch ? switchStopOnWinRef.current : stopOnWinRef.current,
          stopOnLoss: isSwitch ? switchStopOnLossRef.current : stopOnLossRef.current,
          stopLoseStreak: isSwitch ? switchStopLoseStreakRef.current : stopLoseStreakRef.current,
          stopWinStreak: isSwitch ? switchStopWinStreakRef.current : stopWinStreakRef.current,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Check if user manually switched active strategy via UI pills during autobet
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const switchedStrat = live.activeStrategy;
          currentActiveStrategyId = switchedStrat.id;
          activeStrategyName = switchedStrat.name;
          currentOnWinAction = switchedStrat.onWinAction;
          currentOnWinPercent = parseFloat(String(switchedStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(switchedStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = switchedStrat.onLossAction;
          currentOnLossPercent = parseFloat(String(switchedStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(switchedStrat.onLossEveryCount || '1'), 10) || 1;

          const parsedBase = parseFloat(switchedStrat.betAmount) || 0;
          currentBaseAmount = sanitizeBetAmount(parsedBase, currency);
          currentBetAmount = currentBaseAmount;

          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;

          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress(prev => prev ? {
            ...prev,
            activeStrategyName: switchedStrat.name,
            strategyProfit: 0,
          } : null);
          addToast('Strategi Berubah', 'ON', `Berpindah ke strategi aktif: "${switchedStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : autoConfig.stopProfit;

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : autoConfig.stopLoss;

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalMinVal > 0 && runningBalance <= stopBalMinVal) {
          addToast('Batas Saldo Minimum Tercapai!', 'OFF', `Berhenti: Saldo ${runningBalance.toFixed(8)} menyentuh batas minimum (${stopBalMinVal})`);
          break;
        }

        const effMaxConsecutiveLosses = (live.maxConsecutiveLosses !== undefined && live.maxConsecutiveLosses > 0)
          ? live.maxConsecutiveLosses
          : (autoConfig.maxConsecutiveLosses || 0);
        if (effMaxConsecutiveLosses > 0 && consecutiveLosses >= effMaxConsecutiveLosses) {
          addToast('Max Loss Streak Tercapai!', 'OFF', `Berhenti: Mengalami ${consecutiveLosses} kekalahan berturut-turut.`);
          break;
        }

        const effStopLoseStreak = live.stopLoseStreak || 0;
        if (effStopLoseStreak > 0 && consecutiveLosses >= effStopLoseStreak) {
          addToast('Live Stop Lose Streak Tercapai!', 'OFF', `Berhenti: Mengalami ${consecutiveLosses} kekalahan berturut-turut.`);
          break;
        }

        const effStopWinStreak = live.stopWinStreak || 0;
        if (effStopWinStreak > 0 && consecutiveWins >= effStopWinStreak) {
          addToast('Live Stop Win Streak Tercapai!', 'ON', `Berhenti: Meraih ${consecutiveWins} kemenangan berturut-turut.`);
          break;
        }

        const effTrailingStop = (live.trailingStop !== undefined && live.trailingStop > 0)
          ? live.trailingStop
          : (autoConfig.trailingStop || 0);
        if (effTrailingStop > 0 && peakProfit > effTrailingStop && (peakProfit - runningProfit) >= effTrailingStop) {
          addToast('Trailing Stop Mengunci Profit!', 'ON', `Berhenti: Profit turun ${effTrailingStop} dari puncak +${peakProfit.toFixed(8)} ${currency.toUpperCase()}`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playDiamonds(currentBetAmount, currency, config);
          recordBet(bet);

          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakProfit) {
            peakProfit = runningProfit;
          }
          runningBalance = Number((runningBalance + bet.profit).toFixed(8));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops
          if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
            addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
            break;
          }
          if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
            addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
            break;
          }

          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : live;
          const effPostStopOnWin = livePost.stopOnWin ?? (isSwitch ? switchStopOnWinRef.current : stopOnWinRef.current);
          const effPostStopOnLoss = livePost.stopOnLoss ?? (isSwitch ? switchStopOnLossRef.current : stopOnLossRef.current);

          if (bet.won && effPostStopOnWin) {
            addToast('Stop on Win Terpicu!', 'ON', 'Berhenti otomatis setelah menang.');
            break;
          }
          if (!bet.won && effPostStopOnLoss) {
            addToast('Stop on Loss Terpicu!', 'OFF', 'Berhenti otomatis setelah kalah.');
            break;
          }

          // Evaluate Strategy Switch
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast(
              'Pindah Strategi Otomatis',
              'ON',
              `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`
            );

            activeStrategyName = targetStrategy.name;
            currentActiveStrategyId = targetStrategy.id;
            currentOnWinAction = targetStrategy.onWinAction;
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction;
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            const parsedTargetBase = parseFloat(targetStrategy.betAmount) || 0;
            currentBaseAmount = sanitizeBetAmount(parsedTargetBase, currency);
            currentBetAmount = currentBaseAmount;

            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);

            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const startKenoAutobet = async (
    autoConfig: AutobetConfig,
    kenoNumbers: number[],
    kenoRisk: KenoRisk
  ) => {
    if (autobetRunningRef.current) return;
    if (!hasToken) {
      setErrorMessage('Masukkan Stake Session Token Anda terlebih dahulu.');
      return;
    }

    autobetRunningRef.current = true;
    setAutobetRunning(true);
    setErrorMessage(null);

    let currentActiveStrategyId = autoConfig.activeStrategyId;
    let currentBaseAmount = sanitizeBetAmount(autoConfig.baseAmount, currency);
    let currentBetAmount = currentBaseAmount;
    let currentNumbers = [...kenoNumbers];
    let currentRisk = kenoRisk;
    let roundsPlayed = 0;
    let runningProfit = 0;
    let peakProfit = 0;
    let consecutiveWins = 0;
    let consecutiveLosses = 0;
    let totalWagered = 0;
    let runningBalance = currentBalanceRef.current;

    let currentStrategyProfit = 0;
    let currentStrategyLoss = 0;
    let currentStrategyWagered = 0;
    let currentStrategyBets = 0;

    let currentOnWinAction = autoConfig.onWinAction;
    let currentOnWinPercent = autoConfig.onWinPercent;
    let currentOnWinEveryCount = autoConfig.onWinEveryCount || 1;
    let currentOnLossAction = autoConfig.onLossAction;
    let currentOnLossPercent = autoConfig.onLossPercent;
    let currentOnLossEveryCount = autoConfig.onLossEveryCount || 1;

    let activeStrategyName = autoConfig.savedStrategies?.find(s => s.id === autoConfig.activeStrategyId)?.name || 'Default';

    setBatchProgress({
      currentRound: 0,
      totalRounds: autoConfig.numberOfBets,
      runningProfit: 0,
      peakProfit: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      isActive: true,
      activeStrategyName,
      strategyProfit: 0,
      totalWagered: 0,
    });

    try {
      while (autobetRunningRef.current) {
        if (autoConfig.numberOfBets > 0 && roundsPlayed >= autoConfig.numberOfBets) {
          addToast('Batch Selesai', 'INFO', `Target ${autoConfig.numberOfBets} putaran Keno berhasil diselesaikan.`);
          break;
        }

        if (currentBetAmount > 0 && currentBetAmount > runningBalance) {
          setErrorMessage('Taruhan berhenti: Saldo tidak cukup untuk nominal berikutnya.');
          addToast('Berhenti: Saldo Kurang', 'OFF', 'Saldo tidak mencukupi untuk nominal taruhan berikutnya.');
          break;
        }

        const live = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
          stopOnWin: stopOnWinRef.current,
          stopOnLoss: stopOnLossRef.current,
          stopLoseStreak: stopLoseStreakRef.current,
          stopWinStreak: stopWinStreakRef.current,
          maxBetCap: autoConfig.maxBetCap,
          maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
          trailingStop: autoConfig.trailingStop,
          stopProfit: 0,
          stopLoss: 0,
        };

        // Live Strategy Switch Detection
        if (live.activeStrategy && live.activeStrategy.id !== currentActiveStrategyId) {
          const nextStrat = live.activeStrategy as KenoSavedStrategy;
          currentActiveStrategyId = nextStrat.id;
          activeStrategyName = nextStrat.name;
          currentBaseAmount = sanitizeBetAmount(parseFloat(nextStrat.betAmount) || 0, currency);
          currentBetAmount = currentBaseAmount;
          if (nextStrat.risk) currentRisk = nextStrat.risk;
          if (nextStrat.selectedNumbers && nextStrat.selectedNumbers.length > 0) {
            currentNumbers = nextStrat.selectedNumbers;
          }
          currentOnWinAction = nextStrat.onWinAction || 'reset';
          currentOnWinPercent = parseFloat(String(nextStrat.onWinPercent)) || 0;
          currentOnWinEveryCount = parseInt(String(nextStrat.onWinEveryCount || '1'), 10) || 1;
          currentOnLossAction = nextStrat.onLossAction || 'reset';
          currentOnLossPercent = parseFloat(String(nextStrat.onLossPercent)) || 0;
          currentOnLossEveryCount = parseInt(String(nextStrat.onLossEveryCount || '1'), 10) || 1;
          currentStrategyProfit = 0;
          currentStrategyLoss = 0;
          currentStrategyWagered = 0;
          currentStrategyBets = 0;
          consecutiveWins = 0;
          consecutiveLosses = 0;
          autoConfig.onBetAmountChange?.(currentBetAmount);
          setBatchProgress((prev) => prev ? { ...prev, activeStrategyName: nextStrat.name } : null);
          addToast('Beralih Strategi', 'ON', `Berpindah ke: "${nextStrat.name}"`);
        }

        const currentTargetProfit = (live.stopProfit !== undefined && live.stopProfit > 0)
          ? live.stopProfit
          : (autoConfig.stopProfit);

        const currentTargetLoss = (live.stopLoss !== undefined && live.stopLoss > 0)
          ? live.stopLoss
          : (autoConfig.stopLoss);

        // Pre-roll Hard Stops
        if (currentTargetProfit > 0 && runningProfit >= currentTargetProfit) {
          addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${currentTargetProfit})`);
          break;
        }
        if (currentTargetLoss > 0 && runningProfit <= -currentTargetLoss) {
          addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${currentTargetLoss})`);
          break;
        }

        const stopWagerVal = autoConfig.stopWager || 0;
        if (stopWagerVal > 0 && totalWagered >= stopWagerVal) {
          addToast('Stop Wager Tercapai!', 'INFO', `Berhenti: Total wager mencapai ${totalWagered.toFixed(8)} ${currency.toUpperCase()} (Batas: ${stopWagerVal})`);
          break;
        }

        const stopBalanceMinVal = autoConfig.stopBalanceMin || 0;
        if (stopBalanceMinVal > 0 && runningBalance <= stopBalanceMinVal) {
          addToast('Stop Saldo Minimal!', 'OFF', `Berhenti: Saldo tersisa ${runningBalance.toFixed(8)} ${currency.toUpperCase()} (Batas Saldo: ${stopBalanceMinVal})`);
          break;
        }

        setIsRolling(true);

        try {
          const bet = await playKeno(currentBetAmount, currentNumbers, currentRisk, currency, config);
          recordBet(bet);
          roundsPlayed++;
          totalWagered = Number((totalWagered + bet.betAmount).toFixed(8));
          runningProfit = Number((runningProfit + bet.profit).toFixed(8));
          if (runningProfit > peakProfit) {
            peakProfit = runningProfit;
          }
          runningBalance = Math.max(0, Number((runningBalance + bet.profit).toFixed(8)));

          currentStrategyBets++;
          currentStrategyWagered = Number((currentStrategyWagered + bet.betAmount).toFixed(8));
          currentStrategyProfit = Number((currentStrategyProfit + bet.profit).toFixed(8));
          if (!bet.won) {
            currentStrategyLoss = Number((currentStrategyLoss + bet.betAmount).toFixed(8));
          }

          if (bet.won) {
            consecutiveWins++;
            consecutiveLosses = 0;
          } else {
            consecutiveLosses++;
            consecutiveWins = 0;
          }

          setBatchProgress({
            currentRound: roundsPlayed,
            totalRounds: autoConfig.numberOfBets,
            runningProfit,
            peakProfit,
            consecutiveWins,
            consecutiveLosses,
            isActive: true,
            activeStrategyName,
            strategyProfit: currentStrategyProfit,
            totalWagered,
          });

          // Post-roll Hard Stops
          const livePost = autoConfig.getLiveTriggers ? autoConfig.getLiveTriggers() : {
            stopOnWin: stopOnWinRef.current,
            stopOnLoss: stopOnLossRef.current,
            stopLoseStreak: stopLoseStreakRef.current,
            stopWinStreak: stopWinStreakRef.current,
            maxBetCap: autoConfig.maxBetCap,
            maxConsecutiveLosses: autoConfig.maxConsecutiveLosses,
            trailingStop: autoConfig.trailingStop,
            stopProfit: 0,
            stopLoss: 0,
          };

          const postTargetProfit = (livePost.stopProfit !== undefined && livePost.stopProfit > 0)
            ? livePost.stopProfit
            : (autoConfig.stopProfit);

          const postTargetLoss = (livePost.stopLoss !== undefined && livePost.stopLoss > 0)
            ? livePost.stopLoss
            : (autoConfig.stopLoss);

          if (postTargetProfit > 0 && runningProfit >= postTargetProfit) {
            addToast('Target Profit Tercapai!', 'ON', `Berhenti: Profit sesi mencapai +${runningProfit.toFixed(8)} ${currency.toUpperCase()} (Target: +${postTargetProfit})`);
            break;
          }

          if (postTargetLoss > 0 && runningProfit <= -postTargetLoss) {
            addToast('Batas Stop Loss Tercapai!', 'OFF', `Berhenti: Drawdown sesi mencapai -${Math.abs(runningProfit).toFixed(8)} ${currency.toUpperCase()} (Batas: -${postTargetLoss})`);
            break;
          }

          // Trailing Stop Protection
          const trailingStopVal = (livePost.trailingStop !== undefined && livePost.trailingStop > 0)
            ? livePost.trailingStop
            : (autoConfig.trailingStop || 0);

          if (trailingStopVal > 0 && peakProfit > 0) {
            const dropFromPeak = peakProfit - runningProfit;
            if (dropFromPeak >= trailingStopVal) {
              addToast('Trailing Stop Aktif!', 'OFF', `Berhenti mengunci profit: Turun -${dropFromPeak.toFixed(8)} ${currency.toUpperCase()} dari puncak (+${peakProfit.toFixed(8)})`);
              break;
            }
          }

          // Max Consecutive Losses
          const maxConsecutiveLossesVal = (livePost.maxConsecutiveLosses !== undefined && livePost.maxConsecutiveLosses > 0)
            ? livePost.maxConsecutiveLosses
            : (autoConfig.maxConsecutiveLosses || 0);

          if (maxConsecutiveLossesVal > 0 && consecutiveLosses >= maxConsecutiveLossesVal) {
            addToast('Batas Kalah Beruntun!', 'OFF', `Berhenti: Mencapai ${consecutiveLosses}× kalah beruntun.`);
            break;
          }

          // Stop Lose Streak
          const stopLoseStreakVal = (livePost.stopLoseStreak !== undefined && livePost.stopLoseStreak > 0)
            ? livePost.stopLoseStreak
            : (stopLoseStreakRef.current || 0);

          if (stopLoseStreakVal > 0 && consecutiveLosses >= stopLoseStreakVal) {
            addToast('Lose Streak Trigger', 'OFF', `Berhenti otomatis setelah ${consecutiveLosses}× kalah beruntun.`);
            break;
          }

          // Stop Win Streak
          const stopWinStreakVal = (livePost.stopWinStreak !== undefined && livePost.stopWinStreak > 0)
            ? livePost.stopWinStreak
            : (stopWinStreakRef.current || 0);

          if (stopWinStreakVal > 0 && consecutiveWins >= stopWinStreakVal) {
            addToast('Win Streak Trigger', 'ON', `Berhenti otomatis setelah ${consecutiveWins}× menang beruntun.`);
            break;
          }

          if (livePost.stopOnWin && bet.won) {
            addToast('Pemicu Win', 'ON', 'Berhenti karena pemicu "Stop on Win" aktif.');
            break;
          }

          if (livePost.stopOnLoss && !bet.won) {
            addToast('Pemicu Loss', 'OFF', 'Berhenti karena pemicu "Stop on Loss" aktif.');
            break;
          }

          // Evaluate Strategy Switch
          const switchResult = evaluateStrategySwitch({
            switchRulesEnabled: autoConfig.switchRulesEnabled,
            switchRules: autoConfig.switchRules,
            savedStrategies: autoConfig.savedStrategies,
            strategyProfit: currentStrategyProfit,
            strategyLoss: currentStrategyLoss,
            strategyWagered: currentStrategyWagered,
            strategyBets: currentStrategyBets,
            consecutiveWins,
            consecutiveLosses,
          });

          if (switchResult) {
            const { matchedRule, targetStrategy, conditionLabel } = switchResult;
            addToast('Pindah Strategi Otomatis', 'ON', `Syarat [${conditionLabel}] tercapai! Berpindah ke: "${targetStrategy.name}"`);

            currentActiveStrategyId = targetStrategy.id;
            activeStrategyName = targetStrategy.name;
            const kenoStrat = targetStrategy as KenoSavedStrategy;
            if (kenoStrat.risk) currentRisk = kenoStrat.risk;
            if (kenoStrat.selectedNumbers && kenoStrat.selectedNumbers.length > 0) {
              currentNumbers = kenoStrat.selectedNumbers;
            }
            currentOnWinAction = targetStrategy.onWinAction || 'reset';
            currentOnWinPercent = parseFloat(String(targetStrategy.onWinPercent)) || 0;
            currentOnWinEveryCount = parseInt(String(targetStrategy.onWinEveryCount || '1'), 10) || 1;
            currentOnLossAction = targetStrategy.onLossAction || 'reset';
            currentOnLossPercent = parseFloat(String(targetStrategy.onLossPercent)) || 0;
            currentOnLossEveryCount = parseInt(String(targetStrategy.onLossEveryCount || '1'), 10) || 1;

            currentBaseAmount = sanitizeBetAmount(parseFloat(targetStrategy.betAmount) || 0, currency);
            currentBetAmount = currentBaseAmount;
            const maxBetCapValSwitch = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
              ? livePost.maxBetCap
              : (autoConfig.maxBetCap || 0);
            if (maxBetCapValSwitch > 0 && currentBetAmount > maxBetCapValSwitch) {
              currentBetAmount = maxBetCapValSwitch;
            }
            autoConfig.onBetAmountChange?.(currentBetAmount);

            currentStrategyProfit = 0;
            currentStrategyLoss = 0;
            currentStrategyWagered = 0;
            currentStrategyBets = 0;
            if (matchedRule.resetCountersOnSwitch) {
              consecutiveWins = 0;
              consecutiveLosses = 0;
            }

            autoConfig.onSwitchStrategy?.(targetStrategy, matchedRule);
            await delay(Math.max(100, autoConfig.batchDelayMs || 100));
            continue;
          }

          if (bet.won) {
            const winEvery = Math.max(1, currentOnWinEveryCount || 1);
            if (consecutiveWins % winEvery === 0) {
              if (currentOnWinAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnWinPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnWinPercent / 100);
                }
              }
            }
          } else {
            const lossEvery = Math.max(1, currentOnLossEveryCount || 1);
            if (consecutiveLosses % lossEvery === 0) {
              if (currentOnLossAction === 'reset') {
                currentBetAmount = currentBaseAmount;
              } else {
                if (currentBetAmount <= 0 && currentBaseAmount > 0) {
                  currentBetAmount = currentBaseAmount * (1 + currentOnLossPercent / 100);
                } else {
                  currentBetAmount += currentBetAmount * (currentOnLossPercent / 100);
                }
              }
            }
          }
          currentBetAmount = sanitizeBetAmount(currentBetAmount, currency);
          const maxBetCapValProg = (livePost.maxBetCap !== undefined && livePost.maxBetCap > 0)
            ? livePost.maxBetCap
            : (autoConfig.maxBetCap || 0);
          if (maxBetCapValProg > 0 && currentBetAmount > maxBetCapValProg) {
            currentBetAmount = maxBetCapValProg;
          }
          autoConfig.onBetAmountChange?.(currentBetAmount);
        } catch (err: any) {
          const errMsg = err.message || 'Taruhan gagal';
          if (errMsg.includes('429') || errMsg.toLowerCase().includes('rate limit')) {
            addToast('Rate Limit Stake (HTTP 429)', 'OFF', 'Stake membatasi frekuensi request. Batch dihentikan otomatis.');
          } else {
            addToast('Taruhan Error', 'OFF', errMsg);
          }
          setErrorMessage(`Auto bet / batch berhenti: ${errMsg}`);
          break;
        } finally {
          setIsRolling(false);
        }

        const currentDelay = Math.max(100, autoConfig.batchDelayMs || 100);
        await delay(currentDelay);
      }
    } finally {
      autobetRunningRef.current = false;
      setAutobetRunning(false);
      setBatchProgress(null);
      autoConfig.onBetAmountChange?.(currentBaseAmount);
      loadBalances();
    }
  };

  const handleBackToLobby = () => {
    stopAutobet();
    setSelectedGame(null);
  };

  const hideZeroBalances = config.hideZeroBalances ?? false;

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 flex flex-col font-sans selection:bg-zinc-200">
      <Header
        config={config}
        balance={currentBalance}
        currency={currency}
        onCurrencyChange={handleCurrencyChange}
        userBalances={userBalances}
        isRefreshingBalance={isRefreshingBalance}
        onRefreshBalance={loadBalances}
        onOpenSettings={() => setIsSettingsOpen(true)}
        hideZeroBalances={hideZeroBalances}
        onToggleHideZeroBalances={handleToggleHideZeroBalances}
        username={username}
        onNavigateLobby={handleBackToLobby}
        onOpenSeedModal={() => setIsSeedModalOpen(true)}
      />

      <main className={`flex-1 w-full mx-auto px-2 sm:px-5 py-3 sm:py-5 flex flex-col gap-3 sm:gap-4 ${selectedGame !== null ? 'max-w-7xl' : 'max-w-4xl'}`}>
        {/* Error notification */}
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 sm:p-3.5 flex items-start justify-between gap-2 sm:gap-3 text-rose-800 text-[10px] sm:text-xs font-mono shadow-xs">
            <div className="flex items-start gap-2 sm:gap-2.5 flex-1">
              <AlertCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="space-y-1.5 flex-1">
                <p className="font-bold">{errorMessage}</p>
                <div className="pt-2 border-t border-rose-200/80 space-y-2">
                  <div className="text-[10px] sm:text-[11px] text-zinc-700 font-semibold">
                    Solusi Koneksi 1-Klik: Beralih ke Jalur Alternatif
                  </div>
                  <div className="flex flex-wrap gap-1.5 sm:gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        handleSaveConfig({ ...config, routingMode: 'proxy', endpoint: 'https://stake.bet/_api/graphql' });
                        setErrorMessage(null);
                        addToast('Mode Koneksi', 'ON', 'Beralih ke Server Proxy (Auto-Rotasi Mirror Stake)');
                        loadBalances();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] sm:text-[11px] font-bold cursor-pointer shadow-2xs"
                    >
                      1. Server Proxy (Auto-Rotate Mirror)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleSaveConfig({ ...config, routingMode: 'cors-proxy', corsProxyUrl: 'https://corsproxy.io/?url=' });
                        setErrorMessage(null);
                        addToast('Mode Koneksi', 'ON', 'Beralih ke CORS Proxy (corsproxy.io)');
                        loadBalances();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-900 text-white text-[10px] sm:text-[11px] font-bold cursor-pointer shadow-2xs"
                    >
                      2. CORS Proxy Relay
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleSaveConfig({ ...config, routingMode: 'direct', endpoint: 'https://stake.com/_api/graphql' });
                        setErrorMessage(null);
                        addToast('Mode Koneksi', 'ON', 'Beralih ke Direct Fetch (stake.com)');
                        loadBalances();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-white border border-rose-300 hover:bg-rose-100 text-[10px] sm:text-[11px] text-rose-900 font-semibold cursor-pointer"
                    >
                      3. Direct Fetch (stake.com)
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <button onClick={() => setErrorMessage(null)} className="p-1 hover:bg-rose-100 rounded text-rose-600">
              <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </div>
        )}

        {/* Dynamic State View Switching */}
        {viewMode === 'token-gate' && (
          <TokenRequiredScreen
            config={config}
            onSaveToken={handleInitialTokenSave}
          />
        )}

        {viewMode === 'lobby' && (
          <GameLobby
            username={username}
            currency={currency}
            balance={currentBalance}
            onSelectGame={(game) => setSelectedGame(game)}
            onRefreshBalance={loadBalances}
            isRefreshingBalance={isRefreshingBalance}
            onDisconnect={handleDisconnect}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {selectedGame !== null && (
          <div className="flex flex-col gap-3 sm:gap-4">
            {/* Desktop 2-Column Layout (Left: Bet Control Box, Right: Live Result Card + Bet History) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 items-start">
              {/* LEFT COLUMN: Game Bet Control Panel */}
              <div className="lg:col-span-6 xl:col-span-5 flex flex-col gap-4">
                {selectedGame === 'dice' && (
                  <DiceGame
                    balance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    onBet={executeDiceBet}
                    houseEdgePercent={config.houseEdgePercent}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={startDiceAutobet}
                    onStopAutobet={stopAutobet}
                    onShowToast={addToast}
                    batchProgress={batchProgress}
                    currentStreak={currentStreak}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

                {selectedGame === 'limbo' && (
                  <LimboGame
                    balance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    onBet={executeLimboBet}
                    houseEdgePercent={config.houseEdgePercent}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={startLimboAutobet}
                    onStopAutobet={stopAutobet}
                    onShowToast={addToast}
                    batchProgress={batchProgress}
                    currentStreak={currentStreak}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

                {selectedGame === 'plinko' && (
                  <PlinkoGame
                    balance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    onBet={executePlinkoBet}
                    houseEdgePercent={config.houseEdgePercent}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={startPlinkoAutobet}
                    onStopAutobet={stopAutobet}
                    onShowToast={addToast}
                    batchProgress={batchProgress}
                    currentStreak={currentStreak}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    lastBet={lastBet}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

                {selectedGame === 'mines' && (
                  <MinesGame
                    balance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    onBetFinished={recordBet}
                    houseEdgePercent={config.houseEdgePercent}
                    onShowToast={addToast}
                    config={config}
                    onRefreshBalance={loadBalances}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={startMinesAutobet}
                    onStopAutobet={stopAutobet}
                    batchProgress={batchProgress}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    lastBet={lastBet}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

                {selectedGame === 'diamonds' && (
                  <DiamondsGame
                    balance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    onBet={executeDiamondsBet}
                    houseEdgePercent={1.71}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={startDiamondsAutobet}
                    onStopAutobet={stopAutobet}
                    onShowToast={addToast}
                    lastBet={lastBet}
                    batchProgress={batchProgress}
                    currentStreak={currentStreak}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

                {selectedGame === 'keno' && (
                  <KenoGame
                    userBalance={currentBalance}
                    currency={currency}
                    isRolling={isRolling}
                    lastBet={lastBet}
                    onPlayKeno={async (amount, numbers, risk) => {
                      return await executeKenoBet(amount, numbers, risk);
                    }}
                    config={config}
                    autobetRunning={autobetRunning}
                    onToggleAutobet={(autoConfig, numbers, risk) => {
                      startKenoAutobet(autoConfig, numbers, risk);
                    }}
                    onStopAutobet={stopAutobet}
                    onShowToast={addToast}
                    batchProgress={batchProgress}
                    stopLoseStreak={stopLoseStreak}
                    stopWinStreak={stopWinStreak}
                    stopOnWin={stopOnWin}
                    stopOnLoss={stopOnLoss}
                    showHistoryStats={showHistoryStats}
                    onToggleShowStats={handleToggleShowStats}
                    onUpdateTriggers={handleUpdateSingleTriggers}
                    switchRulesEnabled={isSwitchActive}
                  />
                )}

              </div>

              {/* RIGHT COLUMN: Live Result Card + Bet History */}
              <div className="lg:col-span-6 xl:col-span-7 flex flex-col gap-3">
                {/* Compact Live Result Card */}
                <LiveResultCard
                  lastBet={lastBet}
                  currency={currency}
                  isRolling={isRolling}
                />

                {/* Global Quick Triggers (Moved from game panels as per user request) */}
                <LiveTriggers
                  stopOnWin={activeStopOnWin}
                  onToggleStopOnWin={handleActiveToggleStopOnWin}
                  stopOnLoss={activeStopOnLoss}
                  onToggleStopOnLoss={handleActiveToggleStopOnLoss}
                  stopLoseStreak={activeStopLoseStreak}
                  onStopLoseStreakChange={handleActiveStopLoseStreakChange}
                  currentStreak={currentStreak}
                  currency={currency}
                  modeLabel={isSwitchActive ? 'Mode Switch Strategy' : undefined}
                  isSwitchMode={isSwitchActive}
                />

                {/* History & Live Statistics (Stats summary toggled by BarChart2 sub-toolbar button) */}
                <BetHistory
                  history={history}
                  sessionStats={sessionStats}
                  chartHistory={chartHistory}
                  onClearHistory={handleClearHistory}
                  onResetStats={handleResetStats}
                  currency={currency}
                  username={username}
                  maxLimit={historyLimit}
                  onMaxLimitChange={handleHistoryLimitChange}
                  onShowToast={addToast}
                  showLiveStatsProp={showHistoryStats}
                  onToggleShowStats={handleToggleShowStats}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="py-3 px-4 text-center text-[11px] font-mono text-zinc-400 border-t border-zinc-200 bg-white">
        JStkBot • Real GraphQL Client • Eksekusi Instan
      </footer>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onSaveConfig={handleSaveConfig}
        onRefreshBalance={loadBalances}
        onDisconnect={handleDisconnect}
        onShowToast={addToast}
        historyLimit={historyLimit}
        onHistoryLimitChange={handleHistoryLimitChange}
      />

      <SeedModal
        isOpen={isSeedModalOpen}
        onClose={() => setIsSeedModalOpen(false)}
        activeClientSeed={clientSeed}
        activeServerSeedHash={serverSeedHash}
        nonce={seedNonce}
        onSaveNewSeed={handleSaveNewClientSeed}
      />

      {/* Modern Feedback Toasts */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
