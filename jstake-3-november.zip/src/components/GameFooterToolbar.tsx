import React, { useState, useRef, useEffect } from 'react';
import { Settings, BarChart2 } from 'lucide-react';
import { BatchSpeedInput } from './BatchSpeedInput';

interface GameFooterToolbarProps {
  batchDelayMs: number;
  onBatchDelayChange: (ms: number) => void;
  autobetRunning: boolean;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  accentColor?: 'emerald' | 'cyan' | 'amber' | 'indigo' | 'purple';
}

export const GameFooterToolbar: React.FC<GameFooterToolbarProps> = ({
  batchDelayMs,
  onBatchDelayChange,
  autobetRunning,
  showHistoryStats = true,
  onToggleShowStats,
  accentColor = 'emerald',
}) => {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const settingsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (settingsRef.current && !settingsRef.current.contains(e.target as Node)) {
        setIsSettingsOpen(false);
      }
    };
    if (isSettingsOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isSettingsOpen]);

  const activeBadgeStyles = {
    emerald: 'bg-emerald-50 border-emerald-300 text-emerald-700 font-bold',
    cyan: 'bg-cyan-50 border-cyan-300 text-cyan-700 font-bold',
    amber: 'bg-amber-50 border-amber-300 text-amber-700 font-bold',
    indigo: 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold',
    purple: 'bg-purple-50 border-purple-300 text-purple-700 font-bold',
  }[accentColor];

  return (
    <div className="bg-zinc-100 border border-zinc-200 rounded-2xl px-3 py-2 flex items-center justify-between gap-2 relative mt-1 font-mono">
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Settings Button & Speed Popover */}
        <div className="relative" ref={settingsRef}>
          <button
            type="button"
            onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            title="Pengaturan Kecepatan Batch"
            className={`p-1.5 sm:p-2 rounded-xl border transition cursor-pointer flex items-center justify-center ${
              isSettingsOpen
                ? 'bg-zinc-900 text-white border-zinc-900'
                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-200/80'
            }`}
          >
            <Settings className="w-4 h-4" />
          </button>

          {isSettingsOpen && (
            <div className="absolute left-0 bottom-full mb-2 w-72 bg-white border border-zinc-200 rounded-2xl shadow-2xl z-50 p-4 space-y-3 text-left animate-in fade-in duration-150 text-zinc-900">
              <BatchSpeedInput
                value={batchDelayMs}
                onChange={onBatchDelayChange}
                disabled={autobetRunning}
              />
            </div>
          )}
        </div>

        {/* Statistik Button */}
        <button
          type="button"
          onClick={onToggleShowStats}
          title={showHistoryStats ? 'Sembunyikan Data Statistik Sesi' : 'Tampilkan Data Statistik Sesi'}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer shadow-2xs ${
            showHistoryStats
              ? activeBadgeStyles
              : 'bg-white border-zinc-200 hover:bg-zinc-100 text-zinc-700 hover:border-zinc-300'
          }`}
        >
          <BarChart2 className="w-3.5 h-3.5" />
          <span>Statistik</span>
        </button>
      </div>
    </div>
  );
};
