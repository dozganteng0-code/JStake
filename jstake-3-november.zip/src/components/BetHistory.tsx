import React, { useState, useMemo } from 'react';
import { BetResult, SessionStats } from '../types/stake';
import { Trash2, Copy, Check, BarChart2, Eye, EyeOff, TrendingUp, X, Dices, Rocket, FileText, RotateCcw, CircleDot, Disc, Bomb, Gem, Info, Grid } from 'lucide-react';
import { formatBetId, DIAMOND_COLOR_MAP, DiamondColor } from '../services/stakeApi';
import { DiamondIcon } from './DiamondsGame';

interface BetHistoryProps {
  history: BetResult[];
  sessionStats?: SessionStats;
  chartHistory?: number[];
  onClearHistory: () => void;
  onResetStats?: () => void;
  currency: string;
  username?: string;
  maxLimit?: 10 | 20;
  onMaxLimitChange?: (limit: 10 | 20) => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  showLiveStatsProp?: boolean;
  onToggleShowStats?: () => void;
}

export const BetHistory: React.FC<BetHistoryProps> = ({
  history,
  sessionStats,
  chartHistory = [],
  onClearHistory,
  onResetStats,
  currency,
  username = 'jstkbot',
  maxLimit = 20,
  onMaxLimitChange,
  onShowToast,
  showLiveStatsProp,
  onToggleShowStats,
}) => {
  const [localLimit, setLocalLimit] = useState<10 | 20>(maxLimit);
  const currentLimit = maxLimit ?? localLimit;
  const [filter, setFilter] = useState<'all' | 'wins' | 'losses'>('all');
  const [localShowStats, setLocalShowStats] = useState<boolean>(false);
  const showLiveStats = showLiveStatsProp !== undefined ? showLiveStatsProp : localShowStats;
  const toggleLiveStats = () => {
    if (onToggleShowStats) {
      onToggleShowStats();
    } else {
      setLocalShowStats(!localShowStats);
    }
  };
  const [copiedBetId, setCopiedBetId] = useState<string | null>(null);

  // Selected bet for Modal detail display
  const [selectedBetModal, setSelectedBetModal] = useState<BetResult | null>(null);

  // Helper to format currency amount strictly with 8 decimal places
  const formatAmount = (amt: number) => {
    return amt.toFixed(8);
  };

  const stats = useMemo(() => {
    if (sessionStats) {
      return sessionStats;
    }

    let wins = 0;
    let losses = 0;
    let totalWagered = 0;
    let totalWonCurrency = 0;
    let totalLostCurrency = 0;
    let netProfit = 0;

    history.forEach((bet) => {
      totalWagered += bet.betAmount;
      netProfit += bet.profit;
      if (bet.won) {
        wins++;
        totalWonCurrency += bet.profit;
      } else {
        losses++;
        totalLostCurrency += bet.betAmount;
      }
    });

    const totalBets = history.length;
    const winRate = totalBets > 0 ? Number(((wins / totalBets) * 100).toFixed(1)) : 0;

    return {
      totalBets,
      wins,
      losses,
      totalWagered,
      totalWonCurrency,
      totalLostCurrency,
      netProfit,
      winRate,
    };
  }, [sessionStats, history]);

  const sparklineData = useMemo(() => {
    // If stats are empty, the session was reset. Do NOT fallback to history in this case.
    if (stats.totalBets === 0) {
      return {
        polyline: '0,24 280,24', // Flat line
        areaPoints: '0,48 0,24 280,24 280,48',
        zeroY: '24',
        lastX: 280,
        lastY: 24,
        isProfit: true,
        latestProfit: 0,
      };
    }

    // Use chartHistory if available, otherwise fallback to history
    // We check length > 1 for chartHistory because [0] means it was just reset
    const points = (chartHistory.length > 1 || (chartHistory.length === 1 && stats.totalBets === 0)) ? chartHistory : (() => {
      if (history.length < 2 || stats.totalBets === 0) return null;
      const chrono = [...history].reverse();
      let cum = 0;
      const p: number[] = [0];
      chrono.forEach((b) => {
        cum += b.profit;
        p.push(cum);
      });
      return p;
    })();

    if (!points || points.length < 2) {
      // If we only have 1 point (reset state [0]), show flat line
      if (points && points.length === 1) {
        return {
          polyline: '0,24 280,24',
          areaPoints: '0,48 0,24 280,24 280,48',
          zeroY: '24',
          lastX: 280,
          lastY: 24,
          isProfit: true,
          latestProfit: points[0],
        };
      }
      return null;
    }

    const min = Math.min(...points);
    const max = Math.max(...points);
    let range = max - min;
    if (range === 0) range = 1;

    const width = 280;
    const height = 48;
    const padTop = 4;
    const padBottom = 4;
    const usableHeight = height - padTop - padBottom;

    const coordsArray = points.map((p, idx) => {
      const x = (idx / (points.length - 1)) * width;
      const y = height - padBottom - ((p - min) / range) * usableHeight;
      return { x: Number(x.toFixed(1)), y: Number(y.toFixed(1)) };
    });

    const polyline = coordsArray.map((c) => `${c.x},${c.y}`).join(' ');
    const firstX = coordsArray[0].x;
    const lastX = coordsArray[coordsArray.length - 1].x;
    const lastY = coordsArray[coordsArray.length - 1].y;
    const areaPoints = `${firstX},${height} ${polyline} ${lastX},${height}`;

    const zeroY = (0 >= min && 0 <= max)
      ? (height - padBottom - ((0 - min) / range) * usableHeight).toFixed(1)
      : null;

    const isProfit = points[points.length - 1] >= 0;
    return {
      polyline,
      areaPoints,
      zeroY,
      lastX,
      lastY,
      isProfit,
      latestProfit: points[points.length - 1],
    };
  }, [chartHistory, history, stats.totalBets]);

  // Use raw stats for clarity as requested by user (reverting 'Net' logic)
  const displayStats = useMemo(() => {
    return stats;
  }, [stats]);

  const filteredHistory = useMemo(() => {
    return history.filter((bet) => {
      if (filter === 'wins') return bet.won;
      if (filter === 'losses') return !bet.won;
      return true;
    });
  }, [history, filter]);

  // Local counts for the current history buffer (not total session)
  const bufferCounts = useMemo(() => {
    let wins = 0;
    let losses = 0;
    history.forEach((b) => {
      if (b.won) wins++;
      else losses++;
    });
    return { wins, losses, total: history.length };
  }, [history]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBetId(text);
    onShowToast?.('Disalin', 'ON', `ID Taruhan ${text} disalin ke clipboard.`);
    setTimeout(() => setCopiedBetId(null), 1800);
  };



  const handleClearHistoryAction = () => {
    if (history.length === 0) return;
    onClearHistory();
    onShowToast?.('Riwayat Dihapus', 'INFO', 'Memori lokal riwayat taruhan telah dibebaskan.');
  };

  const displayUsername = username ? (username.startsWith('@') ? username : `@${username}`) : '@jstkbot';

  return (
    <div className="bg-white border border-zinc-200 rounded-xl sm:rounded-2xl overflow-hidden flex flex-col shadow-xs font-mono text-zinc-900">
      {/* Header bar with Live Stats Toggle */}
      <div className="p-2 sm:p-3 border-b border-zinc-200 bg-zinc-50 flex items-center justify-between gap-2 flex-wrap text-xs">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <BarChart2 className="w-3.5 h-3.5 sm:w-4 h-4 text-emerald-600" />
          <span className="font-bold text-zinc-900 text-[10px] sm:text-xs uppercase">Riwayat & Stats</span>
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5">
          {onResetStats && stats.totalBets > 0 && (
            <button
              type="button"
              onClick={onResetStats}
              title="Reset Statistik Sesi Ke 0"
              className="p-1 sm:p-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 text-zinc-600 transition cursor-pointer select-none"
            >
              <RotateCcw className="w-3.5 h-3.5 sm:w-4 h-4 text-rose-500" />
            </button>
          )}

          <button
            type="button"
            onClick={toggleLiveStats}
            title={showLiveStats ? "Sembunyikan Live Statistik" : "Tampilkan Live Statistik"}
            className={`p-1 sm:p-1.5 rounded-lg border transition cursor-pointer select-none ${
              showLiveStats
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-100'
            }`}
          >
            {showLiveStats ? (
              <EyeOff className="w-3.5 h-3.5 sm:w-4 h-4 text-emerald-600" />
            ) : (
              <Eye className="w-3.5 h-3.5 sm:w-4 h-4 text-zinc-500" />
            )}
          </button>
        </div>
      </div>

      {/* Live Session Statistics Panel */}
      {showLiveStats && (
        <div className="p-2.5 sm:p-3.5 border-b border-zinc-200 bg-white grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3 text-xs border-dashed animate-in fade-in duration-150">
          {/* Total Wagered & Bet Count */}
          <div className="bg-zinc-50 border border-zinc-200/80 rounded-lg sm:rounded-xl p-2 sm:p-3 flex flex-col justify-between group relative">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[9px] sm:text-[10px] text-zinc-500 block font-bold uppercase mb-0.5">Total Taruhan</span>
                <Info className="w-3 h-3 text-zinc-300 group-hover:text-zinc-500 transition-colors" />
              </div>
              <span className="font-bold text-zinc-900 text-base sm:text-xl leading-tight block truncate">
                {formatAmount(stats.totalWagered)} <span className="text-[10px] uppercase text-zinc-400 font-medium">{currency}</span>
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-bold mt-1.5">
              {stats.totalBets} <span className="font-normal">BET</span>
            </span>
            <div className="pointer-events-none absolute left-0 bottom-full mb-1 hidden group-hover:block w-48 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
              Total akumulasi nilai taruhan yang telah dipasang selama sesi ini.
            </div>
          </div>

          {/* Wins Count & Won Currency */}
          <div className="bg-emerald-50/50 border border-emerald-100 rounded-lg sm:rounded-xl p-2 sm:p-3 flex flex-col justify-between shadow-2xs group relative">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[9px] sm:text-[10px] text-emerald-600 block font-bold uppercase mb-0.5">Menang</span>
                <Info className="w-3 h-3 text-emerald-300 group-hover:text-emerald-500 transition-colors" />
              </div>
              <span className="font-bold text-emerald-700 text-base sm:text-xl leading-tight block truncate">
                +{formatAmount(stats.totalWonCurrency)}
              </span>
            </div>
            <span className="text-[10px] text-emerald-600 font-black mt-1.5 uppercase">
              {displayStats.wins} W <span className="font-medium opacity-60">({stats.winRate}%)</span>
            </span>
            <div className="pointer-events-none absolute left-0 bottom-full mb-1 hidden group-hover:block w-48 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
              Jumlah kemenangan dan total keuntungan kotor yang didapat.
            </div>
          </div>
          {/* Losses Count & Lost Currency */}
          <div className="bg-rose-50/50 border border-rose-100 rounded-lg sm:rounded-xl p-2 sm:p-3 flex flex-col justify-between shadow-2xs group relative">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[9px] sm:text-[10px] text-rose-600 block font-bold uppercase mb-0.5">Kalah</span>
                <Info className="w-3 h-3 text-rose-300 group-hover:text-rose-500 transition-colors" />
              </div>
              <span className="font-bold text-rose-700 text-base sm:text-xl leading-tight block truncate">
                -{formatAmount(stats.totalLostCurrency)}
              </span>
            </div>
            <span className="text-[10px] text-rose-600 font-black mt-1.5 uppercase">
              {displayStats.losses} L
            </span>
            <div className="pointer-events-none absolute left-0 bottom-full mb-1 hidden group-hover:block w-48 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
              Jumlah kekalahan dan total modal yang hilang.
            </div>
          </div>

          {/* Mini Sparkline Chart */}
          {sparklineData && (
            <div className="col-span-1 sm:col-span-3 bg-zinc-50 border border-zinc-200/80 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-3 shadow-2xs">
              <div className="flex flex-col justify-between group relative">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] sm:text-[10px] text-zinc-500 block font-bold uppercase mb-0.5">TREN PROFIT SESI</span>
                  <Info className="w-3 h-3 text-zinc-300 group-hover:text-zinc-500 transition-colors" />
                </div>
                <span className={`font-bold text-base sm:text-xl leading-tight block truncate ${sparklineData.isProfit ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {sparklineData.isProfit ? '+' : ''}{formatAmount(sparklineData.latestProfit)} <span className="text-[10px] uppercase text-zinc-400 font-medium">{currency}</span>
                </span>
                <div className="pointer-events-none absolute left-0 bottom-full mb-1 hidden group-hover:block w-48 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                  Grafik tren keuntungan atau kerugian bersih secara kronologis dari awal sesi.
                </div>
              </div>
              <div className="flex-1 max-w-[200px] h-10 flex items-center justify-end">
                <svg viewBox="0 0 280 48" className="w-full h-full overflow-visible">
                  <defs>
                    <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                    </linearGradient>
                    <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {/* Optional Break-even Zero Line */}
                  {sparklineData.zeroY && (
                    <line
                      x1="0"
                      y1={sparklineData.zeroY}
                      x2="280"
                      y2={sparklineData.zeroY}
                      stroke="#d4d4d8"
                      strokeDasharray="3 3"
                      strokeWidth="1"
                    />
                  )}

                  {/* Gradient fill under trend line */}
                  <polygon
                    points={sparklineData.areaPoints}
                    fill={sparklineData.isProfit ? 'url(#profitGrad)' : 'url(#lossGrad)'}
                  />

                  {/* Trend Line */}
                  <polyline
                    fill="none"
                    stroke={sparklineData.isProfit ? '#10b981' : '#f43f5e'}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={sparklineData.polyline}
                  />

                  {/* Current Position End Dot */}
                  <circle
                    cx={sparklineData.lastX}
                    cy={sparklineData.lastY}
                    r="4"
                    fill={sparklineData.isProfit ? '#10b981' : '#f43f5e'}
                  />
                  <circle
                    cx={sparklineData.lastX}
                    cy={sparklineData.lastY}
                    r="2"
                    fill="#ffffff"
                  />
                </svg>
              </div>
            </div>
          )}

          {/* Last 10 Bets Outcome Visual Dots */}
          <div className="col-span-1 sm:col-span-3 bg-zinc-50 border border-zinc-200/80 rounded-xl p-2.5 flex items-center justify-between gap-2">
            <span className="text-[10px] text-zinc-500 font-bold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              STREAK TARUHAN TERAKHIR:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              {history.length === 0 ? (
                <span className="text-[10px] text-zinc-400">Belum ada taruhan</span>
              ) : (
                history.slice(0, 10).map((bet) => {
                  const isPlinko = bet.game === 'plinko';
                  let badgeStyle = bet.won
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-rose-100 text-rose-800 border border-rose-300';
                  let badgeLabel = bet.won ? 'H' : 'M';

                  if (isPlinko) {
                    const mult = bet.multiplier;
                    badgeLabel = mult >= 1000 ? `${mult.toLocaleString()}×` : `${mult}×`;

                    if (mult >= 1000) {
                      badgeStyle = 'bg-gradient-to-r from-amber-500 to-rose-600 text-white border border-amber-300 font-extrabold shadow-2xs';
                    } else if (mult >= 100) {
                      badgeStyle = 'bg-rose-500 text-white border border-rose-600 font-bold';
                    } else if (mult >= 10) {
                      badgeStyle = 'bg-orange-500 text-white border border-orange-600 font-bold';
                    } else if (mult >= 2) {
                      badgeStyle = 'bg-amber-400 text-amber-950 border border-amber-500 font-bold';
                    } else if (mult >= 1) {
                      badgeStyle = 'bg-emerald-100 text-emerald-800 border border-emerald-400 font-bold';
                    } else {
                      badgeStyle = 'bg-zinc-100 text-zinc-600 border border-zinc-300 font-semibold';
                    }
                  }

                  return (
                    <button
                      key={bet.id}
                      type="button"
                      onClick={() => setSelectedBetModal(bet)}
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold cursor-pointer transition hover:scale-105 shrink-0 ${badgeStyle}`}
                      title={`Klik untuk lihat rincian: ${bet.game.toUpperCase()} (${isPlinko ? `${bet.multiplier}×` : (bet.won ? 'Menang' : 'Kalah')})`}
                    >
                      {badgeLabel}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Filter & Actions Bar */}
      <div className="p-2.5 px-3 flex items-center justify-between gap-2 border-b border-zinc-200 text-xs font-mono bg-zinc-50/50">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setFilter('all')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
              filter === 'all' ? 'bg-zinc-900 text-white' : 'text-zinc-500 hover:text-zinc-900'
            }`}
          >
            Semua ({bufferCounts.total})
          </button>
          <button
            onClick={() => setFilter('wins')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
              filter === 'wins' ? 'bg-emerald-600 text-white' : 'text-zinc-500 hover:text-emerald-700'
            }`}
          >
            Menang ({bufferCounts.wins})
          </button>
          <button
            onClick={() => setFilter('losses')}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
              filter === 'losses' ? 'bg-rose-600 text-white' : 'text-zinc-500 hover:text-rose-700'
            }`}
          >
            Kalah ({bufferCounts.losses})
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Limit Toggle: 10 vs 20 */}
          <div className="flex items-center gap-1 bg-white px-1.5 py-0.5 rounded-md border border-zinc-200">
            <span className="text-[10px] text-zinc-400 font-semibold">Maks:</span>
            <button
              type="button"
              onClick={() => {
                setLocalLimit(10);
                onMaxLimitChange?.(10);
              }}
              className={`px-1.5 py-0.2 rounded text-[10px] font-bold transition cursor-pointer ${
                currentLimit === 10
                  ? 'bg-zinc-900 text-white'
                  : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              10
            </button>
            <button
              type="button"
              onClick={() => {
                setLocalLimit(20);
                onMaxLimitChange?.(20);
              }}
              className={`px-1.5 py-0.2 rounded text-[10px] font-bold transition cursor-pointer ${
                currentLimit === 20
                  ? 'bg-zinc-900 text-white'
                  : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              20
            </button>
          </div>


          <button
            onClick={handleClearHistoryAction}
            disabled={history.length === 0}
            title="Hapus Riwayat (Bebaskan Memori Browser)"
            className="p-1 rounded border border-zinc-200 bg-white hover:bg-rose-50 hover:text-rose-600 text-zinc-400 text-[11px] disabled:opacity-40 cursor-pointer"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* History Table - Columns: Game | Waktu | Taruhan | Target | Hasil | Profit */}
      <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-zinc-200">
        <table className="w-full text-left text-[10px] sm:text-xs font-mono border-separate border-spacing-y-0 px-1.5">
          <thead className="bg-zinc-50 text-zinc-500 uppercase text-[9px] sm:text-[10px] tracking-wider">
            <tr>
              <th className="py-1 px-2 sm:px-2.5 font-bold text-zinc-600">Game</th>
              <th className="py-1 px-2 sm:px-2.5 hidden xs:table-cell font-bold text-zinc-600">Waktu</th>
              <th className="py-1 px-2 sm:px-2.5 text-right font-bold text-zinc-700">Taruhan</th>
              <th className="py-1 px-2 sm:px-2.5 text-center font-bold text-zinc-600">Target/Hasil</th>
              <th className="py-1 px-2 sm:px-2.5 text-right font-bold text-zinc-700">Result</th>
            </tr>
          </thead>
          <tbody className="bg-white">
            {filteredHistory.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-4 text-zinc-400 font-mono text-xs">
                  Belum ada data.
                </td>
              </tr>
            ) : (
              filteredHistory.slice(0, currentLimit).map((bet) => {
                const targetText =
                  bet.game === 'dice'
                    ? `${bet.condition === 'above' ? '>' : '<'}${bet.target.toFixed(2)}`
                    : bet.game === 'plinko'
                    ? `${bet.target}B`
                    : bet.game === 'mines'
                    ? `${bet.target}M`
                    : bet.game === 'diamonds'
                    ? (bet.combinationName || 'Diamonds')
                    : bet.game === 'keno'
                    ? `${bet.kenoSelectedNumbers?.length ?? bet.target} Petak`
                    : `${bet.target.toFixed(2)}x`;

                const resultText =
                  bet.game === 'dice'
                    ? bet.rollResult.toFixed(2)
                    : bet.game === 'limbo'
                    ? `${bet.rollResult.toFixed(2)}x`
                    : bet.game === 'keno'
                    ? `${bet.kenoHitsCount ?? 0} Hit (${bet.multiplier}×)`
                    : `${bet.multiplier.toFixed(2)}x`;

                return (
                  <tr key={bet.id} className={`transition group shadow-2xs rounded-lg overflow-hidden ${bet.won ? 'border-l-4 border-l-emerald-500 bg-emerald-50/30' : 'border-l-4 border-l-rose-500 bg-rose-50/30'}`}>
                    {/* Column 1: Game */}
                    <td className="py-1 px-2 sm:px-2.5 whitespace-nowrap rounded-l-lg">
                      <button
                        type="button"
                        onClick={() => setSelectedBetModal(bet)}
                        className="flex items-center gap-1 font-bold text-emerald-700 hover:underline cursor-pointer transition-transform"
                      >
                        {bet.game === 'dice' ? (
                          <Dices className="w-3 h-3 text-emerald-600 shrink-0" />
                        ) : bet.game === 'limbo' ? (
                          <Rocket className="w-3 h-3 text-cyan-600 shrink-0" />
                        ) : bet.game === 'plinko' ? (
                          <CircleDot className="w-3 h-3 text-amber-500 shrink-0" />
                        ) : bet.game === 'mines' ? (
                          <Bomb className="w-3 h-3 text-amber-600 shrink-0" />
                        ) : bet.game === 'diamonds' ? (
                          <Gem className="w-3 h-3 text-cyan-600 shrink-0" />
                        ) : bet.game === 'keno' ? (
                          <Grid className="w-3 h-3 text-purple-600 shrink-0" />
                        ) : (
                          <Disc className="w-3 h-3 text-indigo-600 shrink-0" />
                        )}
                        <span className="capitalize">{bet.game}</span>
                      </button>
                    </td>

                    {/* Column 2: Waktu (Hidden on very small) */}
                    <td className="py-1 px-2 sm:px-2.5 text-zinc-500 whitespace-nowrap hidden xs:table-cell text-xs font-semibold">
                      {new Date(bet.timestamp).toLocaleTimeString([], {
                        hour12: false,
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>

                    {/* Column 3: Taruhan */}
                    <td className="py-1 px-2 sm:px-2.5 text-right text-zinc-900 font-bold whitespace-nowrap text-xs sm:text-sm tabular-nums">
                      {formatAmount(bet.betAmount)}
                    </td>

                    {/* Column 4: Target | Hasil */}
                    <td className="py-1 px-2 sm:px-2.5 text-center whitespace-nowrap">
                      {bet.game !== 'plinko' && bet.game !== 'mines' && bet.game !== 'diamonds' && (
                        <>
                          <span className="text-zinc-500 font-semibold text-xs">{targetText}</span>
                          <span className="text-zinc-300 mx-0.5 sm:mx-1">|</span>
                        </>
                      )}
                      <span className={`font-bold text-xs sm:text-sm ${bet.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {resultText}
                      </span>
                    </td>

                    {/* Column 5: Result (Payout on win, -BetAmount on loss) */}
                    <td
                      className={`py-1 px-2 sm:px-2.5 text-right font-bold text-xs sm:text-sm whitespace-nowrap tabular-nums rounded-r-lg ${
                        bet.won ? 'text-emerald-600' : 'text-rose-600 font-bold'
                      }`}
                    >
                      {bet.won
                        ? formatAmount(bet.betAmount + bet.profit)
                        : `-${formatAmount(bet.betAmount)}`}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* WHITE THEME BET DETAIL MODAL - MOBILE FRIENDLY & COMPACT */}
      {selectedBetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div
            className="bg-white text-zinc-900 border border-zinc-200 rounded-2xl w-full max-w-sm sm:max-w-md shadow-2xl overflow-hidden flex flex-col font-mono text-xs max-h-[92vh] animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-3 sm:p-3.5 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
              <div className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span className="font-bold text-xs sm:text-sm text-zinc-900">Rincian Taruhan</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBetModal(null)}
                className="p-1 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-200/60 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 sm:p-4 flex flex-col gap-3 overflow-y-auto">
              {/* Game Title & User Info */}
              <div className="text-center space-y-0.5">
                <h3 className="text-lg sm:text-xl font-black capitalize text-zinc-900 tracking-tight">
                  {selectedBetModal.game}
                </h3>
                <p className="text-[11px] text-zinc-500 font-semibold">
                  Ditempatkan oleh <span className="text-emerald-600 font-bold">{displayUsername}</span>
                </p>
                <p className="text-[10px] text-zinc-400 font-medium">
                  {new Date(selectedBetModal.timestamp).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'numeric',
                    year: 'numeric',
                  })}{' '}
                  pada{' '}
                  {new Date(selectedBetModal.timestamp).toLocaleTimeString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>

                {/* Bet ID with Copy */}
                <div className="pt-0.5 flex items-center justify-center gap-1.5 text-[11px] text-zinc-500 max-w-full px-2">
                  <div className="font-mono text-zinc-800 font-bold break-all bg-zinc-100/80 px-2 py-1 rounded-lg border border-zinc-200/60 max-w-full flex items-center gap-1.5">
                    <span className="text-[10px] text-zinc-400 uppercase font-semibold shrink-0">ID:</span>
                    <span className="text-zinc-900 select-all">{formatBetId(selectedBetModal.betId || selectedBetModal.id)}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(formatBetId(selectedBetModal.betId || selectedBetModal.id))}
                      className="p-0.5 text-zinc-400 hover:text-zinc-800 rounded transition cursor-pointer shrink-0 ml-auto"
                      title="Salin ID / Hash Taruhan"
                    >
                      {copiedBetId === formatBetId(selectedBetModal.betId || selectedBetModal.id) ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* 3 Summary Stats Blocks (Taruhan | Pengganda | Pembayaran) */}
              <div className="grid grid-cols-3 gap-1.5 bg-zinc-50 border border-zinc-200 rounded-xl p-2 text-center text-[10px]">
                <div>
                  <span className="text-[9px] text-zinc-400 block font-bold uppercase mb-0.5">Taruhan</span>
                  <div className="font-bold text-[11px] text-zinc-900 truncate">
                    <span>{formatAmount(selectedBetModal.betAmount)}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[9px] text-zinc-400 block font-bold uppercase mb-0.5">Pengganda</span>
                  <div className="font-bold text-[11px] text-zinc-900">
                    {selectedBetModal.multiplier.toFixed(2)}×
                  </div>
                </div>

                <div>
                  <span className="text-[9px] text-zinc-400 block font-bold uppercase mb-0.5">Pembayaran</span>
                  <div
                    className={`font-bold text-[11px] truncate ${
                      selectedBetModal.won ? 'text-emerald-600' : 'text-zinc-400'
                    }`}
                  >
                    <span>
                      {selectedBetModal.won
                        ? formatAmount(selectedBetModal.betAmount + selectedBetModal.profit)
                        : formatAmount(0)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Game Specific Visual Breakdown */}
              {selectedBetModal.game === 'dice' ? (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col gap-2">
                  <div className="relative pt-4 pb-1">
                    <div className="h-2.5 w-full bg-zinc-200 rounded-full overflow-hidden relative">
                      {selectedBetModal.condition === 'above' ? (
                        <div
                          className="absolute right-0 top-0 bottom-0 bg-emerald-500 rounded-r-full"
                          style={{ width: `${100 - selectedBetModal.target}%` }}
                        />
                      ) : (
                        <div
                          className="absolute left-0 top-0 bottom-0 bg-emerald-500 rounded-l-full"
                          style={{ width: `${selectedBetModal.target}%` }}
                        />
                      )}
                    </div>

                    <div
                      className="absolute top-0 -translate-x-1/2 flex flex-col items-center"
                      style={{ left: `${Math.max(4, Math.min(96, selectedBetModal.rollResult))}%` }}
                    >
                      <div
                        className={`px-1.5 py-0.2 rounded font-bold text-[10px] shadow-sm border ${
                          selectedBetModal.won
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : 'bg-rose-600 text-white border-rose-700'
                        }`}
                      >
                        {selectedBetModal.rollResult.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-1 text-center pt-1.5 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Pengganda</span>
                      <span className="font-bold text-zinc-800">{selectedBetModal.multiplier.toFixed(2)}×</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Roll</span>
                      <span className="font-bold text-zinc-800">
                        {selectedBetModal.condition === 'above' ? '>' : '<'} {selectedBetModal.target.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Peluang</span>
                      <span className="font-bold text-emerald-600">
                        {(selectedBetModal.condition === 'above' ? 100 - selectedBetModal.target : selectedBetModal.target).toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              ) : selectedBetModal.game === 'limbo' ? (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col items-center gap-2">
                  <span className="text-[9px] text-zinc-400 font-bold uppercase">Hasil Limbo</span>
                  <div
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {selectedBetModal.rollResult.toFixed(2)}×
                  </div>

                  <div className="w-full grid grid-cols-3 gap-1 text-center pt-2 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Target</span>
                      <span className="font-bold text-zinc-800">{selectedBetModal.target.toFixed(2)}×</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Hasil</span>
                      <span className={`font-bold ${selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {selectedBetModal.rollResult.toFixed(2)}×
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Peluang</span>
                      <span className="font-bold text-emerald-600">
                        {selectedBetModal.target <= 1 ? '99.00%' : `${((99) / selectedBetModal.target).toFixed(2)}%`}
                      </span>
                    </div>
                  </div>
                </div>
              ) : selectedBetModal.game === 'plinko' ? (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col items-center gap-2">
                  <span className="text-[9px] text-zinc-400 font-bold uppercase">Hasil Plinko</span>
                  <div
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {selectedBetModal.multiplier.toFixed(2)}×
                  </div>

                  <div className="w-full grid grid-cols-2 gap-1 text-center pt-2 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Baris</span>
                      <span className="font-bold text-zinc-800">{selectedBetModal.target} Baris</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Status</span>
                      <span className={`font-bold ${selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {selectedBetModal.won ? 'Menang' : 'Kalah'}
                      </span>
                    </div>
                  </div>
                </div>
              ) : selectedBetModal.game === 'mines' ? (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col items-center gap-2">
                  <span className="text-[9px] text-zinc-400 font-bold uppercase">Hasil Mines</span>
                  <div
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {selectedBetModal.multiplier.toFixed(2)}×
                  </div>

                  {/* Compact 5x5 Grid Mini Preview */}
                  {selectedBetModal.minePositions && (
                    <div className="grid grid-cols-5 gap-0.5 w-32 aspect-square p-1.5 bg-zinc-900 rounded-xl shadow-inner">
                      {Array.from({ length: 25 }, (_, idx) => {
                        const isGem = selectedBetModal.revealedFields?.includes(idx);
                        const isMine = selectedBetModal.minePositions?.includes(idx);
                        return (
                          <div
                            key={idx}
                            className={`rounded-sm flex items-center justify-center text-[9px] ${
                              isGem
                                ? 'bg-emerald-500 text-white font-bold'
                                : isMine
                                ? 'bg-rose-600 text-white font-bold'
                                : 'bg-zinc-800 text-zinc-600'
                            }`}
                          >
                            {isGem ? '💎' : isMine ? '💣' : '•'}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="w-full grid grid-cols-3 gap-1 text-center pt-2 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Ranjau</span>
                      <span className="font-bold text-zinc-800">{selectedBetModal.target} Mines</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Berlian</span>
                      <span className="font-bold text-emerald-600">{selectedBetModal.rollResult} Gems</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Status</span>
                      <span className={`font-bold ${selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {selectedBetModal.won ? 'Cashout' : 'Kena Ranjau'}
                      </span>
                    </div>
                  </div>
                </div>
              ) : selectedBetModal.game === 'diamonds' ? (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col items-center gap-2">
                  <span className="text-[9px] text-zinc-400 font-bold uppercase">Hasil Permata</span>
                  <div className="flex items-center justify-center gap-1 sm:gap-1.5 py-1">
                    {(selectedBetModal.diamonds as DiamondColor[] || []).map((color, idx) => (
                      <div key={idx} className="bg-white border border-zinc-100 rounded-lg p-1 shadow-2xs">
                        <DiamondIcon color={color} className="w-7 h-7 sm:w-8 sm:h-8" />
                      </div>
                    ))}
                  </div>

                  <div className="w-full grid grid-cols-2 gap-1 text-center pt-2 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Kombinasi</span>
                      <span className="font-bold text-zinc-800">{selectedBetModal.combinationName || 'Diamonds'}</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Status</span>
                      <span className={`font-bold ${selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {selectedBetModal.won ? 'Menang' : 'Kalah'}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col items-center gap-2">
                  <span className="text-[9px] text-zinc-400 font-bold uppercase">Hasil Taruhan</span>
                  <div
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {selectedBetModal.multiplier.toFixed(2)}×
                  </div>

                  <div className="w-full grid grid-cols-2 gap-1 text-center pt-2 border-t border-zinc-200 text-[10px]">
                    <div>
                      <span className="text-zinc-400 block font-bold">Game</span>
                      <span className="font-bold text-zinc-800 uppercase">{selectedBetModal.game}</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block font-bold">Status</span>
                      <span className={`font-bold ${selectedBetModal.won ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {selectedBetModal.won ? 'Menang' : 'Kalah'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Seed / Provably Fair Info */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-2.5 space-y-1 text-[10px]">
                <span className="text-[9px] text-zinc-500 font-bold uppercase block">Provably Fair Seed</span>
                <div className="flex items-center justify-between text-zinc-600">
                  <span className="text-zinc-400">Client Seed:</span>
                  <span className="font-bold text-zinc-800 truncate max-w-[160px]">{selectedBetModal.clientSeed || 'jstkbot_active_seed'}</span>
                </div>
                <div className="flex items-center justify-between text-zinc-600 truncate">
                  <span className="text-zinc-400 shrink-0 mr-2">Server Seed (Hashed):</span>
                  <span className="font-mono text-[9px] text-zinc-700 truncate">{selectedBetModal.serverSeedHash || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}</span>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-zinc-100 bg-zinc-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedBetModal(null)}
                className="px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-bold text-xs transition cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
