import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Play,
  Square,
  KeyRound,
  ShieldCheck,
  Zap,
  Settings,
  BarChart2,
  PieChart,
  CircleDot,
  Target,
} from 'lucide-react';
import { AutobetConfig, BatchProgress, PlinkoRisk, PlinkoRows, BetResult, PlinkoSavedStrategy, SavedStrategy, StrategySwitchRule } from '../types/stake';
import { PLINKO_PAYOUTS } from '../services/stakeApi';
import { SeedModal } from './SeedModal';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import { GameFooterToolbar } from './GameFooterToolbar';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface PlinkoGameProps {
  balance: number;
  currency: string;
  isRolling: boolean;
  onBet: (amount: number, risk: PlinkoRisk, rows: PlinkoRows) => Promise<boolean>;
  houseEdgePercent: number;
  autobetRunning: boolean;
  onToggleAutobet: (config: AutobetConfig, risk: PlinkoRisk, rows: PlinkoRows) => void;
  onStopAutobet: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  batchProgress?: BatchProgress | null;
  currentStreak?: { type: 'win' | 'loss' | 'none'; count: number };
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin: boolean;
  stopOnLoss: boolean;
  lastBet?: BetResult | null;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

export const PlinkoGame: React.FC<PlinkoGameProps> = ({
  balance,
  currency,
  isRolling,
  onBet,
  houseEdgePercent = 1.0,
  autobetRunning,
  onToggleAutobet,
  onStopAutobet,
  onShowToast,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin,
  stopOnLoss,
  lastBet,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: externalSwitchRulesEnabled = false,
}) => {
  // Mode: Manual vs Otomatis
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies State - starts empty per user request
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() =>
    loadSavedStrategies('plinko')
  );

  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('plinko');
    const activeId = getActiveStrategyId('plinko');
    if (activeId) {
      const found = list.find((s) => s.id === activeId);
      if (found) return found;
    }
    return list.length > 0 ? list[0] : null;
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const handleImportStrategies = (imported: SavedStrategy[]) => {
    setStrategies((prev) => {
      const existingIds = new Set(prev.map((s) => s.id));
      const newItems = imported.filter((s) => !existingIds.has(s.id));
      const updated = [...newItems, ...prev];
      saveSavedStrategies('plinko', updated);
      if (imported[0]) {
        handleSelectStrategy(imported[0]);
      }
      return updated;
    });
  };

  // Bet Amount
  const [betAmount, setBetAmount] = useState<string>(() => {
    const saved = localStorage.getItem('plinko_bet_amount');
    return activeStrategy?.betAmount || (saved === '0.00000001' ? '0' : saved) || '0';
  });

  // Rows & Risk
  const [rows, setRows] = useState<PlinkoRows>(() => {
    const stratRows = (activeStrategy as PlinkoSavedStrategy)?.rows;
    if (stratRows) return stratRows;
    const saved = Number(localStorage.getItem('plinko_rows'));
    return (saved >= 8 && saved <= 16 ? saved : 16) as PlinkoRows;
  });

  const [risk, setRisk] = useState<PlinkoRisk>(() => {
    const stratRisk = (activeStrategy as PlinkoSavedStrategy)?.risk;
    if (stratRisk) return stratRisk;
    const saved = localStorage.getItem('plinko_risk') as PlinkoRisk;
    return saved === 'low' || saved === 'medium' || saved === 'high' || saved === 'expert' ? saved : 'expert';
  });

  // Auto Bet Parameters
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('plinko_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('plinko_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('plinko_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('plinko_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('plinko_on_loss_percent') || '0');
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('plinko_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('plinko_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('plinko_max_bet_cap') || '0');
  const [localStopLoseStreak, setLocalStopLoseStreak] = useState<string>(() => activeStrategy?.stopLoseStreak || (stopLoseStreak > 0 ? String(stopLoseStreak) : localStorage.getItem('plinko_stop_lose_streak') || '0'));
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('plinko_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => localStorage.getItem('plinko_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => localStorage.getItem('plinko_stop_balance_min') || '0');
  const [batchDelayMs, setBatchDelayMs] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('stake_batch_delay_ms'));
      return saved ? Math.max(100, saved) : 100;
    } catch {
      return 100;
    }
  });

  // Dynamic Strategy Switch Rules
  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('plinko'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('plinko'));

  const handleUpdateSwitchRules = (newRules: StrategySwitchRule[]) => {
    setSwitchRules(newRules);
    saveSwitchRules('plinko', newRules);
  };

  const handleToggleSwitchRulesEnabled = (val: boolean) => {
    setSwitchRulesEnabledState(val);
    setSwitchRulesEnabled('plinko', val);
  };

  // Strategy switching handler
  const handleSelectStrategy = (strat: SavedStrategy) => {
    const plinkoStrat = strat as PlinkoSavedStrategy;
    activeStrategyRef.current = strat;
    setActiveStrategy(strat);
    setActiveStrategyId('plinko', strat.id);

    setBetAmount(strat.betAmount !== undefined ? strat.betAmount : '0');
    if (plinkoStrat.risk) setRisk(plinkoStrat.risk);
    if (plinkoStrat.rows) setRows(plinkoStrat.rows);
    
    // Explicitly reset to 0 if not defined in strategy
    setStopHitMultiplier(plinkoStrat.stopHitMultiplier ?? 0);
    
    setNumberOfBets(strat.numberOfBets !== undefined ? strat.numberOfBets : '0');
    setOnWinAction(strat.onWinAction || 'reset');
    setOnWinPercent(strat.onWinPercent !== undefined ? strat.onWinPercent : '0');
    setOnLossAction(strat.onLossAction || 'reset');
    setOnLossPercent(strat.onLossPercent !== undefined ? strat.onLossPercent : '0');
    setStopProfit(strat.stopProfit !== undefined ? strat.stopProfit : '0');
    stopProfitRef.current = parseFloat(strat.stopProfit || '0') || 0;
    setStopLoss(strat.stopLoss !== undefined ? strat.stopLoss : '0');
    stopLossRef.current = parseFloat(strat.stopLoss || '0') || 0;
    setMaxBetCap(strat.maxBetCap !== undefined ? strat.maxBetCap : '0');
    maxBetCapRef.current = parseFloat(strat.maxBetCap || '0') || 0;
    setLocalStopLoseStreak(strat.stopLoseStreak !== undefined ? strat.stopLoseStreak : '0');
    stopLoseStreakRef.current = parseInt(strat.stopLoseStreak || '0', 10) || 0;
    setTrailingStop(strat.trailingStop !== undefined ? strat.trailingStop : '0');
    trailingStopRef.current = parseFloat(strat.trailingStop || '0') || 0;
    setStopWager(strat.stopWager !== undefined ? strat.stopWager : '0');
    stopWagerRef.current = parseFloat(strat.stopWager || '0') || 0;
    setStopBalanceMin(strat.stopBalanceMin !== undefined ? strat.stopBalanceMin : '0');
    stopBalanceMinRef.current = parseFloat(strat.stopBalanceMin || '0') || 0;

    // Apply stop limits and triggers unconditionally so Strategy 2 resets Strategy 1's values
    onUpdateTriggers?.({
      stopOnWin: !!strat.stopOnWin,
      stopOnLoss: !!strat.stopOnLoss,
      stopLoseStreak: parseInt(strat.stopLoseStreak || '0', 10) || 0,
      stopWinStreak: parseInt(strat.stopWinStreak || '0', 10) || 0,
    });

    onShowToast?.('Strategi Dipilih', 'ON', `Mengaktifkan strategi "${strat.name}"`);
  };

  const handleSaveStrategy = (strat: SavedStrategy) => {
    setStrategies((prev) => {
      const idx = prev.findIndex((s) => s.id === strat.id);
      let updated: SavedStrategy[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = strat;
      } else {
        updated = [strat, ...prev];
      }
      saveSavedStrategies('plinko', updated);
      return updated;
    });
    handleSelectStrategy(strat);
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveSavedStrategies('plinko', updated);
      if (activeStrategy?.id === id) {
        const next = updated.length > 0 ? updated[0] : null;
        setActiveStrategy(next);
        if (next) {
          setActiveStrategyId('plinko', next.id);
        } else {
          localStorage.removeItem('stake_active_strategy_plinko');
        }
      }
      return updated;
    });
  };

  // Refs for real-time evaluation
  const stopProfitRef = useRef<number>(parseFloat(stopProfit) || 0);
  const stopLossRef = useRef<number>(parseFloat(stopLoss) || 0);
  const maxBetCapRef = useRef<number>(parseFloat(maxBetCap) || 0);
  const trailingStopRef = useRef<number>(parseFloat(trailingStop) || 0);
  const stopWagerRef = useRef<number>(parseFloat(stopWager) || 0);
  const stopBalanceMinRef = useRef<number>(parseFloat(stopBalanceMin) || 0);
  const stopOnWinRef = useRef<boolean>(stopOnWin);
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);

  useEffect(() => { stopOnWinRef.current = stopOnWin; }, [stopOnWin]);
  useEffect(() => { stopOnLossRef.current = stopOnLoss; }, [stopOnLoss]);
  useEffect(() => {
    if (stopLoseStreak > 0) {
      stopLoseStreakRef.current = stopLoseStreak;
      setLocalStopLoseStreak(String(stopLoseStreak));
    }
  }, [stopLoseStreak]);

  const handleStopProfitChange = (val: string) => {
    setStopProfit(val);
    stopProfitRef.current = parseFloat(val) || 0;
  };

  const handleStopLossChange = (val: string) => {
    setStopLoss(val);
    stopLossRef.current = parseFloat(val) || 0;
  };

  const handleMaxBetCapChange = (val: string) => {
    setMaxBetCap(val);
    maxBetCapRef.current = parseFloat(val) || 0;
  };

  const handleLocalStopLoseStreakChange = (val: string) => {
    setLocalStopLoseStreak(val);
    stopLoseStreakRef.current = parseInt(val, 10) || 0;
  };

  const handleTrailingStopChange = (val: string) => {
    setTrailingStop(val);
    trailingStopRef.current = parseFloat(val) || 0;
  };

  const handleStopWagerChange = (val: string) => {
    setStopWager(val);
    stopWagerRef.current = parseFloat(val) || 0;
  };

  const handleStopBalanceMinChange = (val: string) => {
    setStopBalanceMin(val);
    stopBalanceMinRef.current = parseFloat(val) || 0;
  };

  const [stopHitMultiplier, setStopHitMultiplier] = useState<number>(() => {
    return Number(localStorage.getItem('plinko_stop_hit_multiplier')) || 0;
  });
  const stopHitMultiplierRef = useRef(stopHitMultiplier);
  stopHitMultiplierRef.current = stopHitMultiplier;

  useEffect(() => {
    try {
      localStorage.setItem('plinko_bet_amount', betAmount);
      localStorage.setItem('plinko_rows', rows.toString());
      localStorage.setItem('plinko_risk', risk);
      localStorage.setItem('plinko_num_bets', numberOfBets);
      localStorage.setItem('plinko_on_win_action', onWinAction);
      localStorage.setItem('plinko_on_win_percent', onWinPercent);
      localStorage.setItem('plinko_on_loss_action', onLossAction);
      localStorage.setItem('plinko_on_loss_percent', onLossPercent);
      localStorage.setItem('plinko_stop_profit', stopProfit);
      localStorage.setItem('plinko_stop_loss', stopLoss);
      localStorage.setItem('plinko_max_bet_cap', maxBetCap);
      localStorage.setItem('plinko_stop_lose_streak', localStopLoseStreak);
      localStorage.setItem('plinko_trailing_stop', trailingStop);
      localStorage.setItem('plinko_stop_wager', stopWager);
      localStorage.setItem('plinko_stop_balance_min', stopBalanceMin);
      localStorage.setItem('plinko_stop_hit_multiplier', String(stopHitMultiplier));
      localStorage.setItem('stake_batch_delay_ms', String(batchDelayMs));
    } catch {}
  }, [betAmount, rows, risk, numberOfBets, onWinAction, onWinPercent, onLossAction, onLossPercent, stopProfit, stopLoss, maxBetCap, localStopLoseStreak, trailingStop, stopWager, stopBalanceMin, stopHitMultiplier, batchDelayMs]);

  // Provably Fair Seed State
  const [clientSeed, setClientSeed] = useState<string>(() => {
    try {
      return localStorage.getItem('stake_client_seed') || 'jstkbot_client_seed_x9a82';
    } catch {
      return 'jstkbot_client_seed_x9a82';
    }
  });
  const [serverSeedHash] = useState<string>('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  const [nonce] = useState<number>(1);
  const [isSeedModalOpen, setIsSeedModalOpen] = useState<boolean>(false);

  const handleSaveSeed = (newSeed: string) => {
    setClientSeed(newSeed);
    try {
      localStorage.setItem('stake_client_seed', newSeed);
    } catch {}
    onShowToast?.('Seed Diperbarui', 'ON', `Client Seed berhasil diganti ke "${newSeed}"`);
  };

  useEffect(() => {
    localStorage.setItem('plinko_bet_amount', betAmount);
    localStorage.setItem('plinko_rows', String(rows));
    localStorage.setItem('plinko_risk', risk);
    localStorage.setItem('plinko_num_bets', numberOfBets);
    localStorage.setItem('plinko_on_win_action', onWinAction);
    localStorage.setItem('plinko_on_win_percent', onWinPercent);
    localStorage.setItem('plinko_on_loss_action', onLossAction);
    localStorage.setItem('plinko_on_loss_percent', onLossPercent);
    localStorage.setItem('plinko_stop_profit', stopProfit);
    localStorage.setItem('plinko_stop_loss', stopLoss);
    localStorage.setItem('plinko_stop_hit_multiplier', String(stopHitMultiplier));
  }, [betAmount, rows, risk, numberOfBets, onWinAction, onWinPercent, onLossAction, onLossPercent, stopProfit, stopLoss, stopHitMultiplier]);

  const numericInput = useMemo(() => {
    const parsed = parseFloat(betAmount.replace(',', '.'));
    return isNaN(parsed) || parsed < 0 ? 0 : parsed;
  }, [betAmount]);

  const currentPayouts = useMemo(() => {
    const table = PLINKO_PAYOUTS[rows]?.[risk];
    if (table && table.length > 0) return table;
    return PLINKO_PAYOUTS[16].expert;
  }, [rows, risk]);

  const maxMultiplier = useMemo(() => {
    return Math.max(...currentPayouts);
  }, [currentPayouts]);

  const availableMultipliers = useMemo(() => {
    return Array.from(new Set(currentPayouts)).sort((a, b) => b - a);
  }, [currentPayouts]);

  const sortedAscendingMultipliers = useMemo(() => {
    return Array.from(new Set(currentPayouts)).sort((a, b) => a - b);
  }, [currentPayouts]);

  const hitMultiplier = useMemo(() => {
    if (!lastBet || lastBet.game !== 'plinko') return null;
    return lastBet.multiplier;
  }, [lastBet]);

  const handleMin = () => setBetAmount('0');
  const handleHalf = () => {
    if (numericInput <= 0) {
      setBetAmount('0');
      return;
    }
    setBetAmount(Math.max(0, Number((numericInput / 2).toFixed(8))).toString());
  };
  const handleDouble = () => {
    if (numericInput <= 0) {
      setBetAmount(currency.toLowerCase() === 'idr' ? '1000' : '0.00000001');
      return;
    }
    setBetAmount(Number((numericInput * 2).toFixed(8)).toString());
  };

  const handleSingleBet = async () => {
    if (isRolling || autobetRunning) return;
    await onBet(numericInput, risk, rows);
  };

  const handleStartAutoBet = () => {
    const currentStrat = (activeStrategy || strategies.find(s => s.id === getActiveStrategyId('plinko')) || strategies[0]) as PlinkoSavedStrategy | undefined;

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : numericInput;
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(String(currentStrat.onWinEveryCount), 10) || 1
      : 1;
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(String(currentStrat.onLossEveryCount), 10) || 1
      : 1;
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const autoRisk = currentStrat?.risk || risk;
    const autoRows = currentStrat?.rows || rows;

    const autoConfig: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      stopLoseStreak: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      stopHitMultiplier,
      batchDelayMs,
      onBetAmountChange: (amt) => setBetAmount(amt.toString()),
      switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onSwitchStrategy: (targetStrat) => {
        handleSelectStrategy(targetStrat);
      },
      getLiveTriggers: () => ({
        stopOnWin: stopOnWinRef.current,
        stopOnLoss: stopOnLossRef.current,
        stopLoseStreak: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        maxConsecutiveLosses: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        stopWinStreak: stopWinStreak || 0,
        stopHitMultiplier: stopHitMultiplierRef.current,
        stopProfit: stopProfitRef.current,
        stopLoss: stopLossRef.current,
        maxBetCap: maxBetCapRef.current,
        trailingStop: trailingStopRef.current,
        stopWager: stopWagerRef.current,
        stopBalanceMin: stopBalanceMinRef.current,
        switchRules,
        switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(autoConfig, autoRisk, autoRows);
  };

  const getSlotColor = (mult: number, index: number, total: number) => {
    if (mult >= 1000) return 'bg-amber-500 text-white font-extrabold shadow-xs';
    if (mult >= 100) return 'bg-rose-500 text-white font-bold';
    if (mult >= 10) return 'bg-orange-500 text-white font-bold';
    if (mult >= 2) return 'bg-amber-400 text-amber-950 font-bold';
    if (mult >= 1) return 'bg-emerald-500 text-white font-bold';
    return 'bg-zinc-100 text-zinc-600 font-semibold border border-zinc-200';
  };

  return (
    <div className="flex flex-col gap-3 font-sans">
      {/* Top Game Header Bar */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3 font-sans">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500 text-zinc-950 flex items-center justify-center shadow-xs shrink-0">
            <CircleDot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900 tracking-tight">
                PLINKO
              </h2>
              <span className="text-[9px] bg-amber-100 text-amber-800 border border-amber-200 font-mono font-bold px-1.5 py-0.2 rounded">
                STAKE ORIGINAL
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-zinc-500 font-mono">
              Jatuhkan bola di papan pasak • Max Win 1000.00× • House Edge {houseEdgePercent}%
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3 font-mono text-zinc-900">
        {/* 1. TOP TAB PILL CONTAINER (MANUAL vs OTOMATIS) */}
        <div className="bg-zinc-200/80 p-1 rounded-full grid grid-cols-2 gap-1 w-full max-w-sm mx-auto">
        <button
          type="button"
          onClick={() => {
            if (autobetRunning) return;
            setTabMode('manual');
          }}
          disabled={autobetRunning}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'manual'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Manual</span>
        </button>

        <button
          type="button"
          onClick={() => setTabMode('auto')}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'auto'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Otomatis</span>
          {autobetRunning && <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />}
        </button>
      </div>

      {/* AUTO BET RUNNING STATUS */}
      {autobetRunning && batchProgress && (
        <div className="bg-amber-600 text-white rounded-xl p-3 flex items-center justify-between text-xs shadow-md">
          <div className="space-y-0.5">
            <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>Auto Bet Plinko: Putaran {batchProgress.currentRound} / {batchProgress.totalRounds || '∞'}</span>
              {batchProgress.activeStrategyName && (
                <span className="bg-amber-700/80 px-1.5 py-0.5 rounded text-[10px] font-black border border-amber-300/40">
                  {batchProgress.activeStrategyName}
                </span>
              )}
            </span>
            <span className="text-[10px] text-amber-100 flex items-center gap-2 flex-wrap">
              <span>Profit: <strong>{batchProgress.runningProfit >= 0 ? `+${batchProgress.runningProfit}` : batchProgress.runningProfit} {currency.toUpperCase()}</strong></span>
              {batchProgress.peakProfit !== undefined && batchProgress.peakProfit > 0 && (
                <span>• Puncak: <strong className="text-white">+{batchProgress.peakProfit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 6)}</strong></span>
              )}
              {batchProgress.totalWagered !== undefined && (
                <span>• Wager: <strong>{batchProgress.totalWagered} {currency.toUpperCase()}</strong></span>
              )}
            </span>
          </div>
          <button
            type="button"
            onClick={onStopAutobet}
            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer transition flex items-center gap-1"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Berhenti</span>
          </button>
        </div>
      )}

      {/* MANUAL CONTROLS: MULTIPLIERS STRIP, RISK, ROWS & BET INPUTS */}
      {tabMode === 'manual' && (
        <>
          {/* MULTIPLIERS STRIP */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-zinc-700">
              <span className="flex items-center gap-1.5">
                <CircleDot className="w-3.5 h-3.5 text-amber-500" />
                <span>Multipliers Plinko ({rows} Baris):</span>
              </span>
              <span className="text-amber-600 font-bold text-[10px] uppercase">
                {risk} Risk (Maks {maxMultiplier.toLocaleString()}×)
              </span>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 pt-1">
              {sortedAscendingMultipliers.map((mult, idx) => {
                const isHit = hitMultiplier !== null && Math.abs(mult - hitMultiplier) < 0.0001;
                return (
                  <div
                    key={idx}
                    className={`min-w-[36px] py-1.5 px-1 rounded-xl text-center text-[10px] ${getSlotColor(
                      mult,
                      idx,
                      sortedAscendingMultipliers.length
                    )} ${isHit ? 'ring-2 ring-amber-400 scale-105 font-black' : ''}`}
                  >
                    {mult >= 1000 ? `${(mult / 1000).toFixed(0)}k` : mult}×
                  </div>
                );
              })}
            </div>
          </div>
          {/* RISK & ROWS SELECTORS */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-2.5 space-y-1">
              <label className="text-[10px] font-bold text-zinc-700 block">Tingkat Risiko:</label>
              <div className="grid grid-cols-4 gap-1">
                {(['low', 'medium', 'high', 'expert'] as PlinkoRisk[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    disabled={autobetRunning}
                    onClick={() => setRisk(r)}
                    className={`py-1 rounded text-[9px] font-bold capitalize transition cursor-pointer ${
                      risk === r
                        ? 'bg-zinc-900 text-white'
                        : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                    }`}
                  >
                    {r === 'expert' ? 'Expert' : r}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-2.5 space-y-1">
              <label className="text-[10px] font-bold text-zinc-700 block">Baris Pin: {rows}</label>
              <div className="flex items-center gap-1 overflow-x-auto">
                {([8, 10, 12, 14, 16] as PlinkoRows[]).map((rw) => (
                  <button
                    key={rw}
                    type="button"
                    disabled={autobetRunning}
                    onClick={() => setRows(rw)}
                    className={`flex-1 py-1 rounded text-[9px] font-bold transition cursor-pointer ${
                      rows === rw
                        ? 'bg-amber-500 text-white'
                        : 'bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-100'
                    }`}
                  >
                    {rw}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* BET INPUTS */}
          <div className="flex flex-col gap-2.5 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
            <div className="flex items-center justify-between text-xs font-bold text-zinc-700">
              <span className="text-zinc-900 uppercase">Jumlah Taruhan</span>
              <span className="text-[10px] text-zinc-500 font-normal">
                Saldo: <strong className="text-zinc-900">{balance.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="0"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={autobetRunning}
                  className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 font-mono text-xs sm:text-sm font-bold text-zinc-900 outline-none focus:border-amber-500 transition disabled:opacity-75"
                />
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleMin}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  0
                </button>
                <button
                  onClick={handleHalf}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  ½
                </button>
                <button
                  onClick={handleDouble}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  2×
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* OTOMATIS MODE: TAMPIL HANYA LIST DAFTAR STRATEGI */}
      {tabMode === 'auto' && (
        <div className="space-y-3">
          <AutoBetStrategyManager
            game="plinko"
            currency={currency}
            strategies={strategies}
            activeStrategy={activeStrategy}
            onSelectStrategy={handleSelectStrategy}
            onSaveStrategy={handleSaveStrategy}
            onDeleteStrategy={handleDeleteStrategy}
            onImportStrategies={handleImportStrategies}
            autobetRunning={autobetRunning}
            onShowToast={onShowToast}
            stopProfit={stopProfit}
            onChangeStopProfit={handleStopProfitChange}
            stopLoss={stopLoss}
            onChangeStopLoss={handleStopLossChange}
            maxBetCap={maxBetCap}
            onChangeMaxBetCap={handleMaxBetCapChange}
            maxConsecutiveLosses={localStopLoseStreak}
            onChangeMaxConsecutiveLosses={handleLocalStopLoseStreakChange}
            trailingStop={trailingStop}
            onChangeTrailingStop={handleTrailingStopChange}
            stopWager={stopWager}
            onChangeStopWager={handleStopWagerChange}
            stopBalanceMin={stopBalanceMin}
            onChangeStopBalanceMin={handleStopBalanceMinChange}
            stopOnWin={stopOnWin}
            onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
            stopOnLoss={stopOnLoss}
            onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
            stopWinStreak={String(stopWinStreak)}
            onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
            switchRules={switchRules}
            onChangeSwitchRules={handleUpdateSwitchRules}
            switchRulesEnabled={externalSwitchRulesEnabled || switchRulesEnabled}
            onToggleSwitchRulesEnabled={handleToggleSwitchRulesEnabled}
            renderStrategyForm={(temp, setTemp) => {
              const plinkoStrat = temp as PlinkoSavedStrategy;
              const currentRows = plinkoStrat.rows || 16;
              const currentRisk = plinkoStrat.risk || 'medium';
              const boardPayouts = PLINKO_PAYOUTS[currentRows]?.[currentRisk] || [];
              const availableMultipliers = Array.from(new Set(boardPayouts)).sort((a, b) => b - a);

              return (
                <div className="space-y-3">
                  {/* 1. Base Bet Amount */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Jumlah Taruhan Dasar (Base Amount)
                    </label>
                    <input
                      type="text"
                      value={plinkoStrat.betAmount}
                      onChange={(e) => setTemp({ ...plinkoStrat, betAmount: e.target.value })}
                      placeholder="0"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* 2. Risk & Rows */}
                  <div className="grid grid-cols-2 gap-2 bg-zinc-50 border border-zinc-200 rounded-xl p-3">
                    <div>
                      <label className="text-[10px] text-zinc-500 font-bold uppercase block mb-1">
                        Tingkat Risiko
                      </label>
                      <select
                        value={plinkoStrat.risk}
                        onChange={(e) => setTemp({ ...plinkoStrat, risk: e.target.value as PlinkoRisk })}
                        className="w-full bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-zinc-900 outline-none focus:border-amber-500 cursor-pointer"
                      >
                        <option value="low">Rendah (Low)</option>
                        <option value="medium">Sedang (Medium)</option>
                        <option value="high">Tinggi (High)</option>
                        <option value="expert">Expert (Maks 10.000×)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] text-zinc-500 font-bold uppercase block mb-1">
                        Jumlah Baris Pin
                      </label>
                      <select
                        value={plinkoStrat.rows}
                        onChange={(e) => setTemp({ ...plinkoStrat, rows: Number(e.target.value) as PlinkoRows })}
                        className="w-full bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-zinc-900 outline-none focus:border-amber-500 cursor-pointer"
                      >
                        {[8, 9, 10, 11, 12, 13, 14, 15, 16].map((r) => (
                          <option key={r} value={r}>
                            {r} Baris
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* 3. Berhenti jika Hit Multiplier */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Berhenti jika Hit Multiplier
                    </label>
                    <select
                      value={plinkoStrat.stopHitMultiplier ?? 0}
                      onChange={(e) => setTemp({ ...plinkoStrat, stopHitMultiplier: parseFloat(e.target.value) || 0 })}
                      className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-amber-500 cursor-pointer"
                    >
                      <option value={0}>0 (Matikan / Jangan Berhenti)</option>
                      {availableMultipliers.map((m) => (
                        <option key={m} value={m}>
                          ≥ {m >= 1000 ? `${(m / 1000).toFixed(0)}k` : m}× {m === Math.max(...availableMultipliers) ? '(Maksimal Papan)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 4. Number of bets */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Jumlah Putaran (0 = Tanpa Batas)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={plinkoStrat.numberOfBets}
                      onChange={(e) => setTemp({ ...plinkoStrat, numberOfBets: e.target.value })}
                      placeholder="0"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* 5. Strategy Controls */}
                  <AutoBetStrategyControls
                    onWinAction={plinkoStrat.onWinAction}
                    onChangeOnWinAction={(val) => setTemp({ ...plinkoStrat, onWinAction: val })}
                    onWinPercent={plinkoStrat.onWinPercent}
                    onChangeOnWinPercent={(val) => setTemp({ ...plinkoStrat, onWinPercent: val })}
                    onWinEveryCount={plinkoStrat.onWinEveryCount}
                    onChangeOnWinEveryCount={(val) => setTemp({ ...plinkoStrat, onWinEveryCount: val })}
                    onLossAction={plinkoStrat.onLossAction}
                    onChangeOnLossAction={(val) => setTemp({ ...plinkoStrat, onLossAction: val })}
                    onLossPercent={plinkoStrat.onLossPercent}
                    onChangeOnLossPercent={(val: string) => setTemp({ ...plinkoStrat, onLossPercent: val })}
                    onLossEveryCount={plinkoStrat.onLossEveryCount}
                    onChangeOnLossEveryCount={(val) => setTemp({ ...plinkoStrat, onLossEveryCount: val })}
                    currency={currency}
                    disabled={false}
                  />
                </div>
              );
            }}
          />
        </div>
      )}

      {/* MAIN ACTION BUTTON */}
      <div className="flex flex-col gap-2 pt-1">
        {tabMode === 'manual' ? (
          <button
            type="button"
            onClick={handleSingleBet}
            disabled={isRolling}
            className="w-full py-3.5 rounded-2xl font-mono font-bold text-sm bg-amber-500 hover:bg-amber-600 text-white shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>DROP PLINKO BALL</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (autobetRunning) {
                onStopAutobet();
                return;
              }
              if (isRolling) return; // Wait for last bet
              if (!activeStrategy || strategies.length === 0) {
                onShowToast?.('Strategi Diperlukan', 'OFF', 'Anda wajib menambahkan strategi terlebih dahulu.');
                return;
              }
              handleStartAutoBet();
            }}
            disabled={(!autobetRunning && isRolling) || (!autobetRunning && (!activeStrategy || strategies.length === 0))}
            className={`w-full py-3.5 rounded-2xl font-mono font-bold text-sm shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              autobetRunning || (isRolling && !autobetRunning)
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-amber-500 hover:bg-amber-600 text-white'
            }`}
          >
            {autobetRunning ? (
              <>
                <Square className="w-4 h-4 fill-current" />
                <span>HENTIKAN OTOMATIS</span>
              </>
            ) : isRolling ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>MENGHENTIKAN...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current text-amber-200" />
                <span>
                  {!activeStrategy || strategies.length === 0 
                    ? 'TAMBAH STRATEGI DAHULU' 
                    : `MULAI AUTO BET (${activeStrategy.name})`
                  }
                </span>
              </>
            )}
          </button>
        )}
      </div>

      {/* 2. UNIFIED STAKE-STYLE CONTROLS TOOLBAR */}
      <GameFooterToolbar
        batchDelayMs={batchDelayMs}
        onBatchDelayChange={setBatchDelayMs}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="amber"
      />
    </div>
  </div>
);
};
