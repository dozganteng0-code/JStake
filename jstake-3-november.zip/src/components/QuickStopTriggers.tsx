import React from 'react';
import { Octagon, ShieldAlert, Zap } from 'lucide-react';

interface QuickStopTriggersProps {
  stopOnWin: boolean;
  setStopOnWin: (val: boolean) => void;
  stopOnLoss: boolean;
  setStopOnLoss: (val: boolean) => void;
  stopLoseStreak: number;
  setStopLoseStreak: (val: number) => void;
  stopWinStreak?: number;
  setStopWinStreak?: (val: number) => void;
  currentStreak?: { type: 'win' | 'loss' | 'none'; count: number };
  autobetRunning?: boolean;
  onStopAutobet?: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
}

export const QuickStopTriggers: React.FC<QuickStopTriggersProps> = ({
  stopOnWin,
  setStopOnWin,
  stopOnLoss,
  setStopOnLoss,
  stopLoseStreak,
  setStopLoseStreak,
  stopWinStreak = 0,
  setStopWinStreak,
  currentStreak = { type: 'none', count: 0 },
  autobetRunning = false,
  onStopAutobet,
  onShowToast,
}) => {
  const isLossStreakClose =
    stopLoseStreak > 0 &&
    currentStreak.type === 'loss' &&
    currentStreak.count >= Math.max(1, stopLoseStreak - 2);

  return (
    <div className="bg-white border border-zinc-200 rounded-xl p-2.5 sm:p-3 font-mono shadow-2xs space-y-2">
      {/* Top Header: Title, Live Streak, and Optional Emergency Stop */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-zinc-900 uppercase">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
          <span>Pemicu Berhenti Cepat (Triggers)</span>
        </div>

        {/* Live Streak Status Badge */}
        <div className="flex items-center gap-1.5">
          <div
            className={`px-2 py-0.5 rounded-md text-[9px] sm:text-[10px] font-bold flex items-center gap-1 border ${
              currentStreak.type === 'loss'
                ? isLossStreakClose
                  ? 'bg-rose-100 border-rose-300 text-rose-800 animate-pulse'
                  : 'bg-rose-50 border-rose-200 text-rose-700'
                : currentStreak.type === 'win'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                : 'bg-zinc-100 border-zinc-200 text-zinc-500'
            }`}
          >
            <span>
              {currentStreak.type === 'loss'
                ? `❄️ Streak: ${currentStreak.count}× Kalah`
                : currentStreak.type === 'win'
                ? `🔥 Streak: ${currentStreak.count}× Menang`
                : 'Streak: 0'}
            </span>
            {stopLoseStreak > 0 && currentStreak.type === 'loss' && (
              <span className="text-[9px] opacity-75 font-normal">
                (Stop di {stopLoseStreak}×)
              </span>
            )}
          </div>

          {autobetRunning && onStopAutobet && (
            <button
              type="button"
              onClick={onStopAutobet}
              className="px-2 py-0.5 rounded-md bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shadow-xs animate-bounce"
              title="Batalkan dan hentikan proses taruhan sekarang"
            >
              <Octagon className="w-2.5 h-2.5 fill-current" />
              <span>STOP</span>
            </button>
          )}
        </div>
      </div>

      {/* Trigger Controls Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-1.5 sm:gap-2 pt-1 border-t border-zinc-100 items-center text-[10px] sm:text-[11px]">
        {/* 1. Stop on 1 Win & Stop on 1 Loss */}
        <div className="sm:col-span-4 flex items-center gap-1.5">
          <label
            className={`flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded-lg border cursor-pointer select-none transition font-bold ${
              stopOnWin
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
            }`}
          >
            <input
              type="checkbox"
              checked={stopOnWin}
              onChange={(e) => {
                const next = e.target.checked;
                setStopOnWin(next);
                if (next) {
                  onShowToast?.('Pemicu Win', 'ON', 'Berhenti otomatis begitu 1× WIN.');
                }
              }}
              className="w-3 h-3 text-emerald-600 rounded border-zinc-300 accent-emerald-600 cursor-pointer"
            />
            <span>Stop on Win</span>
          </label>

          <label
            className={`flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded-lg border cursor-pointer select-none transition font-bold ${
              stopOnLoss
                ? 'bg-rose-50 border-rose-300 text-rose-800'
                : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
            }`}
          >
            <input
              type="checkbox"
              checked={stopOnLoss}
              onChange={(e) => {
                const next = e.target.checked;
                setStopOnLoss(next);
                if (next) {
                  onShowToast?.('Pemicu Loss', 'OFF', 'Berhenti otomatis begitu 1× LOSS.');
                }
              }}
              className="w-3 h-3 text-rose-600 rounded border-zinc-300 accent-rose-600 cursor-pointer"
            />
            <span>Stop on Loss</span>
          </label>
        </div>

        {/* 2. Stop on Lose Streak (e.g. 10x) */}
        <div className="sm:col-span-8 flex items-center gap-1.5 bg-zinc-50/80 border border-zinc-200 rounded-lg px-2 py-1 flex-wrap xs:flex-nowrap">
          <div className="flex items-center gap-1 shrink-0 font-bold text-zinc-700">
            <span className="text-rose-600">❄️</span>
            <span>Stop Lose Streak:</span>
          </div>

          <div className="flex items-center gap-1 flex-1">
            <input
              type="number"
              min="0"
              max="999"
              placeholder="0 (Off)"
              value={stopLoseStreak === 0 ? '' : stopLoseStreak}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                const safeVal = isNaN(val) || val <= 0 ? 0 : val;
                setStopLoseStreak(safeVal);
              }}
              className="w-16 bg-white border border-zinc-200 rounded px-1.5 py-0.5 text-center font-bold text-zinc-900 outline-none focus:border-rose-500 text-[10px] sm:text-xs"
              title="Masukkan batas kalah berturut-turut untuk berhenti otomatis (0 untuk menonaktifkan)"
            />
            <span className="text-zinc-500 text-[10px] font-bold">kali</span>

            {/* Quick chips for presets */}
            <div className="flex items-center gap-1 ml-auto">
              {[5, 10, 15].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    const next = stopLoseStreak === preset ? 0 : preset;
                    setStopLoseStreak(next);
                    if (next > 0) {
                      onShowToast?.(
                        `Stop Lose Streak ${next}×`,
                        'ON',
                        `Proses bet akan berhenti otomatis jika kalah ${next}× berturut-turut.`
                      );
                    }
                  }}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-bold border transition cursor-pointer ${
                    stopLoseStreak === preset
                      ? 'bg-rose-600 text-white border-rose-600'
                      : 'bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-100'
                  }`}
                >
                  {preset}×
                </button>
              ))}
              {stopLoseStreak > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setStopLoseStreak(0);
                    onShowToast?.('Lose Streak Nonaktif', 'INFO', 'Pemicu Lose Streak dimatikan.');
                  }}
                  className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-zinc-200 hover:bg-zinc-300 text-zinc-700 transition cursor-pointer"
                >
                  Off
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
