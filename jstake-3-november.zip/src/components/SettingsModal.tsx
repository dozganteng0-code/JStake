import React, { useState } from 'react';
import {
  X,
  Key,
  Globe,
  Zap,
  DollarSign,
  Sliders,
  LogOut,
  Eye,
  EyeOff,
  Check,
  ExternalLink,
  ShieldAlert,
  Search,
  RotateCcw,
  ShieldCheck,
  Activity,
  Layers,
  Copy,
  Radio,
  Server,
  Download,
  Upload,
  FileText,
} from 'lucide-react';
import { RoutingMode, StakeConfig } from '../types/stake';
import {
  DEFAULT_BALANCES_QUERY,
  DEFAULT_DICE_MUTATION,
  DEFAULT_LIMBO_MUTATION,
  DEFAULT_PLINKO_MUTATION,
  DEFAULT_MINES_MUTATION,
  getEffectiveDiceQuery,
  getEffectiveLimboQuery,
  getEffectivePlinkoQuery,
  getEffectiveMinesQuery,
  executeGraphQL,
  testEndpointPing,
} from '../services/stakeApi';
import { STAKE_CRYPTO_LIST } from '../services/fiatRates';
import { OFFICIAL_STAKE_MIRRORS, StakeMirrorItem } from '../data/stakeMirrors';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: StakeConfig;
  onSaveConfig: (newConfig: StakeConfig) => void;
  onRefreshBalance: () => void;
  onDisconnect: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  historyLimit?: 10 | 20;
  onHistoryLimitChange?: (limit: 10 | 20) => void;
}

type TabType = 'token' | 'memory' | 'mirrors' | 'connection' | 'advanced';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onRefreshBalance,
  onDisconnect,
  onShowToast,
  historyLimit: initialHistoryLimit = 20,
  onHistoryLimitChange,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('token');

  // Form states
  const [token, setToken] = useState(config.token || '');
  const [showToken, setShowToken] = useState(false);
  const [endpoint, setEndpoint] = useState(config.endpoint || 'https://stake.bet/_api/graphql');
  const [cookie, setCookie] = useState(config.cookie || '');
  const [routingMode, setRoutingMode] = useState<RoutingMode>(config.routingMode || 'cors-proxy');
  const [corsProxyUrl, setCorsProxyUrl] = useState(config.corsProxyUrl || 'https://corsproxy.io/?url=');
  const [customHeadersJson, setCustomHeadersJson] = useState(config.customHeadersJson || '');
  const [currency, setCurrency] = useState(config.currency || 'btc');

  const [houseEdgePercent, setHouseEdgePercent] = useState<number>(config.houseEdgePercent ?? 1.0);

  // History memory limit
  const [historyLimit, setHistoryLimit] = useState<10 | 20>(config.historyLimit ?? initialHistoryLimit);

  // Import / Export paste state
  const [pasteJson, setPasteJson] = useState('');

  // Toggles
  const [hideZeroBalances, setHideZeroBalances] = useState<boolean>(config.hideZeroBalances ?? false);

  // GraphQL queries
  const [balanceQuery, setBalanceQuery] = useState(config.balanceQueryOverride || DEFAULT_BALANCES_QUERY);
  const [diceQuery, setDiceQuery] = useState(getEffectiveDiceQuery(config.diceQueryOverride));
  const [limboQuery, setLimboQuery] = useState(getEffectiveLimboQuery(config.limboQueryOverride));
  const [plinkoQuery, setPlinkoQuery] = useState(getEffectivePlinkoQuery(config.plinkoQueryOverride));
  const [minesQuery, setMinesQuery] = useState(getEffectiveMinesQuery(config.minesQueryOverride));


  // Connection testing state
  const [isTestingToken, setIsTestingToken] = useState(false);
  const [tokenTestResult, setTokenTestResult] = useState<{
    status: 'idle' | 'success' | 'error';
    message: string;
  }>({ status: 'idle', message: '' });

  // Mirrors testing & filtering
  const [mirrorSearch, setMirrorSearch] = useState('');
  const [mirrorCategoryFilter, setMirrorCategoryFilter] = useState<'all' | 'recommended' | 'official' | 'series1000' | 'series3000'>('all');
  const [pingTestMode, setPingTestMode] = useState<RoutingMode>('cors-proxy');
  const [mirrorPingResults, setMirrorPingResults] = useState<Record<string, { status: 'testing' | 'ok' | 'blocked' | 'error'; latency?: number; message?: string }>>({});
  const [isPingingMirrors, setIsPingingMirrors] = useState(false);

  // Export full settings
  const handleExportFull = (mode: 'download' | 'copy') => {
    const payload = {
      app: 'JStkBot',
      type: 'full_settings',
      version: '1.0',
      exportedAt: new Date().toISOString(),
      config: {
        token: token.trim(),
        endpoint: endpoint.trim(),
        cookie: cookie.trim(),
        routingMode,
        corsProxyUrl: corsProxyUrl.trim(),
        customHeadersJson: customHeadersJson.trim() || undefined,
        currency: currency.toLowerCase(),

        houseEdgePercent,
        hideZeroBalances,
        historyLimit,
        balanceQueryOverride: balanceQuery === DEFAULT_BALANCES_QUERY ? undefined : balanceQuery,
        diceQueryOverride: diceQuery === DEFAULT_DICE_MUTATION ? undefined : diceQuery,
        limboQueryOverride: limboQuery === DEFAULT_LIMBO_MUTATION ? undefined : limboQuery,
        plinkoQueryOverride: plinkoQuery === DEFAULT_PLINKO_MUTATION ? undefined : plinkoQuery,
        minesQueryOverride: minesQuery === DEFAULT_MINES_MUTATION ? undefined : minesQuery,

      },
    };

    const jsonStr = JSON.stringify(payload, null, 2);

    if (mode === 'copy') {
      navigator.clipboard.writeText(jsonStr);
      onShowToast?.('Pengaturan Disalin', 'ON', 'Seluruh konfigurasi JSON berhasil disalin ke clipboard.');
      return;
    }

    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jstkbot_settings_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast?.('Ekspor Berhasil', 'ON', 'File jstkbot_settings.json telah diunduh.');
  };

  // Export Stake API settings only
  const handleExportApiOnly = (mode: 'download' | 'copy') => {
    const payload = {
      app: 'JStkBot',
      type: 'stake_api_config',
      version: '1.0',
      exportedAt: new Date().toISOString(),
      api: {
        token: token.trim(),
        endpoint: endpoint.trim(),
        cookie: cookie.trim(),
        routingMode,
        corsProxyUrl: corsProxyUrl.trim(),
        customHeadersJson: customHeadersJson.trim() || undefined,
        houseEdgePercent,
      },
    };

    const jsonStr = JSON.stringify(payload, null, 2);

    if (mode === 'copy') {
      navigator.clipboard.writeText(jsonStr);
      onShowToast?.('API Config Disalin', 'ON', 'Kredensial API Stake berhasil disalin.');
      return;
    }

    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stake_api_config_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast?.('Ekspor API Berhasil', 'ON', 'File stake_api_config.json telah diunduh.');
  };

  // Parse & apply any JSON config
  const applyImportedData = (rawText: string) => {
    try {
      const data = JSON.parse(rawText.trim());
      const cfg = data.config || data.api || data;

      if (!cfg || typeof cfg !== 'object') {
        throw new Error('Format JSON tidak memuat konfigurasi yang sah.');
      }

      if (typeof cfg.token === 'string') setToken(cfg.token);
      if (typeof cfg.endpoint === 'string') setEndpoint(cfg.endpoint);
      if (typeof cfg.cookie === 'string') setCookie(cfg.cookie);
      if (cfg.routingMode && ['direct', 'cors-proxy', 'proxy'].includes(cfg.routingMode)) {
        setRoutingMode(cfg.routingMode);
      }
      if (typeof cfg.corsProxyUrl === 'string') setCorsProxyUrl(cfg.corsProxyUrl);
      if (typeof cfg.customHeadersJson === 'string') setCustomHeadersJson(cfg.customHeadersJson);
      if (typeof cfg.currency === 'string') setCurrency(cfg.currency);

      if (typeof cfg.houseEdgePercent === 'number') setHouseEdgePercent(cfg.houseEdgePercent);
      if (typeof cfg.hideZeroBalances === 'boolean') setHideZeroBalances(cfg.hideZeroBalances);
      if (cfg.historyLimit === 10 || cfg.historyLimit === 20) {
        setHistoryLimit(cfg.historyLimit);
        onHistoryLimitChange?.(cfg.historyLimit);
      }
      if (typeof cfg.balanceQueryOverride === 'string') setBalanceQuery(cfg.balanceQueryOverride);
      if (typeof cfg.diceQueryOverride === 'string') setDiceQuery(cfg.diceQueryOverride);
      if (typeof cfg.limboQueryOverride === 'string') setLimboQuery(cfg.limboQueryOverride);
      if (typeof cfg.plinkoQueryOverride === 'string') setPlinkoQuery(cfg.plinkoQueryOverride);
      if (typeof cfg.minesQueryOverride === 'string') setMinesQuery(cfg.minesQueryOverride);

      // Auto save to persistent storage immediately
      const updatedConfig: StakeConfig = {
        ...config,
        token: (cfg.token !== undefined ? cfg.token : token).trim(),
        endpoint: (cfg.endpoint !== undefined ? cfg.endpoint : endpoint).trim(),
        cookie: (cfg.cookie !== undefined ? cfg.cookie : cookie).trim(),
        routingMode: cfg.routingMode || routingMode,
        corsProxyUrl: (cfg.corsProxyUrl !== undefined ? cfg.corsProxyUrl : corsProxyUrl).trim(),
        currency: (cfg.currency || currency).toLowerCase(),

        houseEdgePercent: typeof cfg.houseEdgePercent === 'number' ? cfg.houseEdgePercent : houseEdgePercent,
        hideZeroBalances: typeof cfg.hideZeroBalances === 'boolean' ? cfg.hideZeroBalances : hideZeroBalances,
        historyLimit: cfg.historyLimit || historyLimit,
      };

      onSaveConfig(updatedConfig);
      onShowToast?.('Pengaturan Berhasil Diimpor', 'ON', 'Semua konfigurasi telah diperbarui.');

      if (updatedConfig.token) {
        onRefreshBalance();
      }
      return true;
    } catch (err: any) {
      onShowToast?.('Gagal Mengimpor', 'OFF', err.message || 'File JSON tidak valid.');
      return false;
    }
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result;
      if (typeof content === 'string') {
        applyImportedData(content);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleImportPaste = () => {
    if (!pasteJson.trim()) return;
    const ok = applyImportedData(pasteJson);
    if (ok) setPasteJson('');
  };

  if (!isOpen) return null;

  const handleToggleHideZeroBalances = () => {
    const next = !hideZeroBalances;
    setHideZeroBalances(next);
    onShowToast?.(
      'Sembunyikan Saldo Nol',
      next ? 'ON' : 'OFF',
      next ? 'Koin kosong disembunyikan dari daftar' : 'Semua koin ditampilkan'
    );
  };

  const handleSave = () => {
    const updated: StakeConfig = {
      ...config,
      token: token.trim(),
      endpoint: endpoint.trim(),
      cookie: cookie.trim(),
      routingMode,
      corsProxyUrl: corsProxyUrl.trim(),
      customHeadersJson: customHeadersJson.trim() || undefined,
      currency: currency.toLowerCase(),

      houseEdgePercent,
      hideZeroBalances,
      historyLimit,
      balanceQueryOverride: balanceQuery === DEFAULT_BALANCES_QUERY ? undefined : balanceQuery,
      diceQueryOverride: diceQuery === DEFAULT_DICE_MUTATION ? undefined : diceQuery,
      limboQueryOverride: limboQuery === DEFAULT_LIMBO_MUTATION ? undefined : limboQuery,
      plinkoQueryOverride: plinkoQuery === DEFAULT_PLINKO_MUTATION ? undefined : plinkoQuery,
      minesQueryOverride: minesQuery === DEFAULT_MINES_MUTATION ? undefined : minesQuery,

    };
    onSaveConfig(updated);
    if (onHistoryLimitChange) {
      onHistoryLimitChange(historyLimit);
    }
    onClose();
  };

  const handleTestTokenConnection = async () => {
    if (!token.trim()) {
      setTokenTestResult({
        status: 'error',
        message: 'Masukkan Stake Session Token terlebih dahulu.',
      });
      return;
    }

    setIsTestingToken(true);
    setTokenTestResult({ status: 'idle', message: '' });

    try {
      const res = await executeGraphQL<any>(
        DEFAULT_BALANCES_QUERY,
        {},
        {
          ...config,
          token: token.trim(),
          endpoint: endpoint.trim(),
          cookie: cookie.trim(),
          routingMode,
          corsProxyUrl: corsProxyUrl.trim(),
          customHeadersJson: customHeadersJson.trim() || undefined,
        }
      );

      if (res.errors && res.errors.length > 0) {
        setTokenTestResult({
          status: 'error',
          message: res.errors[0]?.message || 'GraphQL error dari Stake',
        });
      } else if (res.data?.user) {
        const username = res.data.user.name || res.data.user.id;
        setTokenTestResult({
          status: 'success',
          message: `Berhasil terhubung sebagai "${username}" (${res.executionMs}ms ping via mode ${routingMode.toUpperCase()})`,
        });
        onRefreshBalance();
      } else {
        setTokenTestResult({
          status: 'error',
          message: 'Response diterima, namun data sesi user kosong. Cek kecocokan token.',
        });
      }
    } catch (err: any) {
      setTokenTestResult({
        status: 'error',
        message: err.message || 'Koneksi gagal',
      });
    } finally {
      setIsTestingToken(false);
    }
  };

  const handlePingAllMirrors = async () => {
    setIsPingingMirrors(true);
    const mirrorsToTest = filteredMirrors.slice(0, 12);
    const initial: typeof mirrorPingResults = { ...mirrorPingResults };

    mirrorsToTest.forEach((m) => {
      initial[m.domain] = { status: 'testing' };
    });
    setMirrorPingResults({ ...initial });

    for (const m of mirrorsToTest) {
      const res = await testEndpointPing(
        m.graphqlUrl,
        pingTestMode,
        token.trim(),
        cookie.trim(),
        corsProxyUrl.trim()
      );
      setMirrorPingResults((prev) => ({
        ...prev,
        [m.domain]: {
          status: res.status,
          latency: res.latency,
          message: res.message,
        },
      }));
    }
    setIsPingingMirrors(false);
  };

  // Filtered mirror list
  const filteredMirrors = OFFICIAL_STAKE_MIRRORS.filter((m) => {
    const matchesSearch =
      m.domain.toLowerCase().includes(mirrorSearch.toLowerCase()) ||
      m.label.toLowerCase().includes(mirrorSearch.toLowerCase()) ||
      (m.notes && m.notes.toLowerCase().includes(mirrorSearch.toLowerCase()));
    const matchesCategory = mirrorCategoryFilter === 'all' || m.category === mirrorCategoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/45 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white border border-zinc-200 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden font-mono">
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-3 border-b border-zinc-200 bg-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 text-white flex items-center justify-center font-bold text-xs">
              S
            </div>
            <div>
              <h2 className="text-sm font-bold text-zinc-900 tracking-tight">PENGATURAN CLIENT STAKE</h2>
              <p className="text-[11px] text-zinc-500">Tersimpan aman secara lokal di browser (localStorage)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 transition cursor-pointer"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Responsive Tab Bar */}
        <div className="flex border-b border-zinc-200 px-3 sm:px-5 bg-zinc-50 overflow-x-auto scrollbar-none gap-1 py-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('token')}
            className={`py-2 px-3 text-xs font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'token'
                ? 'bg-zinc-900 text-white shadow-xs'
                : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Access Token</span>
            {token.trim() && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            )}
          </button>



          <button
            type="button"
            onClick={() => setActiveTab('memory')}
            className={`py-2 px-3 text-xs font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'memory'
                ? 'bg-zinc-900 text-white shadow-xs'
                : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Batas Memori</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('mirrors')}
            className={`py-2 px-3 text-xs font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'mirrors'
                ? 'bg-zinc-900 text-white shadow-xs'
                : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Mirror Stake</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
              activeTab === 'mirrors' ? 'bg-zinc-800 text-zinc-200' : 'bg-emerald-100 text-emerald-800'
            }`}>
              126
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('connection')}
            className={`py-2 px-3 text-xs font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'connection'
                ? 'bg-zinc-900 text-white shadow-xs'
                : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Mode Koneksi & CORS</span>
            <span className="text-[9px] bg-emerald-500 text-white px-1 py-0.2 rounded font-bold">403 Fix</span>
          </button>



          <button
            type="button"
            onClick={() => setActiveTab('advanced')}
            className={`py-2 px-3 text-xs font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'advanced'
                ? 'bg-zinc-900 text-white shadow-xs'
                : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Lanjutan & GraphQL</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* TAB 1: ACCESS TOKEN */}
          {activeTab === 'token' && (
            <div className="space-y-4">
              {/* Token Input Card */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-800 font-bold flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-emerald-600" />
                    <span>STAKE SESSION TOKEN / API KEY (`x-access-token`)</span>
                  </label>
                  {token.trim() ? (
                    <span className="text-[10px] text-emerald-700 bg-emerald-100 font-bold px-1.5 py-0.5 rounded">
                      Terisi
                    </span>
                  ) : (
                    <span className="text-[10px] text-rose-700 bg-rose-100 font-bold px-1.5 py-0.5 rounded">
                      Wajib Diisi
                    </span>
                  )}
                </div>

                <div className="relative">
                  <input
                    type={showToken ? 'text' : 'password'}
                    placeholder="Tempelkan session token Stake Anda di sini..."
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    className="w-full bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs font-mono text-zinc-900 pr-16 outline-none focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setShowToken(!showToken)}
                      className="p-1 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                      title={showToken ? 'Sembunyikan' : 'Tampilkan'}
                    >
                      {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <p className="text-[11px] text-zinc-500 leading-relaxed">
                  Token ini digunakan sebagai otentikasi resmi Stake (`x-access-token`) untuk memeriksa saldo dan memasang taruhan Dice/Limbo.
                </p>
              </div>

              {/* Optional Cookie / cf_clearance */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2">
                <label className="text-zinc-700 font-bold block flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-zinc-500" />
                  <span>COOKIE BROWSER / CLOUDFLARE CLEARANCE (OPSIONAL)</span>
                </label>
                <input
                  type="text"
                  placeholder="cf_clearance=...; session=..."
                  value={cookie}
                  onChange={(e) => setCookie(e.target.value)}
                  className="w-full bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs font-mono text-zinc-800 outline-none focus:border-zinc-400"
                />
              </div>

              {/* Currency Selector (Crypto Active) */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2">
                <label className="text-zinc-800 font-bold block flex items-center justify-between">
                  <span>KOIN KRIPTO AKTIF UTAMA</span>
                  <span className="text-[10px] text-zinc-500 font-normal">21 Kripto Stake Resmi</span>
                </label>
                <select
                  value={currency.toLowerCase()}
                  onChange={(e) => setCurrency(e.target.value.toLowerCase())}
                  className="w-full bg-white border border-zinc-300 rounded-lg px-3 py-2 text-xs font-mono text-zinc-900 outline-none focus:border-zinc-500 cursor-pointer font-bold"
                >
                  {STAKE_CRYPTO_LIST.map((coin) => (
                    <option key={coin.code} value={coin.code.toLowerCase()}>
                      {coin.symbol.toUpperCase()} - {coin.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Test Token Connection Action */}
              <div className="pt-1 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleTestTokenConnection}
                  disabled={isTestingToken || !token.trim()}
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-lg transition text-xs disabled:opacity-50 cursor-pointer"
                >
                  <Activity className={`w-3.5 h-3.5 ${isTestingToken ? 'animate-spin' : ''}`} />
                  <span>{isTestingToken ? 'Menguji Token ke Stake...' : 'Uji Validitas Token'}</span>
                </button>

                {token.trim() && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm('Yakin ingin menghapus session token dan memutuskan sesi?')) {
                        setToken('');
                        onDisconnect();
                      }
                    }}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-lg border border-rose-200 transition cursor-pointer font-bold"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Hapus Token (Disconnect)</span>
                  </button>
                )}
              </div>

              {/* Token test feedback */}
              {tokenTestResult.message && (
                <div
                  className={`p-3 rounded-xl border text-xs leading-relaxed ${
                    tokenTestResult.status === 'success'
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-rose-50 border-rose-300 text-rose-900'
                  }`}
                >
                  <div className="font-bold mb-0.5">
                    {tokenTestResult.status === 'success' ? '✓ Token Sah & Terkoneksi' : '✕ Pengujian Gagal'}
                  </div>
                  <div>{tokenTestResult.message}</div>
                </div>
              )}

              {/* Interactive Step-by-Step Guide */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2.5">
                <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-emerald-600" />
                  <span>Cara Mengambil Token dari Stake (PC & HP):</span>
                </div>
                <div className="space-y-2 text-[11px] text-zinc-600 leading-relaxed">
                  <div className="p-2 bg-white rounded-lg border border-zinc-200">
                    <strong className="text-zinc-900 block mb-0.5">💻 Pada Komputer / Laptop (Chrome / Edge / Brave):</strong>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Buka situs Stake (contoh: <code>stake.bet</code> atau <code>stake.games</code>) dan login.</li>
                      <li>Tekan <strong>F12</strong> untuk membuka DevTools, klik tab <strong>Network</strong>.</li>
                      <li>Ketik <code className="bg-zinc-100 px-1 py-0.2 rounded font-bold">graphql</code> pada kotak filter pencarian.</li>
                      <li>Lakukan 1 klik refresh saldo di Stake atau ganti halaman game.</li>
                      <li>Klik salah satu request <code>graphql</code> &gt; pilih tab <strong>Headers</strong> &gt; cari <strong>x-access-token</strong>.</li>
                      <li>Salin token tersebut dan tempel ke kolom di atas.</li>
                    </ol>
                  </div>

                  <div className="p-2 bg-white rounded-lg border border-zinc-200">
                    <strong className="text-zinc-900 block mb-0.5">📱 Pada HP Android:</strong>
                    <p>
                      Gunakan browser dengan fitur Inspect seperti <strong>Kiwi Browser</strong> atau <strong>Hermit Browser</strong>, buka Developer Tools &gt; Network &gt; cari header <code>x-access-token</code> saat login ke Stake.
                    </p>
                  </div>
                </div>
              </div>

              {/* EXPORT & IMPORT API STAKE CONFIGURATION */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between border-b border-zinc-200/80 pb-2">
                  <div className="font-bold text-zinc-900 flex items-center gap-1.5 text-xs">
                    <Download className="w-4 h-4 text-emerald-600" />
                    <span>EKSPOR &amp; IMPOR SETTING API STAKE</span>
                  </div>
                  <span className="text-[10px] text-zinc-400">Khusus Kredensial API</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Export API Stake Button */}
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleExportApiOnly('download')}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl transition text-xs cursor-pointer shadow-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Ekspor API (.JSON)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleExportApiOnly('copy')}
                      className="flex items-center justify-center gap-1 py-2 px-2.5 bg-white border border-zinc-200 hover:bg-zinc-100 text-zinc-800 font-bold rounded-xl transition text-xs cursor-pointer"
                      title="Salin JSON API ke Clipboard"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Import API Stake Button */}
                  <div className="relative">
                    <label className="flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition text-xs cursor-pointer shadow-xs w-full text-center">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Impor API (.JSON)</span>
                      <input
                        type="file"
                        accept=".json,application/json"
                        onChange={handleImportFile}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* Paste Raw JSON Area for API Stake */}
                <div className="pt-2 border-t border-zinc-200/80 space-y-1.5">
                  <span className="text-[10px] text-zinc-500 font-bold block">Atau Tempel Teks JSON API Stake:</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder='{"api": {"token": "...", "endpoint": "..."}}'
                      value={pasteJson}
                      onChange={(e) => setPasteJson(e.target.value)}
                      className="flex-1 bg-white border border-zinc-300 rounded-lg px-2.5 py-1.5 text-[11px] font-mono outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={handleImportPaste}
                      disabled={!pasteJson.trim()}
                      className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold rounded-lg transition text-xs cursor-pointer shadow-xs whitespace-nowrap"
                    >
                      Terapkan
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: MEMORI */}
          {activeTab === 'memory' && (
            <div className="space-y-4">
              {/* Riwayat Memory Limit */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-zinc-900 text-xs flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-emerald-600" />
                      <span>Batas Riwayat Taruhan (Memory Saver)</span>
                    </h4>
                    <p className="text-[11px] text-zinc-500 mt-0.5">
                      Membatasi riwayat tersimpan di browser agar performa web tetap enteng &amp; cepat.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-zinc-200">
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryLimit(10);
                        onHistoryLimitChange?.(10);
                      }}
                      className={`px-3 py-1.5 rounded text-xs font-bold transition cursor-pointer ${
                        historyLimit === 10
                          ? 'bg-zinc-900 text-white'
                          : 'text-zinc-600 hover:text-zinc-900'
                      }`}
                    >
                      10 Data (Paling Ringan)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setHistoryLimit(20);
                        onHistoryLimitChange?.(20);
                      }}
                      className={`px-3 py-1.5 rounded text-xs font-bold transition cursor-pointer ${
                        historyLimit === 20
                          ? 'bg-zinc-900 text-white'
                          : 'text-zinc-600 hover:text-zinc-900'
                      }`}
                    >
                      20 Data (Standar)
                    </button>
                  </div>
                </div>
                {/* Sembunyikan Saldo Nol */}
                <div className="pt-2 border-t border-zinc-200 flex items-start justify-between gap-3">
                  <div className="space-y-0.5">
                    <span className="font-bold text-zinc-900 block">
                      Sembunyikan saldo nol (Hide Zero Balances)
                    </span>
                    <p className="text-[11px] text-zinc-500 leading-tight">
                      Apabila aktif, koin dengan saldo 0 dihilangkan dari daftar dompet.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleToggleHideZeroBalances}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                      hideZeroBalances ? 'bg-emerald-600' : 'bg-zinc-300'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        hideZeroBalances ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MIRRORS */}
          {activeTab === 'mirrors' && (
            <div className="space-y-4">
              {/* Header Box */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-zinc-900 flex items-center gap-1.5 text-sm">
                      <Globe className="w-4 h-4 text-emerald-600" />
                      <span>Daftar 126 Mirror Resmi Stake</span>
                    </div>
                    <p className="text-[11px] text-zinc-500 mt-0.5">
                      Sumber resmi terverifikasi dari <a href="https://playstake.io/#mirrors" target="_blank" rel="noreferrer" className="text-zinc-900 font-bold underline inline-flex items-center gap-0.5">playstake.io/#mirrors <ExternalLink className="w-3 h-3" /></a>
                    </p>
                  </div>

                  {/* Ping test trigger */}
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <select
                      value={pingTestMode}
                      onChange={(e) => setPingTestMode(e.target.value as RoutingMode)}
                      className="bg-white border border-zinc-300 rounded-lg px-2 py-1.5 text-[11px] text-zinc-800 outline-none cursor-pointer"
                      title="Metode Ping"
                    >
                      <option value="cors-proxy">Ping via CORS Proxy (Bebas 403)</option>
                      <option value="direct">Ping via Direct Browser</option>
                      <option value="proxy">Ping via Server Proxy</option>
                    </select>

                    <button
                      type="button"
                      onClick={handlePingAllMirrors}
                      disabled={isPingingMirrors}
                      className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg font-bold text-xs flex items-center gap-1 transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
                    >
                      <Zap className={`w-3.5 h-3.5 ${isPingingMirrors ? 'animate-spin text-amber-300' : 'text-emerald-400'}`} />
                      <span>{isPingingMirrors ? 'Menguji...' : 'Uji Ping'}</span>
                    </button>
                  </div>
                </div>

                {/* Search & Categories Filter */}
                <div className="space-y-2 pt-1 border-t border-zinc-200/80">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Cari domain mirror (contoh: stake.bet, stake.games, 1020)..."
                      value={mirrorSearch}
                      onChange={(e) => setMirrorSearch(e.target.value)}
                      className="w-full bg-white border border-zinc-300 rounded-lg pl-9 pr-3 py-1.5 text-xs text-zinc-900 outline-none focus:border-zinc-500"
                    />
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {[
                      { id: 'all', label: 'Semua (126)' },
                      { id: 'recommended', label: '★ Rekomendasi' },
                      { id: 'official', label: 'Official / Regional' },
                      { id: 'series1000', label: 'Seri 1000' },
                      { id: 'series3000', label: 'Seri 3000' },
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setMirrorCategoryFilter(cat.id as any)}
                        className={`text-[10px] px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                          mirrorCategoryFilter === cat.id
                            ? 'bg-zinc-900 text-white'
                            : 'bg-white border border-zinc-200 text-zinc-600 hover:bg-zinc-100'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Active Mirror Info */}
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
                <div className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                  <span>Mirror Aktif Dipilih:</span>
                  <span className="font-bold underline">{endpoint}</span>
                </div>
              </div>

              {/* Mirror Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[360px] overflow-y-auto pr-1">
                {filteredMirrors.map((m) => {
                  const isSelected = endpoint === m.graphqlUrl;
                  const ping = mirrorPingResults[m.domain];

                  return (
                    <div
                      key={m.domain}
                      onClick={() => setEndpoint(m.graphqlUrl)}
                      className={`p-3 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/50 shadow-xs ring-1 ring-emerald-500/30'
                          : 'border-zinc-200 bg-zinc-50 hover:bg-zinc-100/80 text-zinc-800'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-bold text-xs flex items-center gap-1.5 text-zinc-900">
                            <span>{m.domain}</span>
                            {isSelected && <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />}
                          </div>
                          <div className="text-[10px] text-zinc-500 mt-0.5">{m.notes || m.label}</div>
                        </div>

                        <span
                          className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                            m.category === 'recommended'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-zinc-200 text-zinc-700'
                          }`}
                        >
                          {m.category === 'recommended' ? 'Top' : m.category}
                        </span>
                      </div>

                      {/* Ping status badge */}
                      <div className="mt-2.5 pt-1.5 border-t border-zinc-200/70 flex items-center justify-between text-[10px]">
                        {ping ? (
                          <>
                            <span
                              className={`font-bold flex items-center gap-1 ${
                                ping.status === 'ok'
                                  ? 'text-emerald-700'
                                  : ping.status === 'testing'
                                  ? 'text-amber-600'
                                  : 'text-rose-600'
                              }`}
                            >
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  ping.status === 'ok'
                                    ? 'bg-emerald-500'
                                    : ping.status === 'testing'
                                    ? 'bg-amber-500 animate-pulse'
                                    : 'bg-rose-500'
                                }`}
                              />
                              <span>{ping.message || (ping.status === 'ok' ? 'Online' : 'Gagal')}</span>
                            </span>
                            {ping.latency !== undefined && (
                              <span className="text-zinc-500 font-mono font-bold">{ping.latency}ms</span>
                            )}
                          </>
                        ) : (
                          <span className="text-zinc-400">Klik "Uji Ping" untuk tes</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: MODE KONEKSI & CORS / DIRECT (SOLUSI 403) */}
          {activeTab === 'connection' && (
            <div className="space-y-4">
              {/* Explanation of 403 & Resolution */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 space-y-2 text-amber-950">
                <div className="flex items-center gap-1.5 font-bold text-amber-900 text-xs">
                  <ShieldAlert className="w-4 h-4 text-amber-700" />
                  <span>KENAPA MUNCUL HTTP 403 & BAGAIMANA SOLUSINYA?</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  <strong>Penyebab 403:</strong> Stake dan Cloudflare WAF memblokir rentang IP data center hosting server (seperti Google Cloud). Oleh karena itu, jika menggunakan mode server proxy bawaan, Cloudflare akan merespon dengan status <em>403 Forbidden</em>.
                </p>
                <p className="text-[11px] leading-relaxed">
                  <strong>Solusi:</strong> Pilih <strong>CORS Unblocker Proxy</strong> atau <strong>Direct Fetch</strong> di bawah ini agar request lolos dari blokir Cloudflare.
                </p>
              </div>

              {/* Mode Selection Cards */}
              <div className="space-y-2.5">
                <label className="text-zinc-800 font-bold block">PILIH MODE ROUTING KONEKSI:</label>

                {/* Option 1: CORS Proxy (Recommended) */}
                <div
                  onClick={() => setRoutingMode('cors-proxy')}
                  className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start gap-3 ${
                    routingMode === 'cors-proxy'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-xs ring-1 ring-emerald-500/20'
                      : 'border-zinc-200 bg-zinc-50 hover:bg-zinc-100'
                  }`}
                >
                  <input
                    type="radio"
                    name="routingMode"
                    checked={routingMode === 'cors-proxy'}
                    onChange={() => setRoutingMode('cors-proxy')}
                    className="mt-0.5 text-emerald-600 cursor-pointer"
                  />
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-xs text-zinc-900 flex items-center gap-1.5">
                        <span>1. CORS Unblocker Proxy</span>
                        <span className="bg-emerald-600 text-white text-[9px] px-1.5 py-0.2 rounded font-bold">
                          PALING DIREKOMENDASIKAN
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-zinc-600 leading-relaxed">
                      Mengirim request GraphQL melalui relay CORS publik terpercaya (<code>corsproxy.io</code>). Bebas dari blokir 403 Cloudflare data center dan bebas dari pembatasan browser CORS.
                    </p>
                  </div>
                </div>

                {/* Option 2: Direct Fetch */}
                <div
                  onClick={() => setRoutingMode('direct')}
                  className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start gap-3 ${
                    routingMode === 'direct'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-xs ring-1 ring-emerald-500/20'
                      : 'border-zinc-200 bg-zinc-50 hover:bg-zinc-100'
                  }`}
                >
                  <input
                    type="radio"
                    name="routingMode"
                    checked={routingMode === 'direct'}
                    onChange={() => setRoutingMode('direct')}
                    className="mt-0.5 text-emerald-600 cursor-pointer"
                  />
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-xs text-zinc-900 flex items-center gap-1.5">
                        <span>2. Direct Fetch (IP Asli Perangkat Anda)</span>
                        <span className="bg-zinc-800 text-zinc-200 text-[9px] px-1.5 py-0.2 rounded font-bold">
                          Bebas 403
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-zinc-600 leading-relaxed">
                      Langsung mengirim request dari browser dan IP asli HP/laptop Anda ke Stake tanpa proxy perantara. Tidak akan diblokir Cloudflare. (Catatan: Memerlukan ekstensi browser Allow CORS di desktop atau browser mobile dengan CORS bypass).
                    </p>
                  </div>
                </div>

                {/* Option 3: Local Server Proxy */}
                <div
                  onClick={() => setRoutingMode('proxy')}
                  className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start gap-3 ${
                    routingMode === 'proxy'
                      ? 'border-zinc-900 bg-zinc-100/90 shadow-xs'
                      : 'border-zinc-200 bg-zinc-50 hover:bg-zinc-100'
                  }`}
                >
                  <input
                    type="radio"
                    name="routingMode"
                    checked={routingMode === 'proxy'}
                    onChange={() => setRoutingMode('proxy')}
                    className="mt-0.5 text-zinc-900 cursor-pointer"
                  />
                  <div className="flex-1 space-y-1">
                    <div className="font-bold text-xs text-zinc-900">
                      3. Local Server Proxy (`/api/stake-graphql`)
                    </div>
                    <p className="text-[11px] text-zinc-600 leading-relaxed">
                      Mengirim request melalui backend proxy internal aplikasi. Dapat terkena 403 jika Cloudflare memblokir IP cloud, kecuali jika menyertakan cookie clearance yang valid.
                    </p>
                  </div>
                </div>
              </div>

              {/* CORS Proxy URL Config */}
              {routingMode === 'cors-proxy' && (
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2">
                  <label className="text-zinc-800 font-bold block">
                    URL CORS PROXY (RELAY)
                  </label>
                  <input
                    type="text"
                    value={corsProxyUrl}
                    onChange={(e) => setCorsProxyUrl(e.target.value)}
                    placeholder="https://corsproxy.io/?url="
                    className="w-full bg-white border border-zinc-300 rounded-lg px-3 py-1.5 text-xs text-zinc-900 outline-none focus:border-zinc-500 font-mono"
                  />
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setCorsProxyUrl('https://corsproxy.io/?url=')}
                      className="text-[10px] px-2 py-0.5 rounded bg-zinc-200 text-zinc-700 hover:bg-zinc-300 cursor-pointer font-bold"
                    >
                      corsproxy.io (Default Cepat)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCorsProxyUrl('https://api.allorigins.win/raw?url=')}
                      className="text-[10px] px-2 py-0.5 rounded bg-zinc-200 text-zinc-700 hover:bg-zinc-300 cursor-pointer font-bold"
                    >
                      allorigins.win
                    </button>
                  </div>
                </div>
              )}

              {/* Custom Headers JSON */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2">
                <label className="text-zinc-700 font-bold block">
                  CUSTOM HEADERS JSON (OPSIONAL)
                </label>
                <textarea
                  rows={2}
                  placeholder='{"cf-connecting-ip": "1.1.1.1"}'
                  value={customHeadersJson}
                  onChange={(e) => setCustomHeadersJson(e.target.value)}
                  className="w-full bg-white border border-zinc-300 rounded-lg p-2 text-xs font-mono text-zinc-800 outline-none focus:border-zinc-400"
                />
              </div>
            </div>
          )}


          {/* TAB 5: LANJUTAN & GRAPHQL */}
          {activeTab === 'advanced' && (
            <div className="space-y-4">
              {/* House Edge */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-800 font-bold">HOUSE EDGE (%)</label>
                  <span className="font-bold text-zinc-900">{houseEdgePercent}%</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="5.0"
                  step="0.1"
                  value={houseEdgePercent}
                  onChange={(e) => setHouseEdgePercent(parseFloat(e.target.value))}
                  className="w-full accent-zinc-900 cursor-pointer"
                />
                <p className="text-[10px] text-zinc-500">
                  Default Stake Original Dice & Limbo adalah 1.0% house edge (99% RTP).
                </p>
              </div>

              {/* GraphQL Document Overrides */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[11px] text-zinc-500">
                  <span className="font-bold text-zinc-800">SKEMA GRAPHQL KUSTOM:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setBalanceQuery(DEFAULT_BALANCES_QUERY);
                      setDiceQuery(DEFAULT_DICE_MUTATION);
                      setLimboQuery(DEFAULT_LIMBO_MUTATION);
                      setPlinkoQuery(DEFAULT_PLINKO_MUTATION);
                      setMinesQuery(DEFAULT_MINES_MUTATION);

                    }}
                    className="text-zinc-700 hover:text-zinc-900 underline cursor-pointer font-bold flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset Default GraphQL</span>
                  </button>
                </div>

                <div>
                  <label className="text-zinc-700 font-bold block mb-1">BALANCES QUERY</label>
                  <textarea
                    rows={3}
                    value={balanceQuery}
                    onChange={(e) => setBalanceQuery(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg p-2 font-mono text-[11px] text-zinc-800 outline-none"
                  />
                </div>

                <div>
                  <label className="text-zinc-700 font-bold block mb-1">DICE MUTATION</label>
                  <textarea
                    rows={3}
                    value={diceQuery}
                    onChange={(e) => setDiceQuery(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg p-2 font-mono text-[11px] text-zinc-800 outline-none"
                  />
                </div>

                <div>
                  <label className="text-zinc-700 font-bold block mb-1">LIMBO MUTATION</label>
                  <textarea
                    rows={3}
                    value={limboQuery}
                    onChange={(e) => setLimboQuery(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg p-2 font-mono text-[11px] text-zinc-800 outline-none"
                  />
                </div>

                <div>
                  <label className="text-zinc-700 font-bold block mb-1">PLINKO MUTATION</label>
                  <textarea
                    rows={3}
                    value={plinkoQuery}
                    onChange={(e) => setPlinkoQuery(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg p-2 font-mono text-[11px] text-zinc-800 outline-none"
                  />
                </div>

                <div>
                  <label className="text-zinc-700 font-bold block mb-1">MINES MUTATION</label>
                  <textarea
                    rows={3}
                    value={minesQuery}
                    onChange={(e) => setMinesQuery(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg p-2 font-mono text-[11px] text-zinc-800 outline-none"
                  />
                </div>


              </div>

              {/* Danger Zone */}
              <div className="pt-2 border-t border-zinc-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Reset seluruh pengaturan ke default pabrik?')) {
                      setToken('');
                      setEndpoint('https://stake.bet/_api/graphql');
                      setRoutingMode('cors-proxy');
                      setCorsProxyUrl('https://corsproxy.io/?url=');

                      setHideZeroBalances(false);
                      setBalanceQuery(DEFAULT_BALANCES_QUERY);
                      setDiceQuery(DEFAULT_DICE_MUTATION);
                      setLimboQuery(DEFAULT_LIMBO_MUTATION);
                      setPlinkoQuery(DEFAULT_PLINKO_MUTATION);
                      setMinesQuery(DEFAULT_MINES_MUTATION);

                      onDisconnect();
                    }
                  }}
                  className="px-3 py-1.5 rounded-lg border border-zinc-300 text-zinc-700 hover:bg-zinc-100 text-xs font-bold transition cursor-pointer"
                >
                  Reset ke Setelan Default
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Sticky Footer */}
        <div className="px-4 sm:px-5 py-3 border-t border-zinc-200 flex items-center justify-between bg-zinc-50">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl text-zinc-600 hover:text-zinc-900 transition font-bold text-xs cursor-pointer"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-bold transition text-xs shadow-sm cursor-pointer flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
            <span>Simpan Pengaturan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
