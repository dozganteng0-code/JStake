import React from 'react';
import { CheckCircle2, XCircle, Info, X } from 'lucide-react';

export interface ToastData {
  id: string;
  title: string;
  status: 'ON' | 'OFF' | 'INFO';
  message?: string;
}

interface ToastProps {
  toasts: ToastData[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  // Enforce max 2 active toasts display
  const activeToasts = toasts.slice(-2);

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-2 w-[calc(100vw-2rem)] sm:w-auto max-w-xs pointer-events-none font-mono">
      {activeToasts.map((toast) => {
        const isOn = toast.status === 'ON';
        const isOff = toast.status === 'OFF';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start justify-between gap-3 px-3.5 py-2.5 rounded-2xl border shadow-xl backdrop-blur-md transition-all duration-200 animate-in fade-in slide-in-from-top-2 text-xs ${
              isOn
                ? 'bg-white/95 border-emerald-300/80 text-zinc-900 shadow-emerald-500/10'
                : isOff
                ? 'bg-white/95 border-rose-300/80 text-zinc-900 shadow-rose-500/10'
                : 'bg-white/95 border-zinc-200 text-zinc-900 shadow-zinc-500/10'
            }`}
          >
            <div className="flex items-start gap-2.5 min-w-0 flex-1">
              {isOn ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : isOff ? (
                <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              ) : (
                <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              )}
              <div className="flex flex-col min-w-0 flex-1">
                <span className="font-black text-zinc-900 text-[11px] sm:text-xs leading-tight break-words">
                  {toast.title}
                </span>
                {toast.message && (
                  <p className="text-[10px] sm:text-[11px] text-zinc-600 leading-normal break-words mt-0.5 font-sans font-medium">
                    {toast.message}
                  </p>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition cursor-pointer shrink-0 -mr-1 -mt-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
