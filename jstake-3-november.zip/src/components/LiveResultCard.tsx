import React from 'react';
import { BetResult } from '../types/stake';
import { ArrowUpRight, ArrowDownRight, Zap } from 'lucide-react';
import { formatBetId } from '../services/stakeApi';

interface LiveResultCardProps {
  lastBet: BetResult | null;
  currency: string;
  isRolling: boolean;
}

export const LiveResultCard: React.FC<LiveResultCardProps> = ({
  lastBet,
  currency,
  isRolling,
}) => {
  if (!lastBet) {
    return (
      <div className="bg-white border border-zinc-200 rounded-xl px-3.5 py-2.5 flex items-center justify-between text-zinc-500 text-xs font-mono">
        <span className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isRolling ? 'bg-emerald-500 animate-ping' : 'bg-emerald-500'}`} />
          {isRolling ? 'Mengirim taruhan...' : 'Hasil taruhan live akan muncul di sini'}
        </span>
        <span className="text-zinc-400 text-[11px]">{isRolling ? 'rolling...' : '0ms'}</span>
      </div>
    );
  }

  const isWin = lastBet.won;

  return (
    <div
      className={`rounded-xl border bg-white px-3 py-1.5 transition flex items-center justify-between gap-2 font-mono shadow-sm ${
        isWin ? 'border-emerald-400 bg-emerald-50/10' : 'border-rose-300 bg-rose-50/10'
      }`}
    >
      {/* Left: Result */}
      <div className="flex items-center gap-2 min-w-0">
        <span
          className={`text-lg sm:text-xl font-black tabular-nums shrink-0 ${
            isWin ? 'text-emerald-600' : 'text-rose-600'
          }`}
        >
          {lastBet.game === 'dice'
            ? lastBet.rollResult.toFixed(2)
            : lastBet.game === 'limbo'
            ? `${lastBet.rollResult.toFixed(2)}x`
            : `${lastBet.multiplier.toFixed(2)}x`}
        </span>

        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1">
            <span
              className={`text-[9px] uppercase font-bold px-1 rounded shrink-0 ${
                isWin ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}
            >
              {isWin ? 'WIN' : 'LOSS'}
            </span>
            <span className="text-[10px] text-zinc-500 font-medium truncate">
              {lastBet.game === 'dice'
                ? `Tgt: ${lastBet.condition === 'above' ? '>' : '<'}${lastBet.target.toFixed(1)}`
                : lastBet.game === 'limbo'
                ? `Tgt: ${lastBet.target.toFixed(1)}x`
                : lastBet.game === 'diamonds'
                ? (lastBet.combinationName || 'Diamonds')
                : lastBet.game === 'keno'
                ? `${lastBet.kenoHitsCount ?? 0}/${lastBet.kenoSelectedNumbers?.length ?? 0} Hit`
                : `${lastBet.target.toFixed(1)}x`}
            </span>
          </div>
        </div>
      </div>

      {/* Right: Profit */}
      <div className="text-right flex items-center gap-2">
        <div
          className={`text-sm font-bold flex items-center gap-0.5 tabular-nums ${
            isWin ? 'text-emerald-600' : 'text-rose-600'
          }`}
        >
          <span>
            {isWin ? '+' : ''}
            {lastBet.profit.toFixed(
              currency.toLowerCase() === 'idr' ? 0 : 6
            )}
          </span>
          <span className="text-[9px] uppercase text-zinc-400 font-normal">{lastBet.currency}</span>
        </div>
        <div className="hidden sm:flex items-center gap-0.5 text-[9px] text-zinc-300">
          <Zap className="w-2.5 h-2.5" />
          <span>{lastBet.durationMs}ms</span>
        </div>
      </div>
    </div>
  );
};
