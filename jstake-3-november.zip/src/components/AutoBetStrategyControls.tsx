import React from 'react';

interface AutoBetStrategyControlsProps {
  onWinAction: 'reset' | 'increase';
  onChangeOnWinAction: (val: 'reset' | 'increase') => void;
  onWinPercent: string;
  onChangeOnWinPercent: (val: string) => void;
  onWinEveryCount?: string;
  onChangeOnWinEveryCount?: (val: string) => void;
  onLossAction: 'reset' | 'increase';
  onChangeOnLossAction: (val: 'reset' | 'increase') => void;
  onLossPercent: string;
  onChangeOnLossPercent: (val: string) => void;
  onLossEveryCount?: string;
  onChangeOnLossEveryCount?: (val: string) => void;
  currency?: string;
  disabled?: boolean;
}

export const AutoBetStrategyControls: React.FC<AutoBetStrategyControlsProps> = ({
  onWinAction,
  onChangeOnWinAction,
  onWinPercent,
  onChangeOnWinPercent,
  onWinEveryCount = '1',
  onChangeOnWinEveryCount,
  onLossAction,
  onChangeOnLossAction,
  onLossPercent,
  onChangeOnLossPercent,
  onLossEveryCount = '1',
  onChangeOnLossEveryCount,
  disabled = false,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 font-mono text-xs">
      {/* ON WIN ACTION */}
      <div className="space-y-2 bg-zinc-50 border border-zinc-200 rounded-xl p-2.5">
        <label className="text-[10px] text-emerald-800 font-bold uppercase block">
          Saat Menang (On Win)
        </label>

        <div className="grid grid-cols-2 gap-1">
          <button
            type="button"
            onClick={() => onChangeOnWinAction('reset')}
            disabled={disabled}
            className={`py-1.5 px-1.5 rounded-lg font-bold text-[11px] transition border cursor-pointer ${
              onWinAction === 'reset'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
            } disabled:opacity-50`}
          >
            Reset Taruhan
          </button>
          <button
            type="button"
            onClick={() => onChangeOnWinAction('increase')}
            disabled={disabled}
            className={`py-1.5 px-1.5 rounded-lg font-bold text-[11px] transition border cursor-pointer ${
              onWinAction === 'increase'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
            } disabled:opacity-50`}
          >
            Naikkan Sebesar
          </button>
        </div>

        <div className="grid grid-cols-2 gap-1.5 pt-0.5">
          {/* Box N kali */}
          <div className="flex flex-col gap-0.5">
            <span className="text-[9px] text-zinc-500 font-bold">Setiap Menang:</span>
            <div className="flex items-center bg-white border border-zinc-200 rounded-lg px-2 py-1 focus-within:border-emerald-500">
              <input
                type="number"
                min="1"
                step="1"
                value={onWinEveryCount}
                onChange={(e) => onChangeOnWinEveryCount?.(e.target.value)}
                disabled={disabled}
                placeholder="1"
                className="w-full bg-transparent font-bold text-xs text-zinc-900 outline-none"
              />
              <span className="text-zinc-400 font-bold text-[10px] select-none">kali</span>
            </div>
          </div>

          {/* Box % Naikkan */}
          {onWinAction === 'increase' ? (
            <div className="flex flex-col gap-0.5">
              <span className="text-[9px] text-zinc-500 font-bold">Naikkan Sebesar:</span>
              <div className="flex items-center bg-white border border-zinc-200 rounded-lg px-2 py-1 focus-within:border-emerald-500">
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={onWinPercent}
                  onChange={(e) => onChangeOnWinPercent(e.target.value)}
                  disabled={disabled}
                  placeholder="0"
                  className="w-full bg-transparent font-bold text-xs text-emerald-600 outline-none"
                />
                <span className="text-emerald-600 font-bold text-xs select-none">%</span>
              </div>
            </div>
          ) : (
            <div className="flex flex-col justify-end text-[9px] text-zinc-400 font-medium pb-1">
              (Kembali ke taruhan awal)
            </div>
          )}
        </div>
      </div>

      {/* ON LOSS ACTION */}
      <div className="space-y-2 bg-zinc-50 border border-zinc-200 rounded-xl p-2.5">
        <label className="text-[10px] text-rose-800 font-bold uppercase block">
          Saat Kalah (On Loss)
        </label>

        <div className="grid grid-cols-2 gap-1">
          <button
            type="button"
            onClick={() => onChangeOnLossAction('reset')}
            disabled={disabled}
            className={`py-1.5 px-1.5 rounded-lg font-bold text-[11px] transition border cursor-pointer ${
              onLossAction === 'reset'
                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
            } disabled:opacity-50`}
          >
            Reset Taruhan
          </button>
          <button
            type="button"
            onClick={() => onChangeOnLossAction('increase')}
            disabled={disabled}
            className={`py-1.5 px-1.5 rounded-lg font-bold text-[11px] transition border cursor-pointer ${
              onLossAction === 'increase'
                ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-100'
            } disabled:opacity-50`}
          >
            Naikkan Sebesar
          </button>
        </div>

        <div className="grid grid-cols-2 gap-1.5 pt-0.5">
          {/* Box N kali */}
          <div className="flex flex-col gap-0.5">
            <span className="text-[9px] text-zinc-500 font-bold">Setiap Kalah:</span>
            <div className="flex items-center bg-white border border-zinc-200 rounded-lg px-2 py-1 focus-within:border-rose-500">
              <input
                type="number"
                min="1"
                step="1"
                value={onLossEveryCount}
                onChange={(e) => onChangeOnLossEveryCount?.(e.target.value)}
                disabled={disabled}
                placeholder="1"
                className="w-full bg-transparent font-bold text-xs text-zinc-900 outline-none"
              />
              <span className="text-zinc-400 font-bold text-[10px] select-none">kali</span>
            </div>
          </div>

          {/* Box % Naikkan */}
          {onLossAction === 'increase' ? (
            <div className="flex flex-col gap-0.5">
              <span className="text-[9px] text-zinc-500 font-bold">Naikkan Sebesar:</span>
              <div className="flex items-center bg-white border border-zinc-200 rounded-lg px-2 py-1 focus-within:border-rose-500">
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={onLossPercent}
                  onChange={(e) => onChangeOnLossPercent(e.target.value)}
                  disabled={disabled}
                  placeholder="0"
                  className="w-full bg-transparent font-bold text-xs text-rose-600 outline-none"
                />
                <span className="text-rose-600 font-bold text-xs select-none">%</span>
              </div>
            </div>
          ) : (
            <div className="flex flex-col justify-end text-[9px] text-zinc-400 font-medium pb-1">
              (Kembali ke taruhan awal)
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
