import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Gem,
  Play,
  KeyRound,
  Sparkles,
  Check,
  Copy,
  Zap,
  Square,
  Shield,
  Layers,
} from 'lucide-react';
import {
  BetResult,
  BatchProgress,
  AutobetConfig,
  SavedStrategy,
  StrategySwitchRule,
  DiamondsSavedStrategy,
} from '../types/stake';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import {
  DIAMOND_COLOR_MAP,
  DIAMONDS_PAYTABLE,
  DiamondColor,
} from '../services/stakeApi';
import { GameFooterToolbar } from './GameFooterToolbar';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface DiamondsGameProps {
  balance: number;
  currency: string;
  isRolling: boolean;
  onBet: (amount: number) => Promise<boolean>;
  houseEdgePercent: number;
  autobetRunning: boolean;
  onToggleAutobet: (config: AutobetConfig) => void;
  onStopAutobet: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  lastBet: BetResult | null;
  batchProgress?: BatchProgress | null;
  currentStreak?: { type: 'win' | 'loss' | 'none'; count: number };
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin: boolean;
  stopOnLoss: boolean;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

// Crisp SVG Gem Icon
export const DiamondIcon: React.FC<{ color: DiamondColor; className?: string }> = ({ color, className = 'w-9 h-9' }) => {
  const meta = DIAMOND_COLOR_MAP[color] || DIAMOND_COLOR_MAP.green;
  return (
    <svg viewBox="0 0 48 48" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Top crown facet */}
      <polygon points="14,8 34,8 44,20 4,20" fill={meta.hex} fillOpacity="0.85" stroke="#ffffff" strokeWidth="1.5" strokeLinejoin="round" />
      {/* Center table facet */}
      <polygon points="14,8 34,8 28,20 20,20" fill="#ffffff" fillOpacity="0.4" />
      {/* Lower pavilion facets */}
      <polygon points="4,20 20,20 24,42" fill={meta.hex} fillOpacity="0.9" stroke="#ffffff" strokeWidth="1.5" strokeLinejoin="round" />
      <polygon points="20,20 28,20 24,42" fill={meta.hex} fillOpacity="1" stroke="#ffffff" strokeWidth="1.5" strokeLinejoin="round" />
      <polygon points="28,20 44,20 24,42" fill={meta.hex} fillOpacity="0.75" stroke="#ffffff" strokeWidth="1.5" strokeLinejoin="round" />
      {/* Highlight reflection */}
      <line x1="16" y1="11" x2="22" y2="18" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" strokeOpacity="0.7" />
    </svg>
  );
};

export const DiamondsGame: React.FC<DiamondsGameProps> = ({
  balance,
  currency,
  isRolling,
  onBet,
  houseEdgePercent,
  autobetRunning,
  onToggleAutobet,
  onStopAutobet,
  onShowToast,
  lastBet,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin,
  stopOnLoss,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: switchRulesEnabledProp,
}) => {
  // Mode: Manual or Auto (Otomatis)
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies State
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() =>
    loadSavedStrategies('diamonds')
  );

  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('diamonds');
    const activeId = getActiveStrategyId('diamonds');
    if (activeId) {
      const found = list.find((s) => s.id === activeId);
      if (found) return found;
    }
    return list.length > 0 ? list[0] : null;
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const handleImportStrategies = (imported: SavedStrategy[]) => {
    setStrategies((prev) => {
      const existingIds = new Set(prev.map((s) => s.id));
      const newItems = imported.filter((s) => !existingIds.has(s.id));
      const updated = [...newItems, ...prev];
      saveSavedStrategies('diamonds', updated);
      if (imported[0]) {
        handleSelectStrategy(imported[0]);
      }
      return updated;
    });
  };

  // Bet amount
  const [betAmount, setBetAmount] = useState<string>(() => {
    const saved = localStorage.getItem('diamonds_bet_amount');
    return activeStrategy?.betAmount || saved || '0';
  });

  // Auto Bet Parameters
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('diamonds_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('diamonds_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('diamonds_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('diamonds_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('diamonds_on_loss_percent') || '0');
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('diamonds_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('diamonds_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('diamonds_max_bet_cap') || '0');
  const [localStopLoseStreak, setLocalStopLoseStreak] = useState<string>(() => activeStrategy?.stopLoseStreak || (stopLoseStreak > 0 ? String(stopLoseStreak) : localStorage.getItem('diamonds_stop_lose_streak') || '0'));
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('diamonds_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => localStorage.getItem('diamonds_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => localStorage.getItem('diamonds_stop_balance_min') || '0');
  const [batchDelayMs, setBatchDelayMs] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('stake_batch_delay_ms'));
      return saved ? Math.max(100, saved) : 100;
    } catch {
      return 100;
    }
  });

  // Dynamic Strategy Switch Rules
  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('diamonds'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('diamonds'));

  const handleUpdateSwitchRules = (newRules: StrategySwitchRule[]) => {
    setSwitchRules(newRules);
    saveSwitchRules('diamonds', newRules);
  };

  const handleToggleSwitchRulesEnabled = (val: boolean) => {
    setSwitchRulesEnabledState(val);
    setSwitchRulesEnabled('diamonds', val);
  };

  // Strategy switching handler
  const handleSelectStrategy = (strat: SavedStrategy) => {
    activeStrategyRef.current = strat;
    setActiveStrategy(strat);
    setActiveStrategyId('diamonds', strat.id);

    setBetAmount(strat.betAmount !== undefined ? strat.betAmount : '0');
    setNumberOfBets(strat.numberOfBets !== undefined ? strat.numberOfBets : '0');
    setOnWinAction(strat.onWinAction || 'reset');
    setOnWinPercent(strat.onWinPercent !== undefined ? strat.onWinPercent : '0');
    setOnLossAction(strat.onLossAction || 'reset');
    setOnLossPercent(strat.onLossPercent !== undefined ? strat.onLossPercent : '0');
    setStopProfit(strat.stopProfit !== undefined ? strat.stopProfit : '0');
    stopProfitRef.current = parseFloat(strat.stopProfit || '0') || 0;
    setStopLoss(strat.stopLoss !== undefined ? strat.stopLoss : '0');
    stopLossRef.current = parseFloat(strat.stopLoss || '0') || 0;
    setMaxBetCap(strat.maxBetCap !== undefined ? strat.maxBetCap : '0');
    maxBetCapRef.current = parseFloat(strat.maxBetCap || '0') || 0;
    setLocalStopLoseStreak(strat.stopLoseStreak !== undefined ? strat.stopLoseStreak : '0');
    stopLoseStreakRef.current = parseInt(strat.stopLoseStreak || '0', 10) || 0;
    setTrailingStop(strat.trailingStop !== undefined ? strat.trailingStop : '0');
    trailingStopRef.current = parseFloat(strat.trailingStop || '0') || 0;
    setStopWager(strat.stopWager !== undefined ? strat.stopWager : '0');
    stopWagerRef.current = parseFloat(strat.stopWager || '0') || 0;
    setStopBalanceMin(strat.stopBalanceMin !== undefined ? strat.stopBalanceMin : '0');
    stopBalanceMinRef.current = parseFloat(strat.stopBalanceMin || '0') || 0;

    // Apply stop limits and triggers unconditionally so Strategy 2 resets Strategy 1's values
    onUpdateTriggers?.({
      stopOnWin: !!strat.stopOnWin,
      stopOnLoss: !!strat.stopOnLoss,
      stopLoseStreak: parseInt(strat.stopLoseStreak || '0', 10) || 0,
      stopWinStreak: parseInt(strat.stopWinStreak || '0', 10) || 0,
    });

    onShowToast?.('Strategi Dipilih', 'ON', `Mengaktifkan strategi "${strat.name}"`);
  };

  const handleSaveStrategy = (strat: SavedStrategy) => {
    setStrategies((prev) => {
      const idx = prev.findIndex((s) => s.id === strat.id);
      let updated: SavedStrategy[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = strat;
      } else {
        updated = [strat, ...prev];
      }
      saveSavedStrategies('diamonds', updated);
      return updated;
    });
    handleSelectStrategy(strat);
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveSavedStrategies('diamonds', updated);
      if (activeStrategy?.id === id) {
        const next = updated.length > 0 ? updated[0] : null;
        setActiveStrategy(next);
        if (next) {
          setActiveStrategyId('diamonds', next.id);
        } else {
          localStorage.removeItem('stake_active_strategy_diamonds');
        }
      }
      return updated;
    });
  };

  // Refs for real-time live evaluation
  const stopProfitRef = useRef<number>(parseFloat(stopProfit) || 0);
  const stopLossRef = useRef<number>(parseFloat(stopLoss) || 0);
  const maxBetCapRef = useRef<number>(parseFloat(maxBetCap) || 0);
  const trailingStopRef = useRef<number>(parseFloat(trailingStop) || 0);
  const stopWagerRef = useRef<number>(parseFloat(stopWager) || 0);
  const stopBalanceMinRef = useRef<number>(parseFloat(stopBalanceMin) || 0);
  const stopOnWinRef = useRef<boolean>(stopOnWin);
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);
  const stopWinStreakRef = useRef<number>(stopWinStreak);

  useEffect(() => {
    stopOnWinRef.current = stopOnWin;
  }, [stopOnWin]);

  useEffect(() => {
    stopOnLossRef.current = stopOnLoss;
  }, [stopOnLoss]);

  useEffect(() => {
    stopLoseStreakRef.current = stopLoseStreak;
  }, [stopLoseStreak]);

  useEffect(() => {
    stopWinStreakRef.current = stopWinStreak;
  }, [stopWinStreak]);

  const handleStopProfitChange = (val: string) => {
    setStopProfit(val);
    stopProfitRef.current = parseFloat(val) || 0;
  };

  const handleStopLossChange = (val: string) => {
    setStopLoss(val);
    stopLossRef.current = parseFloat(val) || 0;
  };

  const handleMaxBetCapChange = (val: string) => {
    setMaxBetCap(val);
    maxBetCapRef.current = parseFloat(val) || 0;
  };

  const handleLocalStopLoseStreakChange = (val: string) => {
    setLocalStopLoseStreak(val);
    stopLoseStreakRef.current = parseInt(val, 10) || 0;
  };

  const handleTrailingStopChange = (val: string) => {
    setTrailingStop(val);
    trailingStopRef.current = parseFloat(val) || 0;
  };

  const handleStopWagerChange = (val: string) => {
    setStopWager(val);
    stopWagerRef.current = parseFloat(val) || 0;
  };

  const handleStopBalanceMinChange = (val: string) => {
    setStopBalanceMin(val);
    stopBalanceMinRef.current = parseFloat(val) || 0;
  };

  // Save settings effect
  useEffect(() => {
    localStorage.setItem('diamonds_bet_amount', betAmount);
    localStorage.setItem('diamonds_num_bets', numberOfBets);
    localStorage.setItem('diamonds_on_win_action', onWinAction);
    localStorage.setItem('diamonds_on_win_percent', onWinPercent);
    localStorage.setItem('diamonds_on_loss_action', onLossAction);
    localStorage.setItem('diamonds_on_loss_percent', onLossPercent);
    localStorage.setItem('diamonds_stop_profit', stopProfit);
    localStorage.setItem('diamonds_stop_loss', stopLoss);
    localStorage.setItem('diamonds_max_bet_cap', maxBetCap);
    localStorage.setItem('diamonds_stop_lose_streak', localStopLoseStreak);
    localStorage.setItem('diamonds_trailing_stop', trailingStop);
    localStorage.setItem('diamonds_stop_wager', stopWager);
    localStorage.setItem('diamonds_stop_balance_min', stopBalanceMin);
  }, [
    betAmount,
    numberOfBets,
    onWinAction,
    onWinPercent,
    onLossAction,
    onLossPercent,
    stopProfit,
    stopLoss,
    maxBetCap,
    localStopLoseStreak,
    trailingStop,
    stopWager,
    stopBalanceMin,
  ]);

  const [nonce, setNonce] = useState<number>(() => parseInt(localStorage.getItem('stake_seed_nonce') || '1') || 1);
  const [copiedBetId, setCopiedBetId] = useState<boolean>(false);

  // Numeric input calculation supporting 0-bet
  const numericInput = useMemo(() => {
    if (betAmount === '') return 0;
    const parsed = parseFloat(betAmount.replace(',', '.'));
    return isNaN(parsed) || parsed < 0 ? 0 : parsed;
  }, [betAmount]);

  // Fallback initial 5 gems when app starts
  const displayDiamonds: DiamondColor[] = useMemo(() => {
    if (lastBet && lastBet.game === 'diamonds' && Array.isArray(lastBet.diamonds) && lastBet.diamonds.length === 5) {
      return lastBet.diamonds as DiamondColor[];
    }
    return ['green', 'purple', 'yellow', 'red', 'cyan'];
  }, [lastBet]);

  // Frequency count to highlight matching gems
  const gemCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    displayDiamonds.forEach((c) => {
      counts[c] = (counts[c] || 0) + 1;
    });
    return counts;
  }, [displayDiamonds]);

  // Handle manual bet placement
  const handlePlaceBet = async () => {
    if (isRolling || autobetRunning) return;
    if (numericInput < 0) {
      onShowToast?.('Taruhan Tidak Valid', 'OFF', 'Nominal taruhan tidak boleh negatif.');
      return;
    }
    if (numericInput > balance && balance > 0) {
      onShowToast?.('Saldo Tidak Cukup', 'OFF', `Saldo Anda tidak mencukupi (${balance.toFixed(8)} ${currency.toUpperCase()}).`);
      return;
    }

    try {
      await onBet(numericInput);
      setNonce((prev) => {
        const next = prev + 1;
        localStorage.setItem('stake_seed_nonce', String(next));
        return next;
      });
    } catch {
      // Handled by parent
    }
  };

  // Autobet Start
  const handleStartAutobet = () => {
    if (autobetRunning) {
      onStopAutobet();
      return;
    }

    const currentStrat = activeStrategy || strategies.find(s => s.id === getActiveStrategyId('diamonds')) || strategies[0];

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : numericInput;
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(String(currentStrat.onWinEveryCount), 10) || 1
      : 1;
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(String(currentStrat.onLossEveryCount), 10) || 1
      : 1;
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const config: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopOnWin,
      stopOnLoss,
      stopLoseStreak,
      stopWinStreak,
      batchDelayMs,
      switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onBetAmountChange: (newAmt: number) => {
        setBetAmount(newAmt === 0 ? '0' : newAmt.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
      },
      onSwitchStrategy: (targetStrategy, rule) => {
        const found = strategies.find((s) => s.id === targetStrategy.id);
        if (found) {
          activeStrategyRef.current = found;
          setActiveStrategy(found);
          setActiveStrategyId('diamonds', found.id);
          setBetAmount(found.betAmount !== undefined ? found.betAmount : '0');
          setOnWinAction(found.onWinAction || 'reset');
          setOnWinPercent(found.onWinPercent !== undefined ? found.onWinPercent : '0');
          setOnLossAction(found.onLossAction || 'reset');
          setOnLossPercent(found.onLossPercent !== undefined ? found.onLossPercent : '0');
        }
      },
      getLiveTriggers: () => ({
        stopOnWin: stopOnWinRef.current,
        stopOnLoss: stopOnLossRef.current,
        stopLoseStreak: stopLoseStreakRef.current,
        stopWinStreak: stopWinStreakRef.current,
        stopProfit: stopProfitRef.current,
        stopLoss: stopLossRef.current,
        stopWager: stopWagerRef.current,
        stopBalanceMin: stopBalanceMinRef.current,
        maxBetCap: maxBetCapRef.current,
        maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || 0,
        trailingStop: trailingStopRef.current,
        switchRules,
        switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(config);
  };

  // Keyboard shortcut: Spacebar to bet in manual mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (tabMode !== 'manual') return;
      if (e.code === 'Space') {
        const target = e.target as HTMLElement;
        const isInputField =
          target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable;

        if (!isInputField && !isRolling && !autobetRunning) {
          e.preventDefault();
          if (numericInput >= 0) {
            handlePlaceBet();
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [tabMode, isRolling, autobetRunning, numericInput]);

  // Quick Amount Handlers
  const handleHalf = () => {
    const half = Math.max(0, numericInput / 2);
    setBetAmount(half === 0 ? '0' : half.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
  };

  const handleDouble = () => {
    const dbl = numericInput === 0 ? (currency.toLowerCase() === 'idr' ? 1000 : 0.00001) : numericInput * 2;
    setBetAmount(dbl.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
  };

  const handleMin = () => {
    setBetAmount('0');
  };

  const handleMax = () => {
    setBetAmount(balance.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
  };

  const copyBetId = () => {
    if (!lastBet?.betId) return;
    navigator.clipboard.writeText(lastBet.betId);
    setCopiedBetId(true);
    setTimeout(() => setCopiedBetId(false), 1500);
  };

  return (
    <div className="flex flex-col gap-3 font-sans">
      {/* Top Game Bar */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-600 text-white flex items-center justify-center shadow-xs">
            <Gem className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900 tracking-tight">
                DIAMONDS
              </h2>
              <span className="text-[9px] bg-cyan-100 text-cyan-800 border border-cyan-200 font-mono font-bold px-1.5 py-0.2 rounded">
                STAKE ORIGINAL
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-zinc-500 font-mono">
              Undian 5 permata instan • Max Win 50.00× • House Edge {houseEdgePercent}%
            </p>
          </div>
        </div>
      </div>

      {/* Mode Switcher Tabs (Manual vs Otomatis) */}
      <div className="grid grid-cols-2 bg-zinc-100 p-1 rounded-2xl border border-zinc-200 font-mono text-xs font-bold">
        <button
          type="button"
          onClick={() => setTabMode('manual')}
          disabled={autobetRunning}
          className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50 ${
            tabMode === 'manual'
              ? 'bg-white text-zinc-950 shadow-2xs'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Play className="w-3.5 h-3.5 text-cyan-600" />
          <span>Manual</span>
        </button>

        <button
          type="button"
          onClick={() => setTabMode('auto')}
          className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer relative ${
            tabMode === 'auto'
              ? 'bg-white text-zinc-950 shadow-2xs'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Otomatis</span>
          {autobetRunning && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
        </button>
      </div>

      {/* AUTO BET RUNNING STATUS BANNER */}
      {autobetRunning && batchProgress && (
        <div className="bg-emerald-600 text-white rounded-xl p-3 flex items-center justify-between text-xs shadow-md">
          <div className="space-y-0.5">
            <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>Auto Bet Diamonds: Putaran {batchProgress.currentRound} / {batchProgress.totalRounds || '∞'}</span>
              {batchProgress.activeStrategyName && (
                <span className="bg-emerald-700/80 px-1.5 py-0.5 rounded text-[10px] font-black border border-emerald-400/40">
                  {batchProgress.activeStrategyName}
                </span>
              )}
            </span>
            <span className="text-[10px] text-emerald-100 flex items-center gap-2 flex-wrap">
              <span>Profit: <strong>{batchProgress.runningProfit >= 0 ? `+${batchProgress.runningProfit}` : batchProgress.runningProfit} {currency.toUpperCase()}</strong></span>
              {batchProgress.peakProfit !== undefined && batchProgress.peakProfit > 0 && (
                <span>• Puncak: <strong className="text-white">+{batchProgress.peakProfit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 6)}</strong></span>
              )}
              {batchProgress.totalWagered !== undefined && (
                <span>• Wager: <strong>{batchProgress.totalWagered} {currency.toUpperCase()}</strong></span>
              )}
            </span>
          </div>
          <button
            type="button"
            onClick={onStopAutobet}
            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer transition flex items-center gap-1 shrink-0"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Berhenti</span>
          </button>
        </div>
      )}

      {/* 5 DIAMOND SLOTS (PEDESTALS DISPLAY) - MANUAL MODE ONLY */}
      {tabMode === 'manual' && (
        <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
              HASIL PERMATA (5 SLOT)
            </span>
            <span className="text-[10px] font-mono text-zinc-400">
              {isRolling ? 'Mengundi di Stake...' : 'Hasil Resmi Provably Fair'}
            </span>
          </div>

          {/* 5 Gems Display Row */}
          <div className="grid grid-cols-5 gap-1.5 sm:gap-3 py-2">
            {displayDiamonds.map((color, idx) => {
              const meta = DIAMOND_COLOR_MAP[color] || DIAMOND_COLOR_MAP.green;
              const count = gemCounts[color] || 0;
              const isMatch = count >= 2;

              return (
                <div
                  key={idx}
                  className={`relative flex flex-col items-center justify-center p-2 sm:p-3.5 rounded-2xl border transition-all ${
                    isMatch
                      ? 'bg-zinc-900 border-zinc-700 shadow-md ring-2 ring-cyan-500/60 scale-[1.02]'
                      : 'bg-zinc-50 border-zinc-200 hover:border-zinc-300'
                  }`}
                >
                  <div className="relative">
                    <DiamondIcon color={color} className="w-10 h-10 sm:w-13 sm:h-13" />
                    {isMatch && (
                      <div
                        className="absolute inset-0 rounded-full blur-md opacity-40 pointer-events-none"
                        style={{ backgroundColor: meta.hex }}
                      />
                    )}
                  </div>

                  <span
                    className={`mt-1.5 text-[9px] sm:text-[10px] font-mono font-bold uppercase truncate max-w-full ${
                      isMatch ? 'text-white' : 'text-zinc-600'
                    }`}
                  >
                    {meta.name}
                  </span>

                  {isMatch && (
                    <span
                      className="absolute -top-1.5 -right-1 px-1.5 py-0.2 rounded-full text-[8px] sm:text-[9px] font-black text-white shadow-2xs font-mono"
                      style={{ backgroundColor: meta.hex }}
                    >
                      {count}×
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Combination Payout Banner */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2 flex-wrap text-xs">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">Kombinasi:</span>
              <span className="font-mono font-black text-cyan-950 text-xs sm:text-sm bg-cyan-100/80 px-2 py-0.5 rounded border border-cyan-200">
                {lastBet && lastBet.game === 'diamonds' && lastBet.combinationName
                  ? lastBet.combinationName
                  : 'Belum Ada Taruhan'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">Pengali:</span>
              <span className={`font-mono font-black text-xs sm:text-sm px-2 py-0.5 rounded border ${
                lastBet && lastBet.multiplier > 0
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                  : 'bg-zinc-100 text-zinc-500 border-zinc-200'
              }`}>
                {lastBet && lastBet.game === 'diamonds' ? `${lastBet.multiplier.toFixed(2)}×` : '0.00×'}
              </span>
            </div>

            {lastBet?.id && (
              <div className="flex items-center gap-1.5 text-[10px] text-zinc-400">
                <span>Bet ID:</span>
                <button
                  type="button"
                  onClick={copyBetId}
                  className="flex items-center gap-1 bg-white/80 hover:bg-white border border-zinc-200 px-1.5 py-0.5 rounded font-mono text-zinc-700 cursor-pointer transition"
                  title="Salin ID Taruhan Stake"
                >
                  {copiedBetId ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-zinc-400" />}
                  <span className="truncate max-w-[90px]">{lastBet.id}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MANUAL BET CONTROLS */}
      {tabMode === 'manual' && (
        <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono font-bold text-zinc-600 uppercase">
              Jumlah Taruhan ({currency.toUpperCase()})
            </label>
            <span className="text-[10px] font-mono text-zinc-400">
              Tersedia: {balance.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8)}
            </span>
          </div>

          {/* Input & Quick Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                placeholder="0 (Bisa bet 0 untuk testing)"
                className="w-full bg-zinc-50 border border-zinc-300 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl px-3 py-2.5 font-mono text-sm font-bold text-zinc-900 outline-hidden transition"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono font-bold text-zinc-400 uppercase pointer-events-none">
                {currency}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleHalf}
                className="px-2.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs font-bold transition cursor-pointer"
              >
                ½
              </button>
              <button
                type="button"
                onClick={handleDouble}
                className="px-2.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs font-bold transition cursor-pointer"
              >
                2×
              </button>
              <button
                type="button"
                onClick={handleMin}
                className="px-2.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs font-bold transition cursor-pointer"
              >
                Min (0)
              </button>
              <button
                type="button"
                onClick={handleMax}
                className="px-2.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs font-bold transition cursor-pointer"
              >
                Max
              </button>
            </div>
          </div>

          {/* Main Action Button */}
          <button
            type="button"
            onClick={handlePlaceBet}
            disabled={isRolling}
            className="w-full py-3.5 sm:py-4 rounded-xl bg-cyan-600 hover:bg-cyan-700 active:scale-[0.99] text-white font-mono font-bold text-sm sm:text-base shadow-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className={`w-4 h-4 fill-current ${isRolling ? 'animate-spin' : ''}`} />
            <span>
              {isRolling
                ? 'MENGUNDI DI STAKE...'
                : `ROLL DIAMONDS (${numericInput > 0 ? `${numericInput} ${currency.toUpperCase()}` : 'BET 0'})`}
            </span>
          </button>
          <p className="text-center text-[10px] font-mono text-zinc-400">
            Tip: Tekan <kbd className="px-1.5 py-0.5 rounded bg-zinc-100 border border-zinc-200 font-bold text-zinc-700">Space</kbd> untuk taruhan cepat tanpa klik mouse
          </p>
        </div>
      )}

      {/* OTOMATIS MODE CONTROLS */}
      {tabMode === 'auto' && (
        <div className="space-y-3">
          <AutoBetStrategyManager
            game="diamonds"
            currency={currency}
            strategies={strategies}
            activeStrategy={activeStrategy}
            onSelectStrategy={handleSelectStrategy}
            onSaveStrategy={handleSaveStrategy}
            onDeleteStrategy={handleDeleteStrategy}
            onImportStrategies={handleImportStrategies}
            autobetRunning={autobetRunning}
            onShowToast={onShowToast}
            stopProfit={stopProfit}
            onChangeStopProfit={handleStopProfitChange}
            stopLoss={stopLoss}
            onChangeStopLoss={handleStopLossChange}
            maxBetCap={maxBetCap}
            onChangeMaxBetCap={handleMaxBetCapChange}
            maxConsecutiveLosses={localStopLoseStreak}
            onChangeMaxConsecutiveLosses={handleLocalStopLoseStreakChange}
            trailingStop={trailingStop}
            onChangeTrailingStop={handleTrailingStopChange}
            stopWager={stopWager}
            onChangeStopWager={handleStopWagerChange}
            stopBalanceMin={stopBalanceMin}
            onChangeStopBalanceMin={handleStopBalanceMinChange}
            stopOnWin={stopOnWin}
            onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
            stopOnLoss={stopOnLoss}
            onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
            stopWinStreak={String(stopWinStreak)}
            onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
            switchRules={switchRules}
            onChangeSwitchRules={handleUpdateSwitchRules}
            switchRulesEnabled={switchRulesEnabled}
            onToggleSwitchRulesEnabled={handleToggleSwitchRulesEnabled}
            renderStrategyForm={(temp, setTemp) => {
              const strat = temp as DiamondsSavedStrategy;
              return (
                <div className="space-y-3">
                  {/* 1. Base Bet Amount */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                      Jumlah Taruhan Dasar (Base Amount)
                    </label>
                    <input
                      type="text"
                      value={strat.betAmount}
                      onChange={(e) => setTemp({ ...strat, betAmount: e.target.value })}
                      placeholder="0.00000000"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* 2. Number of bets */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Jumlah Putaran (0 = Tanpa Batas)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={strat.numberOfBets}
                      onChange={(e) => setTemp({ ...strat, numberOfBets: e.target.value })}
                      placeholder="0"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* 3. Strategy Controls */}
                  <AutoBetStrategyControls
                    onWinAction={strat.onWinAction}
                    onChangeOnWinAction={(val) => setTemp({ ...strat, onWinAction: val })}
                    onWinPercent={strat.onWinPercent}
                    onChangeOnWinPercent={(val) => setTemp({ ...strat, onWinPercent: val })}
                    onWinEveryCount={strat.onWinEveryCount}
                    onChangeOnWinEveryCount={(val) => setTemp({ ...strat, onWinEveryCount: val })}
                    onLossAction={strat.onLossAction}
                    onChangeOnLossAction={(val) => setTemp({ ...strat, onLossAction: val })}
                    onLossPercent={strat.onLossPercent}
                    onChangeOnLossPercent={(val: string) => setTemp({ ...strat, onLossPercent: val })}
                    onLossEveryCount={strat.onLossEveryCount}
                    onChangeOnLossEveryCount={(val) => setTemp({ ...strat, onLossEveryCount: val })}
                    currency={currency}
                    disabled={false}
                  />
                </div>
              );
            }}
          />

          {/* Action Trigger Buttons for Autobet */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs space-y-3 font-mono">
            <button
              type="button"
              onClick={handleStartAutobet}
              disabled={isRolling ? !autobetRunning : (!activeStrategy || strategies.length === 0)}
              className={`w-full py-3 sm:py-3.5 rounded-xl font-bold text-sm shadow-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                autobetRunning
                  ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                  : (isRolling && !autobetRunning)
                  ? 'bg-zinc-400 text-white'
                  : 'bg-cyan-600 hover:bg-cyan-700 text-white'
              }`}
            >
              {autobetRunning ? (
                <>
                  <Square className="w-4 h-4 fill-current" />
                  <span>HENTIKAN AUTO BET DIAMONDS</span>
                </>
              ) : (isRolling && !autobetRunning) ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>MENGHENTIKAN...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-amber-300" />
                  <span>
                    {!activeStrategy || strategies.length === 0 
                      ? 'TAMBAH STRATEGI DAHULU' 
                      : `MULAI AUTO BET DIAMONDS (${numericInput > 0 ? `${numericInput} ${currency.toUpperCase()}` : 'BET 0'})`
                    }
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      )}



      {/* User Request: Move Last Result display above the paytable for Auto Mode */}
      {tabMode === 'auto' && (lastBet && lastBet.game === 'diamonds') && (
        <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs font-mono space-y-2.5 animate-in fade-in slide-in-from-top-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-cyan-700 uppercase flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> HASIL PERMATA TERAKHIR:
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-black text-cyan-950 bg-cyan-50 border border-cyan-200 px-2 py-0.5 rounded">
                {lastBet.combinationName}
              </span>
              <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                {lastBet.multiplier.toFixed(2)}×
              </span>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 py-1">
            {(lastBet.diamonds as DiamondColor[] || []).map((color, idx) => (
              <div key={idx} className="bg-zinc-50 border border-zinc-200 rounded-xl p-1.5 shadow-2xs">
                <DiamondIcon color={color} className="w-7 h-7 sm:w-10 sm:h-10" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PAYTABLE & COMBINATIONS REFERENCE */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex flex-col gap-2.5 font-mono">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
            <Gem className="w-3.5 h-3.5 text-cyan-600" />
            TABEL KOMBINASI &amp; PENGALI DIAMONDS
          </h3>
          <span className="text-[10px] text-zinc-400">7 Warna Permata</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-200 text-[10px] text-zinc-400 uppercase">
                <th className="py-1.5 px-2">Kombinasi</th>
                <th className="py-1.5 px-2 text-right">Pengali</th>
                <th className="py-1.5 px-2 text-right">Peluang</th>
                <th className="py-1.5 px-2 text-zinc-500 hidden sm:table-cell">Keterangan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {DIAMONDS_PAYTABLE.map((item) => {
                const isActive = lastBet && lastBet.game === 'diamonds' && lastBet.multiplier === item.multiplier;

                return (
                  <tr
                    key={item.id}
                    className={`transition ${
                      isActive
                        ? 'bg-cyan-50 font-bold text-cyan-900 ring-1 ring-cyan-400 rounded-md'
                        : 'hover:bg-zinc-50/50 text-zinc-700'
                    }`}
                  >
                    <td className="py-1.5 px-2 flex items-center gap-1.5">
                      {isActive && <Sparkles className="w-3 h-3 text-cyan-600 shrink-0" />}
                      <span>{item.name}</span>
                    </td>
                    <td className="py-1.5 px-2 text-right font-bold text-cyan-700 tabular-nums">
                      {item.multiplier.toFixed(2)}×
                    </td>
                    <td className="py-1.5 px-2 text-right text-zinc-500 text-[11px] tabular-nums">
                      {item.probability}
                    </td>
                    <td className="py-1.5 px-2 text-zinc-400 text-[10px] hidden sm:table-cell">
                      {item.description}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer Toolbar: Settings & Stats Toggle */}
      <GameFooterToolbar
        batchDelayMs={batchDelayMs}
        onBatchDelayChange={(ms) => {
          setBatchDelayMs(ms);
          localStorage.setItem('stake_batch_delay_ms', String(ms));
        }}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="cyan"
      />
    </div>
  );
};
