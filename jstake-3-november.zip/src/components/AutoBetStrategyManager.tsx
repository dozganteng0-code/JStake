import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Download,
  Upload,
  Layers,
  ChevronDown,
  ChevronUp,
  Info,
} from 'lucide-react';
import { GameType, SavedStrategy, StrategySwitchRule } from '../types/stake';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import {
  exportStrategiesToJson,
  downloadStrategiesJson,
  importStrategiesFromJson,
} from '../utils/strategyStorage';

interface AutoBetStrategyManagerProps {
  game: GameType;
  currency: string;
  strategies: SavedStrategy[];
  activeStrategy: SavedStrategy | null;
  onSelectStrategy: (strat: SavedStrategy) => void;
  onSaveStrategy: (strat: SavedStrategy) => void;
  onDeleteStrategy: (id: string) => void;
  onImportStrategies: (strats: SavedStrategy[]) => void;
  autobetRunning: boolean;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  stopProfit: string;
  onChangeStopProfit: (val: string) => void;
  stopLoss: string;
  onChangeStopLoss: (val: string) => void;
  maxBetCap: string;
  onChangeMaxBetCap: (val: string) => void;
  maxConsecutiveLosses: string;
  onChangeMaxConsecutiveLosses: (val: string) => void;
  trailingStop: string;
  onChangeTrailingStop: (val: string) => void;
  stopWager: string;
  onChangeStopWager: (val: string) => void;
  stopBalanceMin: string;
  onChangeStopBalanceMin: (val: string) => void;
  stopOnWin?: boolean;
  onChangeStopOnWin?: (val: boolean) => void;
  stopOnLoss?: boolean;
  onChangeStopOnLoss?: (val: boolean) => void;
  stopWinStreak?: string;
  onChangeStopWinStreak?: (val: string) => void;
  switchRules?: StrategySwitchRule[];
  onChangeSwitchRules?: (rules: StrategySwitchRule[]) => void;
  switchRulesEnabled?: boolean;
  onToggleSwitchRulesEnabled?: (enabled: boolean) => void;
  renderStrategyForm: (
    temp: SavedStrategy,
    setTemp: React.Dispatch<React.SetStateAction<SavedStrategy>>
  ) => React.ReactNode;
}

export const AutoBetStrategyManager: React.FC<AutoBetStrategyManagerProps> = ({
  game,
  currency,
  strategies,
  activeStrategy,
  onSelectStrategy,
  onSaveStrategy,
  onDeleteStrategy,
  onImportStrategies,
  autobetRunning,
  onShowToast,
  stopProfit,
  onChangeStopProfit,
  stopLoss,
  onChangeStopLoss,
  maxBetCap,
  onChangeMaxBetCap,
  maxConsecutiveLosses,
  onChangeMaxConsecutiveLosses,
  trailingStop,
  onChangeTrailingStop,
  stopWager,
  onChangeStopWager,
  stopBalanceMin,
  onChangeStopBalanceMin,
  stopOnWin = false,
  onChangeStopOnWin,
  stopOnLoss = false,
  onChangeStopOnLoss,
  stopWinStreak = '0',
  onChangeStopWinStreak,
  switchRules,
  onChangeSwitchRules,
  switchRulesEnabled,
  onToggleSwitchRulesEnabled,
  renderStrategyForm,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editingStrategy, setEditingStrategy] = useState<SavedStrategy | null>(null);
  const [showAdvancedStops, setShowAdvancedStops] = useState(false);

  const updateActiveStrategyField = <K extends keyof SavedStrategy>(key: K, val: SavedStrategy[K]) => {
    if (activeStrategy) {
      const updated = { ...activeStrategy, [key]: val, updatedAt: Date.now() };
      onSaveStrategy(updated);
    }
  };

  const handleStartCreate = () => {
    const id = `strat_${Date.now()}`;
    const base: SavedStrategy = {
      id,
      name: '',
      game,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      betAmount: '0',
      numberOfBets: '0',
      onWinAction: 'reset',
      onWinPercent: '0',
      onWinEveryCount: '1',
      onLossAction: 'reset',
      onLossPercent: '0',
      onLossEveryCount: '1',
      stopProfit: '0',
      stopLoss: '0',
      maxBetCap: '0',
      stopLoseStreak: '0',
      stopWinStreak: '0',
      stopOnWin: false,
      stopOnLoss: false,
      trailingStop: '0',
      stopWager: '0',
      stopBalanceMin: '0',
      ...(game === 'dice' ? { condition: 'above', target: 50.5 } : {}),
      ...(game === 'limbo' ? { targetMultiplier: 2.0 } : {}),
      ...(game === 'plinko' ? { risk: 'medium', rows: 16 } : {}),
      ...(game === 'mines' ? { minesCount: 3, autoFields: [0, 1, 2] } : {}),
      ...(game === 'diamonds' ? {} : {}),
      ...(game === 'keno' ? { risk: 'classic', selectedNumbers: [1, 5, 10, 15, 20, 25, 30, 35, 38, 40] } : {}),
    } as SavedStrategy;
    setEditingStrategy(base);
    setIsEditing(true);
  };

  const handleStartEdit = (strat: SavedStrategy) => {
    setEditingStrategy({ ...strat });
    setIsEditing(true);
  };

  const handleSaveEdit = () => {
    if (editingStrategy) {
      onSaveStrategy(editingStrategy);
      setIsEditing(false);
      setEditingStrategy(null);
      onShowToast?.('Strategi Disimpan', 'ON', `"${editingStrategy.name}" berhasil disimpan.`);
    }
  };

  const handleExport = () => {
    if (strategies.length === 0) {
      onShowToast?.('Tidak Ada Strategi', 'OFF', 'Belum ada strategi tersimpan untuk diekspor.');
      return;
    }
    const json = exportStrategiesToJson(strategies);
    downloadStrategiesJson(json, `jstkbot_${game}_strategies_${Date.now()}.json`);
    onShowToast?.('Ekspor Berhasil', 'ON', `${strategies.length} strategi berhasil diunduh.`);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const res = importStrategiesFromJson(text, game);
      if (res.valid) {
        onImportStrategies(res.strategies);
        onShowToast?.('Impor Berhasil', 'ON', `${res.strategies.length} strategi berhasil diimpor.`);
      } else {
        onShowToast?.('Impor Gagal', 'OFF', res.error || 'Format tidak valid.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-3 font-mono text-xs text-zinc-900">
      {/* STRATEGY HEADER & ACTIONS */}
      <div className="flex items-center justify-between gap-2">
        <span className="font-bold uppercase text-[11px] text-zinc-700 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-emerald-600" />
          <span>Daftar Strategi ({strategies.length})</span>
        </span>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleExport}
            className="p-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 cursor-pointer shadow-2xs"
            title="Ekspor Strategi JSON"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          <label
            className="p-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 cursor-pointer shadow-2xs"
            title="Impor Strategi JSON"
          >
            <Upload className="w-3.5 h-3.5" />
            <input type="file" accept=".json" onChange={handleFileInput} className="hidden" />
          </label>
          <button
            type="button"
            onClick={handleStartCreate}
            disabled={autobetRunning}
            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah</span>
          </button>
        </div>
      </div>

      {/* STRATEGY LIST PILLS / SELECTOR */}
      {strategies.length > 0 ? (
        <div className="flex flex-wrap gap-1.5">
          {strategies.map((strat) => {
            const isActive = activeStrategy?.id === strat.id;
            return (
              <div
                key={strat.id}
                className={`flex items-center rounded-xl border text-xs transition cursor-pointer ${
                  isActive
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-xs'
                    : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectStrategy(strat)}
                  className="px-3 py-1.5 text-left flex items-center gap-1.5 cursor-pointer"
                >
                  {isActive && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                  <span>{strat.name}</span>
                </button>
                <div className="flex items-center pr-1.5 border-l border-zinc-200/60 pl-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStartEdit(strat);
                    }}
                    className="p-1 hover:text-emerald-700 cursor-pointer"
                    title="Edit Strategi"
                  >
                    <Edit2 className="w-3 h-3 text-zinc-400 hover:text-zinc-700" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteStrategy(strat.id);
                    }}
                    className="p-1 hover:text-rose-600 cursor-pointer"
                    title="Hapus Strategi"
                  >
                    <Trash2 className="w-3 h-3 text-zinc-400 hover:text-rose-600" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-zinc-50 border border-dashed border-zinc-300 rounded-xl p-3 text-center text-zinc-400 text-xs">
          Belum ada strategi tersimpan. Klik <strong>+ Tambah</strong> untuk membuat strategi baru.
        </div>
      )}

      {/* EDIT MODAL / DRAWER */}
      {isEditing && editingStrategy && (
        <div className="bg-white border-2 border-emerald-500 rounded-2xl p-4 shadow-lg space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
            <span className="font-bold text-xs uppercase text-zinc-900">
              {strategies.some((s) => s.id === editingStrategy.id) ? 'Edit Strategi' : 'Buat Strategi Baru'}
            </span>
            <button
              type="button"
              onClick={() => {
                setIsEditing(false);
                setEditingStrategy(null);
              }}
              className="text-zinc-400 hover:text-zinc-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-zinc-500 font-bold uppercase block">
              Nama Strategi
            </label>
            <input
              type="text"
              value={editingStrategy.name}
              onChange={(e) =>
                setEditingStrategy({ ...editingStrategy, name: e.target.value })
              }
              placeholder="Contoh: Strategi Martingale 2x"
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 font-bold text-xs outline-none focus:border-emerald-500"
            />
          </div>

          {/* BET AMOUNT & NUMBER OF BETS (STRATEGY LEVEL) */}
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 font-bold uppercase block">
                Jumlah Taruhan ({currency.toUpperCase()})
              </label>
              <input
                type="text"
                placeholder="0"
                value={editingStrategy.betAmount}
                onChange={(e) =>
                  setEditingStrategy({ ...editingStrategy, betAmount: e.target.value })
                }
                className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 font-bold text-xs outline-none focus:border-emerald-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] text-zinc-500 font-bold uppercase block">
                Jumlah Putaran (0 = ∞)
              </label>
              <input
                type="number"
                min="0"
                placeholder="0"
                value={editingStrategy.numberOfBets}
                onChange={(e) =>
                  setEditingStrategy({ ...editingStrategy, numberOfBets: e.target.value })
                }
                className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 font-bold text-xs outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* ON WIN & ON LOSS CONTROLS */}
          <AutoBetStrategyControls
            onWinAction={editingStrategy.onWinAction || 'reset'}
            onChangeOnWinAction={(val) => setEditingStrategy({ ...editingStrategy, onWinAction: val })}
            onWinPercent={editingStrategy.onWinPercent || '0'}
            onChangeOnWinPercent={(val) => setEditingStrategy({ ...editingStrategy, onWinPercent: val })}
            onWinEveryCount={editingStrategy.onWinEveryCount || '1'}
            onChangeOnWinEveryCount={(val) => setEditingStrategy({ ...editingStrategy, onWinEveryCount: val })}
            onLossAction={editingStrategy.onLossAction || 'reset'}
            onChangeOnLossAction={(val) => setEditingStrategy({ ...editingStrategy, onLossAction: val })}
            onLossPercent={editingStrategy.onLossPercent || '0'}
            onChangeOnLossPercent={(val) => setEditingStrategy({ ...editingStrategy, onLossPercent: val })}
            onLossEveryCount={editingStrategy.onLossEveryCount || '1'}
            onChangeOnLossEveryCount={(val) => setEditingStrategy({ ...editingStrategy, onLossEveryCount: val })}
            currency={currency}
          />

          {/* GAME SPECIFIC FORM */}
          {renderStrategyForm(
            editingStrategy,
            setEditingStrategy as React.Dispatch<React.SetStateAction<SavedStrategy>>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-100">
            <button
              type="button"
              onClick={() => {
                setIsEditing(false);
                setEditingStrategy(null);
              }}
              className="px-3 py-1.5 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSaveEdit}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Simpan Strategi</span>
            </button>
          </div>
        </div>
      )}

      {/* GLOBAL / DEDICATED AUTO-BET SAFEGUARDS / STOPS */}
      <div className={`border border-zinc-200 rounded-xl bg-white ${showAdvancedStops ? '' : 'overflow-hidden'}`}>
        <button
          type="button"
          onClick={() => setShowAdvancedStops(!showAdvancedStops)}
          className="w-full p-2.5 bg-zinc-50 hover:bg-zinc-100 flex items-center justify-between text-xs font-bold text-zinc-700 transition cursor-pointer rounded-t-xl"
        >
          <div className="flex items-center gap-1.5 flex-wrap">
            <span>
              {`Pemicu & Batas Stop (${activeStrategy?.name ? `Strategi: ${activeStrategy.name}` : 'Strategi Tunggal'})`}
            </span>
            <span className="text-[10px] font-normal text-zinc-400">
              (Terintegrasi ke Strategi & JSON)
            </span>
          </div>
          {showAdvancedStops ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {showAdvancedStops && (
          <div className="p-3 space-y-3 text-xs bg-white border-t border-zinc-200 rounded-b-xl">
            {/* Mode notification badge */}
            <div className="p-2 rounded-lg border text-[11px] font-bold flex items-center justify-between bg-emerald-50 border-emerald-200 text-emerald-900">
              <span>
                {`🎯 Batas Stop & Pemicu Strategi: ${activeStrategy?.name || 'Tunggal'}`}
              </span>
              <span className="text-[10px] font-normal opacity-80 hidden sm:inline">
                Otomatis ikut tersimpan ke file JSON strategi
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Stop Profit */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Stop Profit (+{currency.toUpperCase()})
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-emerald-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Berhenti otomatis jika total akumulasi keuntungan (profit) bersih sesi taruhan mencapai target angka ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={stopProfit}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeStopProfit(val);
                    updateActiveStrategyField('stopProfit', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Target profit bersih untuk otomatis stop</p>
              </div>

              {/* Stop Loss */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Stop Loss (-{currency.toUpperCase()})
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-rose-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Berhenti otomatis jika total kerugian (drawdown) bersih sesi taruhan mencapai batas nominal ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={stopLoss}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeStopLoss(val);
                    updateActiveStrategyField('stopLoss', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Batas rugi bersih maksimal untuk stop</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Pagu Max Bet Cap */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Pagu Max Bet Cap
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-indigo-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Batas nominal taruhan tertinggi. Jika skema Martingale menaikkan bet, nilai bet dipatok agar tidak melebihi angka ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={maxBetCap}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeMaxBetCap(val);
                    updateActiveStrategyField('maxBetCap', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Cap batas maksimum nominal taruhan</p>
              </div>

              {/* Trailing Stop Drawdown */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Trailing Stop Drawdown
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-amber-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Kunci profit: Bot otomatis stop jika profit turun sebesar nominal ini dari puncak profit tertinggi (peak profit) sesi.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={trailingStop}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeTrailingStop(val);
                    updateActiveStrategyField('trailingStop', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Stop jika profit drop X dari puncak sesi</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Max Consecutive Losses */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Max Loss Beruntun
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-purple-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Berhenti otomatis jika bot mengalami kekalahan berturut-turut (consecutive losses) sebanyak ronde ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={maxConsecutiveLosses}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeMaxConsecutiveLosses(val);
                    updateActiveStrategyField('stopLoseStreak', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Stop jika kalah X kali berturut-turut</p>
              </div>

              {/* Stop Wager Nominal */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Stop Wager Nominal
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-blue-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-52 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Berhenti otomatis jika akumulasi nilai total taruhan yang dipasang (total wagered) mencapai nominal ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={stopWager}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeStopWager(val);
                    updateActiveStrategyField('stopWager', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Stop jika akumulasi wager capai target</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              {/* Stop Saldo Minimal */}
              <div className="space-y-1 bg-zinc-50/80 p-2 rounded-lg border border-zinc-200/80">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-zinc-700 font-bold uppercase block">
                    Stop Saldo Minimal
                  </label>
                  <div className="group relative cursor-pointer">
                    <Info className="w-3.5 h-3.5 text-zinc-400 hover:text-red-600 transition" />
                    <div className="pointer-events-none absolute right-0 top-full mt-1 hidden group-hover:block w-60 p-2 bg-zinc-900 text-white text-[10px] rounded-lg shadow-xl z-50 leading-tight">
                      Pengaman saldo akun: bot membatalkan taruhan &amp; langsung berhenti jika saldo di dompet tersisa &le; angka ini.
                      <div className="absolute right-2 bottom-full border-4 border-transparent border-b-zinc-900"></div>
                    </div>
                  </div>
                </div>
                <input
                  type="text"
                  placeholder="0 (Off)"
                  value={stopBalanceMin}
                  onChange={(e) => {
                    const val = e.target.value;
                    onChangeStopBalanceMin(val);
                    updateActiveStrategyField('stopBalanceMin', val);
                  }}
                  className="w-full bg-white border border-zinc-200 rounded-lg px-2.5 py-1 text-xs font-bold focus:ring-1 focus:ring-emerald-500 transition"
                />
                <p className="text-[9px] text-zinc-400">Pengaman darurat: stop jika saldo tersisa di dompet &le; nominal ini</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
