import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  ArrowLeftRight,
  Play,
  Square,
  Dices,
  KeyRound,
  ShieldCheck,
  Zap,
  Settings,
  BarChart2,
} from 'lucide-react';
import { AutobetConfig, BatchProgress, DiceCondition, DiceSavedStrategy, SavedStrategy, StrategySwitchRule } from '../types/stake';
import { SeedModal } from './SeedModal';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import { GameFooterToolbar } from './GameFooterToolbar';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface DiceGameProps {
  balance: number;
  currency: string;
  isRolling: boolean;
  onBet: (amount: number, target: number, condition: DiceCondition) => Promise<boolean>;
  houseEdgePercent: number;
  autobetRunning: boolean;
  onToggleAutobet: (config: AutobetConfig, target: number, condition: DiceCondition) => void;
  onStopAutobet: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  batchProgress?: BatchProgress | null;
  currentStreak?: { type: 'win' | 'loss' | 'none'; count: number };
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin: boolean;
  stopOnLoss: boolean;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

// Sub-component allowing flexible draft typing for Multiplier & Chance in Dice Strategy Form
const DiceStrategyTargetFields: React.FC<{
  condition: DiceCondition;
  target: number;
  houseEdgePercent: number;
  onChangeTarget: (newTarget: number) => void;
}> = ({ condition, target, houseEdgePercent, onChangeTarget }) => {
  const edgeFactor = (100 - houseEdgePercent) / 100;
  const currentChance = condition === 'above' ? 100 - target : target;
  const clampedChance = Math.max(0.01, Math.min(98.0, currentChance));
  const currentMult = (edgeFactor * 100) / clampedChance;

  const [multDraft, setMultDraft] = useState<string>(() => currentMult.toFixed(4));
  const [chanceDraft, setChanceDraft] = useState<string>(() => clampedChance.toFixed(2));

  // Sync draft whenever external target/condition flips or updates
  useEffect(() => {
    setMultDraft(currentMult.toFixed(4));
    setChanceDraft(clampedChance.toFixed(2));
  }, [condition, target, houseEdgePercent]);

  const commitMultiplier = (raw: string) => {
    const clean = raw.trim().replace(',', '.');
    if (!clean) {
      setMultDraft(currentMult.toFixed(4));
      return;
    }
    let parsed = parseFloat(clean);
    if (isNaN(parsed)) {
      setMultDraft(currentMult.toFixed(4));
      return;
    }

    // Stake minimum multiplier is 1.0102 (for max 98% chance), max 9900.0
    // If user enters 1.01 or less, automatically correct to 1.0102
    const MIN_MULT = 1.0102;
    const MAX_MULT = 9900.0;
    if (parsed < MIN_MULT) parsed = MIN_MULT;
    if (parsed > MAX_MULT) parsed = MAX_MULT;

    let calcChance = (edgeFactor * 100) / parsed;
    calcChance = Math.max(0.01, Math.min(98.0, Number(calcChance.toFixed(2))));
    const finalMult = Number(((edgeFactor * 100) / calcChance).toFixed(4));
    const newTarget = condition === 'above' ? 100 - calcChance : calcChance;

    onChangeTarget(Number(newTarget.toFixed(2)));
    setMultDraft(finalMult.toFixed(4));
    setChanceDraft(calcChance.toFixed(2));
  };

  const commitChance = (raw: string) => {
    const clean = raw.trim().replace(',', '.');
    if (!clean) {
      setChanceDraft(clampedChance.toFixed(2));
      return;
    }
    let parsed = parseFloat(clean);
    if (isNaN(parsed)) {
      setChanceDraft(clampedChance.toFixed(2));
      return;
    }
    const cChance = Math.max(0.01, Math.min(98.0, Number(parsed.toFixed(2))));
    const finalMult = Number(((edgeFactor * 100) / cChance).toFixed(4));
    const newTarget = condition === 'above' ? 100 - cChance : cChance;

    onChangeTarget(Number(newTarget.toFixed(2)));
    setChanceDraft(cChance.toFixed(2));
    setMultDraft(finalMult.toFixed(4));
  };

  return (
    <div className="grid grid-cols-2 gap-2">
      {/* Multiplier Box Input */}
      <div className="space-y-1">
        <label className="text-[10px] text-zinc-500 font-bold uppercase block">
          Multiplier Target (×)
        </label>
        <div className="flex items-center bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 focus-within:border-emerald-500">
          <input
            type="text"
            inputMode="decimal"
            placeholder="1.0102"
            value={multDraft}
            onChange={(e) => setMultDraft(e.target.value)}
            onBlur={() => commitMultiplier(multDraft)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                commitMultiplier(multDraft);
              }
            }}
            className="w-full bg-transparent font-bold text-xs text-zinc-900 outline-none font-mono"
          />
          <span className="text-zinc-400 font-bold text-xs select-none">×</span>
        </div>
      </div>

      {/* Win Chance Box Input */}
      <div className="space-y-1">
        <label className="text-[10px] text-zinc-500 font-bold uppercase block">
          Peluang Menang (%)
        </label>
        <div className="flex items-center bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 focus-within:border-emerald-500">
          <input
            type="text"
            inputMode="decimal"
            placeholder="49.50"
            value={chanceDraft}
            onChange={(e) => setChanceDraft(e.target.value)}
            onBlur={() => commitChance(chanceDraft)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                commitChance(chanceDraft);
              }
            }}
            className="w-full bg-transparent font-bold text-xs text-emerald-600 outline-none font-mono"
          />
          <span className="text-emerald-600 font-bold text-xs select-none">%</span>
        </div>
      </div>
    </div>
  );
};

export const DiceGame: React.FC<DiceGameProps> = ({
  balance,
  currency,
  isRolling,
  onBet,
  houseEdgePercent = 1.0,
  autobetRunning,
  onToggleAutobet,
  onStopAutobet,
  onShowToast,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin,
  stopOnLoss,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: switchRulesEnabledProp,
}) => {
  // Mode: Manual or Auto (Otomatis)
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies State - starts empty per user request
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() =>
    loadSavedStrategies('dice')
  );

  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('dice');
    const activeId = getActiveStrategyId('dice');
    if (activeId) {
      const found = list.find((s) => s.id === activeId);
      if (found) return found;
    }
    return list.length > 0 ? list[0] : null;
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const handleImportStrategies = (imported: SavedStrategy[]) => {
    setStrategies((prev) => {
      const existingIds = new Set(prev.map((s) => s.id));
      const newItems = imported.filter((s) => !existingIds.has(s.id));
      const updated = [...newItems, ...prev];
      saveSavedStrategies('dice', updated);
      if (imported[0]) {
        handleSelectStrategy(imported[0]);
      }
      return updated;
    });
  };

  // Bet amount
  const [betAmount, setBetAmount] = useState<string>(() => {
    const saved = localStorage.getItem('dice_bet_amount');
    return activeStrategy?.betAmount || (saved === '0.00000001' ? '0' : saved) || '0';
  });
  // Target & Condition
  const [condition, setCondition] = useState<DiceCondition>(() => {
    return (activeStrategy as DiceSavedStrategy)?.condition || (localStorage.getItem('dice_condition') as DiceCondition) || 'above';
  });
  const [target, setTarget] = useState<number>(() => {
    const saved = localStorage.getItem('dice_target');
    return (activeStrategy as DiceSavedStrategy)?.target || (saved ? Number(saved) : 50.50);
  });

  // Auto Bet Parameters
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('dice_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('dice_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('dice_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('dice_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('dice_on_loss_percent') || '0');
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('dice_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('dice_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('dice_max_bet_cap') || '0');
  const [localStopLoseStreak, setLocalStopLoseStreak] = useState<string>(() => activeStrategy?.stopLoseStreak || (stopLoseStreak > 0 ? String(stopLoseStreak) : localStorage.getItem('dice_stop_lose_streak') || '0'));
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('dice_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => localStorage.getItem('dice_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => localStorage.getItem('dice_stop_balance_min') || '0');
  const [batchDelayMs, setBatchDelayMs] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('stake_batch_delay_ms'));
      return saved ? Math.max(100, saved) : 100;
    } catch {
      return 100;
    }
  });

  // Dynamic Strategy Switch Rules
  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('dice'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('dice'));

  const handleUpdateSwitchRules = (newRules: StrategySwitchRule[]) => {
    setSwitchRules(newRules);
    saveSwitchRules('dice', newRules);
  };

  const handleToggleSwitchRulesEnabled = (val: boolean) => {
    setSwitchRulesEnabledState(val);
    setSwitchRulesEnabled('dice', val);
  };

  // Strategy switching handler
  const handleSelectStrategy = (strat: SavedStrategy) => {
    const diceStrat = strat as DiceSavedStrategy;
    activeStrategyRef.current = strat;
    setActiveStrategy(strat);
    setActiveStrategyId('dice', strat.id);

    setBetAmount(strat.betAmount !== undefined ? strat.betAmount : '0');
    if (diceStrat.condition) setCondition(diceStrat.condition);
    if (typeof diceStrat.target === 'number') setTarget(diceStrat.target);
    setNumberOfBets(strat.numberOfBets !== undefined ? strat.numberOfBets : '0');
    setOnWinAction(strat.onWinAction || 'reset');
    setOnWinPercent(strat.onWinPercent !== undefined ? strat.onWinPercent : '0');
    setOnLossAction(strat.onLossAction || 'reset');
    setOnLossPercent(strat.onLossPercent !== undefined ? strat.onLossPercent : '0');
    setStopProfit(strat.stopProfit !== undefined ? strat.stopProfit : '0');
    stopProfitRef.current = parseFloat(strat.stopProfit || '0') || 0;
    setStopLoss(strat.stopLoss !== undefined ? strat.stopLoss : '0');
    stopLossRef.current = parseFloat(strat.stopLoss || '0') || 0;
    setMaxBetCap(strat.maxBetCap !== undefined ? strat.maxBetCap : '0');
    maxBetCapRef.current = parseFloat(strat.maxBetCap || '0') || 0;
    setLocalStopLoseStreak(strat.stopLoseStreak !== undefined ? strat.stopLoseStreak : '0');
    stopLoseStreakRef.current = parseInt(strat.stopLoseStreak || '0', 10) || 0;
    setTrailingStop(strat.trailingStop !== undefined ? strat.trailingStop : '0');
    trailingStopRef.current = parseFloat(strat.trailingStop || '0') || 0;
    setStopWager(strat.stopWager !== undefined ? strat.stopWager : '0');
    stopWagerRef.current = parseFloat(strat.stopWager || '0') || 0;
    setStopBalanceMin(strat.stopBalanceMin !== undefined ? strat.stopBalanceMin : '0');
    stopBalanceMinRef.current = parseFloat(strat.stopBalanceMin || '0') || 0;

    // Apply stop limits and triggers unconditionally so Strategy 2 resets Strategy 1's values
    onUpdateTriggers?.({
      stopOnWin: !!strat.stopOnWin,
      stopOnLoss: !!strat.stopOnLoss,
      stopLoseStreak: parseInt(strat.stopLoseStreak || '0', 10) || 0,
      stopWinStreak: parseInt(strat.stopWinStreak || '0', 10) || 0,
    });

    onShowToast?.('Strategi Dipilih', 'ON', `Mengaktifkan strategi "${strat.name}"`);
  };

  const handleSaveStrategy = (strat: SavedStrategy) => {
    setStrategies((prev) => {
      const idx = prev.findIndex((s) => s.id === strat.id);
      let updated: SavedStrategy[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = strat;
      } else {
        updated = [strat, ...prev];
      }
      saveSavedStrategies('dice', updated);
      return updated;
    });
    handleSelectStrategy(strat);
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveSavedStrategies('dice', updated);
      if (activeStrategy?.id === id) {
        const next = updated.length > 0 ? updated[0] : null;
        setActiveStrategy(next);
        if (next) {
          setActiveStrategyId('dice', next.id);
        } else {
          localStorage.removeItem('stake_active_strategy_dice');
        }
      }
      return updated;
    });
  };

  // Refs for real-time live evaluation
  const stopProfitRef = useRef<number>(parseFloat(stopProfit) || 0);
  const stopLossRef = useRef<number>(parseFloat(stopLoss) || 0);
  const maxBetCapRef = useRef<number>(parseFloat(maxBetCap) || 0);
  const trailingStopRef = useRef<number>(parseFloat(trailingStop) || 0);
  const stopWagerRef = useRef<number>(parseFloat(stopWager) || 0);
  const stopBalanceMinRef = useRef<number>(parseFloat(stopBalanceMin) || 0);
  const stopOnWinRef = useRef<boolean>(stopOnWin);
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);
  const stopWinStreakRef = useRef<number>(stopWinStreak);

  useEffect(() => { stopOnWinRef.current = stopOnWin; }, [stopOnWin]);
  useEffect(() => { stopOnLossRef.current = stopOnLoss; }, [stopOnLoss]);
  useEffect(() => {
    if (stopLoseStreak > 0) {
      stopLoseStreakRef.current = stopLoseStreak;
      setLocalStopLoseStreak(String(stopLoseStreak));
    }
  }, [stopLoseStreak]);
  useEffect(() => { stopWinStreakRef.current = stopWinStreak; }, [stopWinStreak]);

  const handleStopProfitChange = (val: string) => {
    setStopProfit(val);
    stopProfitRef.current = parseFloat(val) || 0;
  };

  const handleStopLossChange = (val: string) => {
    setStopLoss(val);
    stopLossRef.current = parseFloat(val) || 0;
  };

  const handleMaxBetCapChange = (val: string) => {
    setMaxBetCap(val);
    maxBetCapRef.current = parseFloat(val) || 0;
  };

  const handleLocalStopLoseStreakChange = (val: string) => {
    setLocalStopLoseStreak(val);
    stopLoseStreakRef.current = parseInt(val, 10) || 0;
  };

  const handleTrailingStopChange = (val: string) => {
    setTrailingStop(val);
    trailingStopRef.current = parseFloat(val) || 0;
  };

  const handleStopWagerChange = (val: string) => {
    setStopWager(val);
    stopWagerRef.current = parseFloat(val) || 0;
  };

  const handleStopBalanceMinChange = (val: string) => {
    setStopBalanceMin(val);
    stopBalanceMinRef.current = parseFloat(val) || 0;
  };

  // Save settings effect
  useEffect(() => {
    localStorage.setItem('dice_bet_amount', betAmount);
    localStorage.setItem('dice_condition', condition);
    localStorage.setItem('dice_target', target.toString());
    localStorage.setItem('dice_num_bets', numberOfBets);
    localStorage.setItem('dice_on_win_action', onWinAction);
    localStorage.setItem('dice_on_win_percent', onWinPercent);
    localStorage.setItem('dice_on_loss_action', onLossAction);
    localStorage.setItem('dice_on_loss_percent', onLossPercent);
    localStorage.setItem('dice_stop_profit', stopProfit);
    localStorage.setItem('dice_stop_loss', stopLoss);
    localStorage.setItem('dice_max_bet_cap', maxBetCap);
    localStorage.setItem('dice_stop_lose_streak', localStopLoseStreak);
    localStorage.setItem('dice_trailing_stop', trailingStop);
    localStorage.setItem('dice_stop_wager', stopWager);
    localStorage.setItem('dice_stop_balance_min', stopBalanceMin);
    localStorage.setItem('stake_batch_delay_ms', String(batchDelayMs));
  }, [betAmount, condition, target, numberOfBets, onWinAction, onWinPercent, onLossAction, onLossPercent, stopProfit, stopLoss, maxBetCap, localStopLoseStreak, trailingStop, stopWager, stopBalanceMin, batchDelayMs]);

  // Provably Fair Seed state & Popover
  const [clientSeed, setClientSeed] = useState<string>(() => {
    try {
      return localStorage.getItem('stake_client_seed') || 'jstkbot_client_seed_x9a82';
    } catch {
      return 'jstkbot_client_seed_x9a82';
    }
  });
  const [serverSeedHash] = useState<string>('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  const [nonce, setNonce] = useState<number>(1);
  const [isSeedModalOpen, setIsSeedModalOpen] = useState<boolean>(false);

  const handleSaveSeed = (newSeed: string) => {
    setClientSeed(newSeed);
    try {
      localStorage.setItem('stake_client_seed', newSeed);
    } catch {}
    onShowToast?.('Seed Diperbarui', 'ON', `Client Seed berhasil diganti ke "${newSeed}"`);
  };

  const edgeFactor = (100 - houseEdgePercent) / 100;

  const winChance = useMemo(() => {
    const chance = condition === 'above' ? 100 - target : target;
    return Math.max(0.01, Math.min(98.0, Number(chance.toFixed(2))));
  }, [condition, target]);

  const multiplier = useMemo(() => {
    const mult = (edgeFactor * 100) / winChance;
    return Math.max(1.0102, Number(mult.toFixed(4)));
  }, [edgeFactor, winChance]);

  const [multiplierInput, setMultiplierInput] = useState<string>('2.0000');
  const [winChanceInput, setWinChanceInput] = useState<string>('49.50');

  useEffect(() => {
    setMultiplierInput(multiplier.toFixed(4));
    setWinChanceInput(winChance.toFixed(2));
  }, [multiplier, winChance]);

  const numericInput = useMemo(() => {
    const trimmed = betAmount.trim();
    if (!trimmed) return 0;
    const isIdr = currency.toLowerCase() === 'idr';
    let clean = trimmed.replace(/\s/g, '');
    if (isIdr) {
      if (/^\d{1,3}(\.\d{3})+$/.test(clean)) {
        clean = clean.replace(/\./g, '');
      } else {
        clean = clean.replace(',', '.');
      }
    } else {
      clean = clean.replace(',', '.');
    }
    const val = parseFloat(clean);
    return isNaN(val) || val < 0 ? 0 : val;
  }, [betAmount, currency]);

  const profitCrypto = useMemo(() => {
    if (numericInput <= 0) return 0;
    return numericInput * (multiplier - 1);
  }, [numericInput, multiplier]);

  const commitMultiplierChange = (rawStr: string) => {
    const trimmed = rawStr.trim().replace(',', '.');
    if (!trimmed) {
      setMultiplierInput(multiplier.toFixed(4));
      return;
    }
    const parsed = parseFloat(trimmed);
    if (isNaN(parsed)) {
      setMultiplierInput(multiplier.toFixed(4));
      return;
    }
    const MIN_MULT = 1.0102;
    const MAX_MULT = 9900.0;
    const clamped = Math.max(MIN_MULT, Math.min(MAX_MULT, parsed));
    const calculatedChance = (edgeFactor * 100) / clamped;
    const clampedChance = Math.max(0.01, Math.min(98.0, Number(calculatedChance.toFixed(2))));
    const validMultiplier = Number(((edgeFactor * 100) / clampedChance).toFixed(4));
    const newTarget = condition === 'above' ? 100 - clampedChance : clampedChance;
    setTarget(Number(newTarget.toFixed(2)));
    setMultiplierInput(validMultiplier.toFixed(4));
  };

  const commitWinChanceChange = (rawStr: string) => {
    const trimmed = rawStr.trim().replace(',', '.');
    if (!trimmed) {
      setWinChanceInput(winChance.toFixed(2));
      return;
    }
    const parsed = parseFloat(trimmed);
    if (isNaN(parsed)) {
      setWinChanceInput(winChance.toFixed(2));
      return;
    }
    const clampedChance = Math.max(0.01, Math.min(98.0, parsed));
    const newTarget = condition === 'above' ? 100 - clampedChance : clampedChance;
    setTarget(Number(newTarget.toFixed(2)));
    setWinChanceInput(clampedChance.toFixed(2));
  };

  const toggleCondition = () => {
    const nextCond = condition === 'above' ? 'below' : 'above';
    setCondition(nextCond);
    setTarget(Number((100 - target).toFixed(2)));
  };

  const handleMin = () => setBetAmount('0');
  const handleHalf = () => {
    if (numericInput <= 0) {
      setBetAmount('0');
      return;
    }
    setBetAmount(Math.max(0, Number((numericInput / 2).toFixed(8))).toString());
  };
  const handleDouble = () => {
    if (numericInput <= 0) {
      setBetAmount(currency.toLowerCase() === 'idr' ? '1000' : '0.00000001');
      return;
    }
    setBetAmount(Number((numericInput * 2).toFixed(8)).toString());
  };

  const handleSingleBet = async () => {
    if (isRolling || autobetRunning) return;
    const success = await onBet(numericInput, target, condition);
    if (success !== undefined) {
      setNonce((prev) => prev + 1);
    }
  };

  const handleStartAutoBet = () => {
    const currentStrat = (activeStrategy || strategies.find(s => s.id === getActiveStrategyId('dice')) || strategies[0]) as DiceSavedStrategy | undefined;

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : numericInput;
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const autoTarget = (typeof currentStrat?.target === 'number') ? currentStrat.target : target;
    const autoCondition = currentStrat?.condition || condition;

    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(currentStrat.onWinEveryCount, 10) || 1
      : 1;
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(currentStrat.onLossEveryCount, 10) || 1
      : 1;

    const autoConfig: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      stopLoseStreak: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      batchDelayMs,
      onBetAmountChange: (amt) => setBetAmount(amt.toString()),
      switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onSwitchStrategy: (targetStrat) => {
        handleSelectStrategy(targetStrat);
      },
      getLiveTriggers: () => ({
        stopOnWin: stopOnWinRef.current,
        stopOnLoss: stopOnLossRef.current,
        stopLoseStreak: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        maxConsecutiveLosses: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        stopWinStreak: stopWinStreakRef.current,
        stopProfit: stopProfitRef.current,
        stopLoss: stopLossRef.current,
        maxBetCap: maxBetCapRef.current,
        trailingStop: trailingStopRef.current,
        stopWager: stopWagerRef.current,
        stopBalanceMin: stopBalanceMinRef.current,
        switchRules,
        switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(autoConfig, autoTarget, autoCondition);
  };

  return (
    <div className="flex flex-col gap-3 font-sans">
      {/* Top Game Header Bar */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3 font-sans">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
            <Dices className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900 tracking-tight">
                DICE
              </h2>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-200 font-mono font-bold px-1.5 py-0.2 rounded">
                STAKE ORIGINAL
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-zinc-500 font-mono">
              Acak nomor 0.00 - 99.99 • Max Win 4950.00× • House Edge {houseEdgePercent}%
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3 font-mono text-zinc-900">
        {/* 1. TOP TAB PILL CONTAINER (MANUAL vs OTOMATIS) */}
        <div className="bg-zinc-200/80 p-1 rounded-full grid grid-cols-2 gap-1 w-full max-w-sm mx-auto">
        <button
          type="button"
          onClick={() => {
            if (autobetRunning) return;
            setTabMode('manual');
          }}
          disabled={autobetRunning}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'manual'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Manual</span>
        </button>

        <button
          type="button"
          onClick={() => setTabMode('auto')}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'auto'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Otomatis</span>
          {autobetRunning && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
        </button>
      </div>

      {/* AUTO BET RUNNING STATUS */}
      {autobetRunning && batchProgress && (
        <div className="bg-emerald-600 text-white rounded-xl p-3 flex items-center justify-between text-xs shadow-md">
          <div className="space-y-0.5">
            <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>Auto Bet Dice: Putaran {batchProgress.currentRound} / {batchProgress.totalRounds || '∞'}</span>
              {batchProgress.activeStrategyName && (
                <span className="bg-emerald-700/80 px-1.5 py-0.5 rounded text-[10px] font-black border border-emerald-400/40">
                  {batchProgress.activeStrategyName}
                </span>
              )}
            </span>
            <span className="text-[10px] text-emerald-100 flex items-center gap-2 flex-wrap">
              <span>Profit: <strong>{batchProgress.runningProfit >= 0 ? `+${batchProgress.runningProfit}` : batchProgress.runningProfit} {currency.toUpperCase()}</strong></span>
              {batchProgress.peakProfit !== undefined && batchProgress.peakProfit > 0 && (
                <span>• Puncak: <strong className="text-white">+{batchProgress.peakProfit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 6)}</strong></span>
              )}
              {batchProgress.totalWagered !== undefined && (
                <span>• Wager: <strong>{batchProgress.totalWagered} {currency.toUpperCase()}</strong></span>
              )}
            </span>
          </div>
          <button
            type="button"
            onClick={onStopAutobet}
            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer transition flex items-center gap-1"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Berhenti</span>
          </button>
        </div>
      )}

      {/* MANUAL BET CONTROLS */}
      {tabMode === 'manual' && (
        <>
          <div className="flex flex-col gap-2.5 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
            <div className="flex items-center justify-between text-xs font-bold text-zinc-700">
              <span className="text-zinc-900 uppercase">Jumlah Taruhan</span>
              <span className="text-[10px] text-zinc-500 font-normal">
                Saldo: <strong className="text-zinc-900">{balance.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="0"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={autobetRunning}
                  className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 font-mono text-xs sm:text-sm font-bold text-zinc-900 outline-none focus:border-emerald-500 transition disabled:opacity-75"
                />
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleMin}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  0
                </button>
                <button
                  onClick={handleHalf}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  ½
                </button>
                <button
                  onClick={handleDouble}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  2×
                </button>
              </div>
            </div>

            {/* Target Multiplier & Win Chance Grid */}
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-zinc-200">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold uppercase block mb-0.5">Multiplier</span>
                <div className="flex items-center gap-0.5 bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 focus-within:border-emerald-500 transition">
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="2.0000"
                    value={multiplierInput}
                    onChange={(e) => setMultiplierInput(e.target.value)}
                    onBlur={() => commitMultiplierChange(multiplierInput)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        commitMultiplierChange(multiplierInput);
                      }
                    }}
                    disabled={autobetRunning}
                    className="w-full bg-transparent font-bold text-xs text-zinc-900 outline-none"
                  />
                  <span className="font-bold text-zinc-400 select-none text-xs">×</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-zinc-500 font-bold uppercase block mb-0.5">Peluang</span>
                <div className="flex items-center gap-0.5 bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 focus-within:border-emerald-500 transition">
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="49.50"
                    value={winChanceInput}
                    onChange={(e) => setWinChanceInput(e.target.value)}
                    onBlur={() => commitWinChanceChange(winChanceInput)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        commitWinChanceChange(winChanceInput);
                      }
                    }}
                    disabled={autobetRunning}
                    className="w-full bg-transparent font-bold text-xs text-emerald-600 outline-none"
                  />
                  <span className="font-bold text-emerald-600 select-none text-xs">%</span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[10px] text-zinc-500 font-bold uppercase">Roll</span>
                  <button
                    type="button"
                    onClick={toggleCondition}
                    disabled={autobetRunning}
                    className="text-[9px] text-emerald-600 font-bold hover:underline cursor-pointer flex items-center"
                  >
                    <ArrowLeftRight className="w-2.5 h-2.5 mr-0.5" /> Flip
                  </button>
                </div>
                <div className="bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 flex items-center justify-center font-bold text-xs text-zinc-900">
                  {condition === 'above' ? '>' : '<'} {target.toFixed(2)}
                </div>
              </div>
            </div>
          </div>

          {/* ESTIMASI PROFIT BANNER */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center justify-between text-xs">
            <span className="text-emerald-900 font-bold">ESTIMASI PROFIT JIKA MENANG:</span>
            <span className="font-bold text-emerald-700 text-sm">
              +{profitCrypto.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}
            </span>
          </div>
        </>
      )}

      {/* OTOMATIS MODE: TAMPIL HANYA LIST DAFTAR STRATEGI */}
      {tabMode === 'auto' && (
        <div className="space-y-3">
          <AutoBetStrategyManager
            game="dice"
            currency={currency}
            strategies={strategies}
            activeStrategy={activeStrategy}
            onSelectStrategy={handleSelectStrategy}
            onSaveStrategy={handleSaveStrategy}
            onDeleteStrategy={handleDeleteStrategy}
            onImportStrategies={handleImportStrategies}
            autobetRunning={autobetRunning}
            onShowToast={onShowToast}
            stopProfit={stopProfit}
            onChangeStopProfit={handleStopProfitChange}
            stopLoss={stopLoss}
            onChangeStopLoss={handleStopLossChange}
            maxBetCap={maxBetCap}
            onChangeMaxBetCap={handleMaxBetCapChange}
            maxConsecutiveLosses={localStopLoseStreak}
            onChangeMaxConsecutiveLosses={handleLocalStopLoseStreakChange}
            trailingStop={trailingStop}
            onChangeTrailingStop={handleTrailingStopChange}
            stopWager={stopWager}
            onChangeStopWager={handleStopWagerChange}
            stopBalanceMin={stopBalanceMin}
            onChangeStopBalanceMin={handleStopBalanceMinChange}
            stopOnWin={stopOnWin}
            onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
            stopOnLoss={stopOnLoss}
            onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
            stopWinStreak={String(stopWinStreak)}
            onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
            switchRules={switchRules}
            onChangeSwitchRules={handleUpdateSwitchRules}
            switchRulesEnabled={switchRulesEnabled}
            onToggleSwitchRulesEnabled={handleToggleSwitchRulesEnabled}
            renderStrategyForm={(temp, setTemp) => {
              const diceStrat = temp as DiceSavedStrategy;
              return (
                <div className="space-y-3">
                  {/* 1. Base Bet Amount (Jumlah Taruhan) Pertama */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                      Jumlah Taruhan Dasar (Base Amount)
                    </label>
                    <input
                      type="text"
                      value={diceStrat.betAmount}
                      onChange={(e) => setTemp({ ...diceStrat, betAmount: e.target.value })}
                      placeholder="0.00000000"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* 2. Target Multiplier & Peluang Kedua */}
                  <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 space-y-2.5">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-zinc-800">Target Multiplier &amp; Peluang:</span>
                      <button
                        type="button"
                        onClick={() => {
                          const nextCond = diceStrat.condition === 'above' ? 'below' : 'above';
                          const curChance = diceStrat.condition === 'above' ? 100 - diceStrat.target : diceStrat.target;
                          const newTarget = nextCond === 'above' ? 100 - curChance : curChance;
                          setTemp({ ...diceStrat, condition: nextCond, target: Math.min(Math.max(0.01, newTarget), 99.98) });
                        }}
                        className="px-2.5 py-1 rounded-lg bg-white border border-zinc-300 hover:bg-zinc-100 text-emerald-700 text-[10px] font-bold cursor-pointer transition shadow-2xs"
                      >
                        Flip: {diceStrat.condition === 'above' ? 'Di Atas (>)' : 'Di Bawah (<)'}
                      </button>
                    </div>

                    {/* Flexible draft Multiplier & Win Chance Fields with auto-correction to 1.0102 */}
                    <DiceStrategyTargetFields
                      condition={diceStrat.condition}
                      target={diceStrat.target}
                      houseEdgePercent={houseEdgePercent}
                      onChangeTarget={(newTarget) =>
                        setTemp({ ...diceStrat, target: newTarget })
                      }
                    />

                    <div className="flex items-center justify-between text-[11px] text-zinc-500 pt-1 border-t border-zinc-200/60 font-mono">
                      <span>Target Roll: <strong className="text-zinc-900">{diceStrat.condition === 'above' ? '>' : '<'} {diceStrat.target.toFixed(2)}</strong></span>
                      <span className="text-emerald-700 font-bold">House Edge: {houseEdgePercent}%</span>
                    </div>
                  </div>

                  {/* 3. Number of bets */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Jumlah Putaran (0 = Tanpa Batas)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={diceStrat.numberOfBets}
                      onChange={(e) => setTemp({ ...diceStrat, numberOfBets: e.target.value })}
                      placeholder="0"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Strategy Controls */}
                  <AutoBetStrategyControls
                    onWinAction={diceStrat.onWinAction}
                    onChangeOnWinAction={(val) => setTemp({ ...diceStrat, onWinAction: val })}
                    onWinPercent={diceStrat.onWinPercent}
                    onChangeOnWinPercent={(val) => setTemp({ ...diceStrat, onWinPercent: val })}
                    onWinEveryCount={diceStrat.onWinEveryCount || '1'}
                    onChangeOnWinEveryCount={(val) => setTemp({ ...diceStrat, onWinEveryCount: val })}
                    onLossAction={diceStrat.onLossAction}
                    onChangeOnLossAction={(val) => setTemp({ ...diceStrat, onLossAction: val })}
                    onLossPercent={diceStrat.onLossPercent}
                    onChangeOnLossPercent={(val: string) => setTemp({ ...diceStrat, onLossPercent: val })}
                    onLossEveryCount={diceStrat.onLossEveryCount || '1'}
                    onChangeOnLossEveryCount={(val: string) => setTemp({ ...diceStrat, onLossEveryCount: val })}
                    currency={currency}
                    disabled={false}
                  />
                </div>
              );
            }}
          />
        </div>
      )}

      {/* MAIN ACTION BUTTON */}
      <div className="flex flex-col gap-2 pt-1">
        {tabMode === 'manual' ? (
          <button
            type="button"
            onClick={handleSingleBet}
            disabled={isRolling}
            className="w-full py-3.5 rounded-2xl font-mono font-bold text-sm bg-emerald-600 hover:bg-emerald-700 text-white shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
          >
            <Dices className={`w-4 h-4 ${isRolling ? 'animate-spin' : ''}`} />
            <span>ROLL DICE TARUHAN</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (autobetRunning) {
                onStopAutobet();
                return;
              }
              if (isRolling) return; // Wait for last bet to finish
              if (!activeStrategy || strategies.length === 0) {
                onShowToast?.('Strategi Diperlukan', 'OFF', 'Anda wajib menambahkan strategi terlebih dahulu.');
                return;
              }
              handleStartAutoBet();
            }}
            disabled={(!autobetRunning && isRolling) || (!autobetRunning && (!activeStrategy || strategies.length === 0))}
            className={`w-full py-3.5 rounded-2xl font-mono font-bold text-sm shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              autobetRunning || (isRolling && !autobetRunning)
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
          >
            {autobetRunning ? (
              <>
                <Square className="w-4 h-4 fill-current" />
                <span>HENTIKAN OTOMATIS</span>
              </>
            ) : isRolling ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>MENGHENTIKAN...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current text-amber-300" />
                <span>
                  {!activeStrategy || strategies.length === 0 
                    ? 'TAMBAH STRATEGI DAHULU' 
                    : `MULAI AUTO BET (${activeStrategy.name})`
                  }
                </span>
              </>
            )}
          </button>
        )}
      </div>

      {/* 2. UNIFIED STAKE-STYLE CONTROLS TOOLBAR */}
      <GameFooterToolbar
        batchDelayMs={batchDelayMs}
        onBatchDelayChange={setBatchDelayMs}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="emerald"
      />
    </div>
  </div>
);
};
