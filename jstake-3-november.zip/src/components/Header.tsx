import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Settings,
  RefreshCw,
  EyeOff,
  Eye,
  ChevronDown,
  Search,
  Check,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import { StakeConfig } from '../types/stake';
import {
  STAKE_CRYPTO_LIST,
} from '../services/fiatRates';

interface HeaderProps {
  config: StakeConfig;
  balance: number;
  currency: string;
  onCurrencyChange: (c: string) => void;
  userBalances: Record<string, number>;
  isRefreshingBalance: boolean;
  onRefreshBalance: () => void;
  onOpenSettings: () => void;
  hideZeroBalances: boolean;
  onToggleHideZeroBalances: () => void;
  username?: string;
  onNavigateLobby?: () => void;
  onOpenSeedModal?: () => void;
}

const CURRENCY_BADGES: Record<string, { bg: string; text: string; iconSymbol: string }> = {
  usdt: { bg: 'bg-emerald-600', text: 'text-white', iconSymbol: '₮' },
  idr: { bg: 'bg-red-600', text: 'text-white', iconSymbol: 'IDR' },
  btc: { bg: 'bg-amber-500', text: 'text-zinc-950', iconSymbol: '₿' },
  eth: { bg: 'bg-indigo-600', text: 'text-white', iconSymbol: 'Ξ' },
  ltc: { bg: 'bg-blue-600', text: 'text-white', iconSymbol: 'Ł' },
  sol: { bg: 'bg-gradient-to-r from-teal-400 to-purple-500', text: 'text-zinc-950', iconSymbol: 'SOL' },
  doge: { bg: 'bg-amber-400', text: 'text-zinc-950', iconSymbol: 'Ð' },
  bch: { bg: 'bg-emerald-500', text: 'text-white', iconSymbol: '₿' },
  xrp: { bg: 'bg-zinc-700', text: 'text-white', iconSymbol: '✕' },
  trx: { bg: 'bg-rose-600', text: 'text-white', iconSymbol: 'TRX' },
  eos: { bg: 'bg-zinc-800', text: 'text-white', iconSymbol: 'ε' },
  bnb: { bg: 'bg-amber-400', text: 'text-zinc-950', iconSymbol: 'BNB' },
  usdc: { bg: 'bg-blue-500', text: 'text-white', iconSymbol: '$' },
  ape: { bg: 'bg-blue-700', text: 'text-white', iconSymbol: 'APE' },
  busd: { bg: 'bg-amber-300', text: 'text-zinc-900', iconSymbol: 'BUSD' },
  cro: { bg: 'bg-blue-900', text: 'text-white', iconSymbol: 'CRO' },
  dai: { bg: 'bg-amber-500', text: 'text-zinc-950', iconSymbol: '◈' },
  link: { bg: 'bg-blue-600', text: 'text-white', iconSymbol: '⬡' },
  sand: { bg: 'bg-sky-500', text: 'text-white', iconSymbol: 'SAND' },
  shib: { bg: 'bg-orange-500', text: 'text-white', iconSymbol: 'SHIB' },
  uni: { bg: 'bg-pink-600', text: 'text-white', iconSymbol: '🦄' },
  pol: { bg: 'bg-purple-600', text: 'text-white', iconSymbol: 'POL' },
  trump: { bg: 'bg-rose-700', text: 'text-white', iconSymbol: 'MAGA' },
  usd: { bg: 'bg-emerald-700', text: 'text-white', iconSymbol: '$' },
  eur: { bg: 'bg-blue-700', text: 'text-white', iconSymbol: '€' },
  jpy: { bg: 'bg-rose-600', text: 'text-white', iconSymbol: '¥' },
  brl: { bg: 'bg-green-700', text: 'text-white', iconSymbol: 'R$' },
};

export const Header: React.FC<HeaderProps> = ({
  config,
  balance,
  currency,
  onCurrencyChange,
  userBalances,
  isRefreshingBalance,
  onRefreshBalance,
  onOpenSettings,
  hideZeroBalances,
  onToggleHideZeroBalances,
  username,
  onNavigateLobby,
  onOpenSeedModal,
}) => {
  const [isWalletDropdownOpen, setIsWalletDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const isConnected = Boolean(config.token && config.token.trim().length > 0);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (dropdownRef.current && !dropdownRef.current.contains(target)) {
        setIsWalletDropdownOpen(false);
      }
    };
    if (isWalletDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isWalletDropdownOpen]);

  const allCurrencies = useMemo(() => STAKE_CRYPTO_LIST, []);

  const filteredCurrencies = useMemo(() => {
    return allCurrencies.filter((item) => {
      const codeLower = item.code.toLowerCase();
      const rawBal = userBalances[codeLower];
      const bal = typeof rawBal === 'number' && !isNaN(rawBal) ? rawBal : 0;

      if (hideZeroBalances && bal <= 0) return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return codeLower.includes(query) || item.name.toLowerCase().includes(query) || item.symbol.toLowerCase().includes(query);
      }
      return true;
    }).sort((a, b) => {
      const balA = userBalances[a.code.toLowerCase()] ?? 0;
      const balB = userBalances[b.code.toLowerCase()] ?? 0;
      if (hideZeroBalances) return balB - balA;
      return 0;
    });
  }, [allCurrencies, userBalances, hideZeroBalances, searchQuery]);

  const activeBadge = CURRENCY_BADGES[currency.toLowerCase()] || {
    bg: 'bg-zinc-700',
    text: 'text-white',
    iconSymbol: currency.toUpperCase(),
  };

  const formatBalanceDisplay = (amt: number, coinCode: string) => {
    const codeLower = coinCode.toLowerCase();
    if (['btc', 'eth', 'ltc', 'bch'].includes(codeLower)) return amt.toFixed(8);
    if (['doge', 'shib'].includes(codeLower)) return amt.toFixed(2);
    return amt.toFixed(8);
  };

  return (
    <header className="border-b border-zinc-200 bg-white sticky top-0 z-30 px-2 sm:px-4 py-1.5 sm:py-2">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-1.5 sm:gap-3">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={onNavigateLobby}
            title="Kembali ke Lobby"
            className="flex items-center gap-1.5 sm:gap-2 text-left group transition cursor-pointer select-none"
          >
            <div className="w-8 h-8 sm:w-8 sm:h-8 rounded-lg bg-emerald-600 group-hover:bg-emerald-700 flex items-center justify-center font-black text-white text-base sm:text-base tracking-wider shadow-xs transition transform group-hover:scale-105 shrink-0">
              J
            </div>
            <span className="font-bold text-sm sm:text-base tracking-tight text-zinc-900 group-hover:text-emerald-700 transition hidden sm:inline">
              JStkBot
            </span>
          </button>
          <div
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] sm:text-[10px] font-mono border ${
              isConnected
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                : 'bg-rose-50 border-rose-300 text-rose-700'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
              }`}
            />
            <span className="max-w-[60px] sm:max-w-none truncate">{isConnected ? (username || 'ON') : 'OFF'}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {isConnected && (
            <div className="relative" ref={dropdownRef}>
              <div className="flex items-center bg-zinc-100 text-zinc-900 rounded-lg sm:rounded-xl p-0.5 sm:p-1 font-mono shadow-2xs border border-zinc-200">
                <button
                  type="button"
                  onClick={() => setIsWalletDropdownOpen(!isWalletDropdownOpen)}
                  className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 py-1 hover:bg-zinc-200/80 rounded-md sm:rounded-lg transition cursor-pointer select-none"
                >
                  <span className="text-zinc-900 tabular-nums font-mono text-xs sm:text-sm font-bold tracking-tight">
                    {formatBalanceDisplay(balance, currency)}
                  </span>
                  <span className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center text-[8px] sm:text-[10px] font-bold ${activeBadge.bg} ${activeBadge.text} shrink-0 shadow-2xs`}>
                    {activeBadge.iconSymbol}
                  </span>
                  <ChevronDown className={`w-3 h-3 text-zinc-500 transition-transform duration-150 ${isWalletDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                <div className="w-[1px] h-4 sm:h-5 bg-zinc-300 mx-0.5 sm:mx-1" />
                <button
                  onClick={onRefreshBalance}
                  disabled={isRefreshingBalance}
                  title="Refresh Saldo"
                  className="p-1 sm:p-1.5 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-200/80 rounded-md sm:rounded-lg transition disabled:opacity-40"
                >
                  <RefreshCw className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isRefreshingBalance ? 'animate-spin text-emerald-600' : ''}`} />
                </button>
              </div>


              {isWalletDropdownOpen && (
                <div className="absolute right-[-10px] sm:right-0 mt-2 w-64 sm:w-80 bg-white border border-zinc-200 rounded-2xl shadow-2xl z-50 p-3.5 font-mono text-xs text-zinc-900 animate-in fade-in zoom-in-95 duration-100">
                  <div className="relative mb-3">
                    <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Cari Mata Uang..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-200 text-zinc-900 placeholder-zinc-400 text-xs rounded-xl pl-10 pr-4 py-2.5 outline-none focus:border-emerald-500 transition"
                      autoFocus
                    />
                  </div>

                  {hideZeroBalances && (
                    <div className="mb-2 flex items-center justify-between text-[10px] text-emerald-700 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200">
                      <span>✓ Filter Saldo &gt; 0 Aktif</span>
                      <span>{filteredCurrencies.length} Koin</span>
                    </div>
                  )}

                  <div className="max-h-64 sm:max-h-80 overflow-y-auto space-y-1.5 pr-1 scrollbar-thin scrollbar-thumb-zinc-300">
                    {filteredCurrencies.length === 0 ? (
                      <div className="py-8 px-4 text-center text-zinc-400 text-xs space-y-2.5">
                        <p>{hideZeroBalances ? 'Tidak ada koin yang memiliki saldo > 0.' : 'Tidak ada mata uang yang cocok.'}</p>
                        {hideZeroBalances && (
                          <button
                            type="button"
                            onClick={() => onToggleHideZeroBalances()}
                            className="px-3 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-[11px] font-bold transition cursor-pointer"
                          >
                            Tampilkan Semua Koin
                          </button>
                        )}
                      </div>
                    ) : (
                      filteredCurrencies.map((coin) => {
                        const codeLower = coin.code.toLowerCase();
                        const isSelected = codeLower === currency.toLowerCase();
                        const bal = userBalances[codeLower] ?? 0;
                        const badge = CURRENCY_BADGES[codeLower] || { bg: 'bg-zinc-700', text: 'text-white', iconSymbol: coin.symbol };
                        return (
                          <button
                            key={coin.code}
                            type="button"
                            onClick={() => {
                              onCurrencyChange(coin.code.toLowerCase());
                              setIsWalletDropdownOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-left transition cursor-pointer border ${isSelected ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold' : 'hover:bg-zinc-50 text-zinc-800 border-transparent hover:border-zinc-100'}`}
                          >
                            <span className="font-mono text-xs font-bold tabular-nums text-zinc-900">{formatBalanceDisplay(bal, coin.code)}</span>
                            <div className="flex items-center gap-2">
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${badge.bg} ${badge.text} shrink-0 shadow-xs`}>{badge.iconSymbol}</span>
                              <span className="font-bold text-xs uppercase text-zinc-900">{coin.code.toUpperCase()}</span>
                              {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 ml-0.5" />}
                            </div>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {isConnected && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleHideZeroBalances();
              }}
              title={hideZeroBalances ? 'Filter Saldo > 0 AKTIF' : 'Filter Saldo > 0 NONAKTIF'}
              className={`relative z-40 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] sm:text-xs font-mono font-bold transition cursor-pointer select-none active:scale-95 ${hideZeroBalances ? 'border-emerald-400 bg-emerald-50 text-emerald-800 shadow-sm' : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50 shadow-2xs'}`}
            >
              {hideZeroBalances ? <EyeOff className="w-4 h-4 text-emerald-600" /> : <Eye className="w-4 h-4 text-zinc-400" />}
              <span className="hidden lg:inline">{hideZeroBalances ? '> 0 Balance' : 'Semua Saldo'}</span>
            </button>
          )}

          {/* Seed Provably Fair Button (Icon Only) */}
          <button
            type="button"
            onClick={onOpenSeedModal}
            title="Pengaturan Seed & Provably Fair"
            className="p-1.5 sm:p-2 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 hover:text-emerald-700 transition cursor-pointer shrink-0 shadow-2xs flex items-center justify-center active:scale-95"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </button>



          <button
            onClick={onOpenSettings}
            title="Pengaturan Klien Stake"
            className="relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 hover:text-zinc-900 transition text-xs font-bold cursor-pointer shrink-0"
          >
            <Settings className="w-3.5 h-3.5 text-zinc-600" />
            <span className="hidden md:inline font-mono text-[11px]">Settings</span>
            {!isConnected && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 border-2 border-white" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

