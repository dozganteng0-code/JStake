import React from 'react';
import { Shield, Target, Square, CheckSquare } from 'lucide-react';

interface LiveTriggersProps {
  stopOnWin: boolean;
  onToggleStopOnWin: (val: boolean) => void;
  stopOnLoss: boolean;
  onToggleStopOnLoss: (val: boolean) => void;
  stopLoseStreak: number;
  onStopLoseStreakChange: (val: number) => void;
  currentStreak: { type: 'win' | 'loss' | 'none'; count: number };
  currency?: string;
  modeLabel?: string;
  isSwitchMode?: boolean;
}

export const LiveTriggers: React.FC<LiveTriggersProps> = ({
  stopOnWin,
  onToggleStopOnWin,
  stopOnLoss,
  onToggleStopOnLoss,
  stopLoseStreak,
  onStopLoseStreakChange,
  currentStreak,
  currency = 'BTC',
  modeLabel,
  isSwitchMode = false,
}) => {
  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex flex-col gap-3 font-mono text-zinc-900">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tight flex-wrap">
          <Shield className="w-4 h-4 text-amber-500" />
          <span>PEMICU BERHENTI CEPAT (LIVE TRIGGERS)</span>
          {modeLabel && (
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                isSwitchMode
                  ? 'bg-cyan-100 text-cyan-800 border border-cyan-300'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
              }`}
            >
              {modeLabel}
            </span>
          )}
        </div>
        <div className="bg-zinc-100 border border-zinc-200 px-2 py-0.5 rounded text-[10px] font-bold text-zinc-600">
          Streak: <span className={currentStreak.type === 'win' ? 'text-emerald-600' : currentStreak.type === 'loss' ? 'text-rose-600' : ''}>{currentStreak.count}</span>
        </div>
      </div>

      {/* Primary Toggles: Stop on Win, Stop on Loss, Stop Lose Streak */}
      <div className="border-t border-zinc-100 pt-3 flex flex-wrap items-center gap-2 sm:gap-3">
        {/* Stop on Win Toggle */}
        <button
          type="button"
          onClick={() => onToggleStopOnWin(!stopOnWin)}
          className={`flex items-center gap-2 px-3 py-1.5 sm:py-2 rounded-xl border transition-all cursor-pointer ${
            stopOnWin 
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-2xs ring-1 ring-emerald-200' 
              : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
          }`}
        >
          <div className={`shrink-0 ${stopOnWin ? 'text-emerald-600' : 'text-zinc-400'}`}>
            {stopOnWin ? <CheckSquare className="w-4 h-4 sm:w-5 sm:h-5 fill-emerald-100" /> : <Square className="w-4 h-4 sm:w-5 sm:h-5" />}
          </div>
          <div className="flex flex-col items-start leading-tight">
            <span className="text-[10px] sm:text-[11px] font-black uppercase">Stop on</span>
            <span className="text-[10px] sm:text-[11px] font-black uppercase text-emerald-600">Win (1×)</span>
          </div>
        </button>

        {/* Stop on Loss Toggle */}
        <button
          type="button"
          onClick={() => onToggleStopOnLoss(!stopOnLoss)}
          className={`flex items-center gap-2 px-3 py-1.5 sm:py-2 rounded-xl border transition-all cursor-pointer ${
            stopOnLoss 
              ? 'bg-rose-50 border-rose-300 text-rose-900 shadow-2xs ring-1 ring-rose-200' 
              : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
          }`}
        >
          <div className={`shrink-0 ${stopOnLoss ? 'text-rose-600' : 'text-zinc-400'}`}>
            {stopOnLoss ? <CheckSquare className="w-4 h-4 sm:w-5 sm:h-5 fill-rose-100" /> : <Square className="w-4 h-4 sm:w-5 sm:h-5" />}
          </div>
          <div className="flex flex-col items-start leading-tight">
            <span className="text-[10px] sm:text-[11px] font-black uppercase">Stop on</span>
            <span className="text-[10px] sm:text-[11px] font-black uppercase text-rose-600">Loss (1×)</span>
          </div>
        </button>

        {/* Stop Lose Streak Input */}
        <div className="flex-1 min-w-[200px] bg-zinc-50 border border-zinc-200 rounded-xl px-2.5 py-1.5 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 shrink-0">
            <Target className="w-3.5 h-3.5 text-cyan-600" />
            <span className="text-[10px] sm:text-[11px] font-bold text-zinc-700 whitespace-nowrap">Stop Lose Streak:</span>
          </div>
          
          <div className="flex items-center gap-1">
            <input
              type="number"
              min="0"
              placeholder="0 (Off)"
              value={stopLoseStreak > 0 ? stopLoseStreak : ''}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                onStopLoseStreakChange(isNaN(val) || val < 0 ? 0 : val);
              }}
              className="w-16 bg-white border border-zinc-200 rounded-lg px-2 py-1 text-xs font-bold text-center outline-none focus:border-cyan-500 transition-colors"
            />
            <span className="text-[10px] font-bold text-zinc-400">×</span>
          </div>
        </div>
      </div>

    </div>
  );
};
