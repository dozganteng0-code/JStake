import React from 'react';
import { Zap } from 'lucide-react';

interface BatchSpeedInputProps {
  value: number;
  onChange: (val: number) => void;
  disabled?: boolean;
}

export const BatchSpeedInput: React.FC<BatchSpeedInputProps> = ({
  value,
  onChange,
  disabled = false,
}) => {
  const PRESETS = [100, 200, 300, 500, 1000];

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs font-bold text-zinc-800">
        <span className="flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Kecepatan Batch</span>
        </span>
        <span className="text-[10px] text-zinc-500 font-mono">
          Min 100ms (Default 100ms)
        </span>
      </div>

      <div className="flex items-center gap-2">
        <input
          type="number"
          min="100"
          step="50"
          value={value}
          onChange={(e) => {
            const v = parseInt(e.target.value, 10);
            if (!isNaN(v) && v >= 100) {
              onChange(v);
              try {
                localStorage.setItem('stake_batch_delay_ms', String(v));
              } catch {}
            }
          }}
          disabled={disabled}
          className="w-24 bg-zinc-50 border border-zinc-200 rounded-xl px-2.5 py-1.5 font-mono text-xs font-bold text-zinc-900 outline-none focus:border-emerald-500 disabled:opacity-50"
        />
        <span className="text-zinc-500 text-xs font-mono">ms per putaran</span>
      </div>

      <div className="flex items-center gap-1 flex-wrap pt-1">
        {PRESETS.map((preset) => (
          <button
            key={preset}
            type="button"
            onClick={() => {
              onChange(preset);
              try {
                localStorage.setItem('stake_batch_delay_ms', String(preset));
              } catch {}
            }}
            disabled={disabled}
            className={`px-2 py-1 rounded-lg text-[10px] font-bold font-mono transition cursor-pointer border ${
              value === preset
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-700 border-zinc-200'
            } disabled:opacity-50`}
          >
            {preset}ms
          </button>
        ))}
      </div>
    </div>
  );
};
