import React, { useState } from 'react';
import { Key, Globe, Eye, EyeOff, Activity, ArrowRight, ShieldCheck, AlertTriangle } from 'lucide-react';
import { RoutingMode, StakeConfig } from '../types/stake';
import { executeGraphQL, DEFAULT_BALANCES_QUERY } from '../services/stakeApi';
import { OFFICIAL_STAKE_MIRRORS } from '../data/stakeMirrors';

interface TokenRequiredScreenProps {
  config: StakeConfig;
  onSaveToken: (token: string, endpoint: string, routingMode: RoutingMode) => void;
}

export const TokenRequiredScreen: React.FC<TokenRequiredScreenProps> = ({ config, onSaveToken }) => {
  const [tokenInput, setTokenInput] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [endpointInput, setEndpointInput] = useState(config.endpoint || 'https://stake.bet/_api/graphql');
  const [routingMode, setRoutingMode] = useState<RoutingMode>(config.routingMode || 'cors-proxy');
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim()) {
      setErrorMessage('Silakan tempel Stake Session Token Anda terlebih dahulu.');
      return;
    }

    setIsVerifying(true);
    setErrorMessage(null);

    const testConfig: StakeConfig = {
      ...config,
      token: tokenInput.trim(),
      endpoint: endpointInput.trim(),
      routingMode,
    };

    try {
      const res = await executeGraphQL<any>(DEFAULT_BALANCES_QUERY, {}, testConfig);
      if (res.errors && res.errors.length > 0) {
        setErrorMessage(res.errors[0]?.message || 'Stake menolak token ini. Periksa kembali.');
      } else if (res.data?.user) {
        onSaveToken(tokenInput.trim(), endpointInput.trim(), routingMode);
      } else {
        // Save anyway if response received
        onSaveToken(tokenInput.trim(), endpointInput.trim(), routingMode);
      }
    } catch (err: any) {
      setErrorMessage(
        err.message || 'Gagal memverifikasi token. Pastikan token dan endpoint sudah benar.'
      );
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="bg-white border border-zinc-200 rounded-2xl p-5 sm:p-7 shadow-sm flex flex-col gap-5 text-zinc-900">
      <div className="flex items-start gap-3.5">
        <div className="w-11 h-11 rounded-xl bg-zinc-900 text-white flex items-center justify-center shrink-0">
          <Key className="w-5 h-5 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-base sm:text-lg font-bold font-mono tracking-tight">
            Hubungkan Akun Stake Anda
          </h2>
          <p className="text-xs text-zinc-500 font-mono mt-0.5">
            Client ultra-ringan langsung ke GraphQL API Stake. Masukkan Stake Session Token Anda untuk mengambil saldo dan bermain.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4 font-mono text-xs">
        {/* Token Input */}
        <div>
          <label className="font-bold text-zinc-700 block mb-1">
            STAKE SESSION TOKEN (`x-access-token`) *
          </label>
          <div className="relative">
            <input
              type={showToken ? 'text' : 'password'}
              placeholder="Tempelkan token di sini (panjang sekitar 64-128 karakter)..."
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-2.5 font-mono text-xs text-zinc-900 pr-10 outline-none focus:border-zinc-900 transition"
              required
            />
            <button
              type="button"
              onClick={() => setShowToken(!showToken)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700 cursor-pointer"
            >
              {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Endpoint Input with playstake.io mirrors */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="font-bold text-zinc-700">
              MIRROR RESMI STAKE (playstake.io/#mirrors)
            </label>
            <a
              href="https://playstake.io/#mirrors"
              target="_blank"
              rel="noreferrer"
              className="text-[11px] text-zinc-500 hover:text-zinc-900 underline"
            >
              126 Mirror playstake.io ↗
            </a>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={endpointInput}
              onChange={(e) => setEndpointInput(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3.5 py-2 font-mono text-xs text-zinc-900 outline-none focus:border-zinc-900 transition"
            />
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {OFFICIAL_STAKE_MIRRORS.slice(0, 6).map((preset) => (
              <button
                key={preset.domain}
                type="button"
                onClick={() => setEndpointInput(preset.graphqlUrl)}
                className={`text-[10px] px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                  endpointInput === preset.graphqlUrl
                    ? 'bg-zinc-900 border-zinc-900 text-white font-bold'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100'
                }`}
              >
                {preset.domain}
              </button>
            ))}
          </div>
        </div>

        {/* Mode Routing */}
        <div>
          <label className="font-bold text-zinc-700 block mb-1">MODE KONEKSI</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setRoutingMode('cors-proxy')}
              className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                routingMode === 'cors-proxy'
                  ? 'border-emerald-600 bg-emerald-50/60 shadow-xs'
                  : 'border-zinc-200 bg-zinc-50 text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              <div className="font-bold text-xs text-zinc-900 flex items-center justify-between">
                <span>CORS Proxy</span>
                <span className="text-[9px] bg-emerald-600 text-white px-1 py-0.2 rounded font-bold">Anti 403</span>
              </div>
              <div className="text-[10px] text-zinc-500 mt-0.5">Bypass Cloudflare &amp; CORS</div>
            </button>

            <button
              type="button"
              onClick={() => setRoutingMode('direct')}
              className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                routingMode === 'direct'
                  ? 'border-zinc-900 bg-zinc-900 text-white'
                  : 'border-zinc-200 bg-zinc-50 text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              <div className="font-bold text-xs">Direct Fetch</div>
              <div className="text-[10px] opacity-80 mt-0.5">Dari browser / IP asli Anda</div>
            </button>

            <button
              type="button"
              onClick={() => setRoutingMode('proxy')}
              className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                routingMode === 'proxy'
                  ? 'border-zinc-900 bg-zinc-900 text-white'
                  : 'border-zinc-200 bg-zinc-50 text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              <div className="font-bold text-xs">Server Proxy</div>
              <div className="text-[10px] opacity-80 mt-0.5">Relay server lokal</div>
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-mono space-y-2">
            <div className="font-bold flex items-start gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
            {errorMessage.includes('403') && (
              <div className="pt-2 border-t border-rose-200/80 space-y-1.5">
                <span className="text-[11px] text-zinc-700 block font-semibold">
                  Solusi 1-Klik untuk Mengatasi HTTP 403:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setRoutingMode('direct');
                      setErrorMessage(null);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                  >
                    1. Ganti ke Direct Fetch (IP Asli Anda)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEndpointInput('https://stake.bet/_api/graphql');
                      setErrorMessage(null);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white border border-rose-300 hover:bg-rose-100 text-[11px] text-rose-900 font-semibold cursor-pointer"
                  >
                    2. Coba mirror stake.bet
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEndpointInput('https://stake.ac/_api/graphql');
                      setErrorMessage(null);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white border border-rose-300 hover:bg-rose-100 text-[11px] text-rose-900 font-semibold cursor-pointer"
                  >
                    3. Coba mirror stake.ac
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        <button
          type="submit"
          disabled={isVerifying || !tokenInput.trim()}
          className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-sm shadow-sm flex items-center justify-center gap-2 transition active:scale-[0.99] disabled:opacity-50 cursor-pointer"
        >
          {isVerifying ? (
            <>
              <Activity className="w-4 h-4 animate-spin" />
              <span>Memverifikasi Token ke Stake...</span>
            </>
          ) : (
            <>
              <span>Hubungkan & Mulai Bermain</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Quick Guide */}
      <div className="p-4 rounded-xl bg-zinc-50 border border-zinc-200 text-xs font-mono text-zinc-600 space-y-2">
        <div className="font-bold text-zinc-900 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Cara Mendapatkan Stake Session Token (1 Menit):</span>
        </div>
        <ol className="list-decimal list-inside space-y-1 text-[11px] text-zinc-600">
          <li>Buka situs Stake Anda di browser dan pastikan sudah login.</li>
          <li>Tekan <strong>F12</strong> (Developer Tools), buka tab <strong>Network</strong>.</li>
          <li>Ketik <code className="bg-zinc-200 px-1 rounded">graphql</code> pada kotak filter pencarian.</li>
          <li>Lakukan 1 klik di Stake (misal ganti game atau klik refresh balance).</li>
          <li>Klik salah satu request <em>graphql</em> &gt; tab <strong>Headers</strong> &gt; cari <strong>x-access-token</strong>.</li>
          <li>Salin nilai token tersebut dan tempelkan ke kolom di atas.</li>
        </ol>
        <p className="text-[10px] text-zinc-400 mt-2">
          Keamanan: Token Anda disimpan hanya di memori lokal (localStorage) browser Anda sendiri.
        </p>
      </div>
    </div>
  );
};
