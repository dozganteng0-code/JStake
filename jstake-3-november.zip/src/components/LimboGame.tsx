import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Play,
  Square,
  Rocket,
  KeyRound,
  ShieldCheck,
  Zap,
  Settings,
  BarChart2,
} from 'lucide-react';
import { AutobetConfig, BatchProgress, LimboSavedStrategy, SavedStrategy, StrategySwitchRule } from '../types/stake';
import { SeedModal } from './SeedModal';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import { GameFooterToolbar } from './GameFooterToolbar';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface LimboGameProps {
  balance: number;
  currency: string;
  isRolling: boolean;
  onBet: (amount: number, targetMultiplier: number) => Promise<boolean>;
  houseEdgePercent: number;
  autobetRunning: boolean;
  onToggleAutobet: (config: AutobetConfig, targetMultiplier: number) => void;
  onStopAutobet: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  batchProgress?: BatchProgress | null;
  currentStreak?: { type: 'win' | 'loss' | 'none'; count: number };
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin: boolean;
  stopOnLoss: boolean;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

export const LimboGame: React.FC<LimboGameProps> = ({
  balance,
  currency,
  isRolling,
  onBet,
  houseEdgePercent = 1.0,
  autobetRunning,
  onToggleAutobet,
  onStopAutobet,
  onShowToast,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin,
  stopOnLoss,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: externalSwitchRulesEnabled = false,
}) => {
  // Mode: Manual vs Otomatis
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies State - starts empty per user request
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() =>
    loadSavedStrategies('limbo')
  );

  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('limbo');
    const activeId = getActiveStrategyId('limbo');
    if (activeId) {
      const found = list.find((s) => s.id === activeId);
      if (found) return found;
    }
    return list.length > 0 ? list[0] : null;
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const handleImportStrategies = (imported: SavedStrategy[]) => {
    setStrategies((prev) => {
      const existingIds = new Set(prev.map((s) => s.id));
      const newItems = imported.filter((s) => !existingIds.has(s.id));
      const updated = [...newItems, ...prev];
      saveSavedStrategies('limbo', updated);
      if (imported[0]) {
        handleSelectStrategy(imported[0]);
      }
      return updated;
    });
  };

  // Bet amount & target multiplier
  const [betAmount, setBetAmount] = useState<string>(() => {
    const saved = localStorage.getItem('limbo_bet_amount');
    return activeStrategy?.betAmount || (saved === '0.00000001' ? '0' : saved) || '0';
  });
  const [targetMultiplier, setTargetMultiplier] = useState<number>(() => {
    const saved = localStorage.getItem('limbo_target_multiplier');
    return (activeStrategy as LimboSavedStrategy)?.targetMultiplier || (saved ? Number(saved) : 2.0);
  });
  const [multiplierInput, setMultiplierInput] = useState<string>(() => {
    const mult = (activeStrategy as LimboSavedStrategy)?.targetMultiplier;
    const saved = localStorage.getItem('limbo_multiplier_input');
    return mult ? mult.toFixed(2) : (saved || '2.00');
  });

  // Auto Bet Parameters
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('limbo_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('limbo_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('limbo_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('limbo_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('limbo_on_loss_percent') || '0');
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('limbo_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('limbo_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('limbo_max_bet_cap') || '0');
  const [localStopLoseStreak, setLocalStopLoseStreak] = useState<string>(() => activeStrategy?.stopLoseStreak || (stopLoseStreak > 0 ? String(stopLoseStreak) : localStorage.getItem('limbo_stop_lose_streak') || '0'));
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('limbo_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => localStorage.getItem('limbo_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => localStorage.getItem('limbo_stop_balance_min') || '0');
  const [batchDelayMs, setBatchDelayMs] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('stake_batch_delay_ms'));
      return saved ? Math.max(100, saved) : 100;
    } catch {
      return 100;
    }
  });

  // Dynamic Strategy Switch Rules
  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('limbo'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('limbo'));

  const handleUpdateSwitchRules = (newRules: StrategySwitchRule[]) => {
    setSwitchRules(newRules);
    saveSwitchRules('limbo', newRules);
  };

  const handleToggleSwitchRulesEnabled = (val: boolean) => {
    setSwitchRulesEnabledState(val);
    setSwitchRulesEnabled('limbo', val);
  };

  // Strategy switching handler
  const handleSelectStrategy = (strat: SavedStrategy) => {
    const limboStrat = strat as LimboSavedStrategy;
    activeStrategyRef.current = strat;
    setActiveStrategy(strat);
    setActiveStrategyId('limbo', strat.id);

    setBetAmount(strat.betAmount !== undefined ? strat.betAmount : '0');
    if (typeof limboStrat.targetMultiplier === 'number') {
      setTargetMultiplier(limboStrat.targetMultiplier);
      setMultiplierInput(limboStrat.targetMultiplier.toFixed(2));
    }
    setNumberOfBets(strat.numberOfBets !== undefined ? strat.numberOfBets : '0');
    setOnWinAction(strat.onWinAction || 'reset');
    setOnWinPercent(strat.onWinPercent !== undefined ? strat.onWinPercent : '0');
    setOnLossAction(strat.onLossAction || 'reset');
    setOnLossPercent(strat.onLossPercent !== undefined ? strat.onLossPercent : '0');
    setStopProfit(strat.stopProfit !== undefined ? strat.stopProfit : '0');
    stopProfitRef.current = parseFloat(strat.stopProfit || '0') || 0;
    setStopLoss(strat.stopLoss !== undefined ? strat.stopLoss : '0');
    stopLossRef.current = parseFloat(strat.stopLoss || '0') || 0;
    setMaxBetCap(strat.maxBetCap !== undefined ? strat.maxBetCap : '0');
    maxBetCapRef.current = parseFloat(strat.maxBetCap || '0') || 0;
    setLocalStopLoseStreak(strat.stopLoseStreak !== undefined ? strat.stopLoseStreak : '0');
    stopLoseStreakRef.current = parseInt(strat.stopLoseStreak || '0', 10) || 0;
    setTrailingStop(strat.trailingStop !== undefined ? strat.trailingStop : '0');
    trailingStopRef.current = parseFloat(strat.trailingStop || '0') || 0;
    setStopWager(strat.stopWager !== undefined ? strat.stopWager : '0');
    stopWagerRef.current = parseFloat(strat.stopWager || '0') || 0;
    setStopBalanceMin(strat.stopBalanceMin !== undefined ? strat.stopBalanceMin : '0');
    stopBalanceMinRef.current = parseFloat(strat.stopBalanceMin || '0') || 0;

    // Apply stop limits and triggers unconditionally so Strategy 2 resets Strategy 1's values
    onUpdateTriggers?.({
      stopOnWin: !!strat.stopOnWin,
      stopOnLoss: !!strat.stopOnLoss,
      stopLoseStreak: parseInt(strat.stopLoseStreak || '0', 10) || 0,
      stopWinStreak: parseInt(strat.stopWinStreak || '0', 10) || 0,
    });

    onShowToast?.('Strategi Dipilih', 'ON', `Mengaktifkan strategi "${strat.name}"`);
  };

  const handleSaveStrategy = (strat: SavedStrategy) => {
    setStrategies((prev) => {
      const idx = prev.findIndex((s) => s.id === strat.id);
      let updated: SavedStrategy[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = strat;
      } else {
        updated = [strat, ...prev];
      }
      saveSavedStrategies('limbo', updated);
      return updated;
    });
    handleSelectStrategy(strat);
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveSavedStrategies('limbo', updated);
      if (activeStrategy?.id === id) {
        const next = updated.length > 0 ? updated[0] : null;
        setActiveStrategy(next);
        if (next) {
          setActiveStrategyId('limbo', next.id);
        } else {
          localStorage.removeItem('stake_active_strategy_limbo');
        }
      }
      return updated;
    });
  };

  // Refs for real-time evaluation
  const stopProfitRef = useRef<number>(parseFloat(stopProfit) || 0);
  const stopLossRef = useRef<number>(parseFloat(stopLoss) || 0);
  const maxBetCapRef = useRef<number>(parseFloat(maxBetCap) || 0);
  const trailingStopRef = useRef<number>(parseFloat(trailingStop) || 0);
  const stopWagerRef = useRef<number>(parseFloat(stopWager) || 0);
  const stopBalanceMinRef = useRef<number>(parseFloat(stopBalanceMin) || 0);
  const stopOnWinRef = useRef<boolean>(stopOnWin);
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);
  const stopWinStreakRef = useRef<number>(stopWinStreak);

  useEffect(() => { stopOnWinRef.current = stopOnWin; }, [stopOnWin]);
  useEffect(() => { stopOnLossRef.current = stopOnLoss; }, [stopOnLoss]);
  useEffect(() => {
    if (stopLoseStreak > 0) {
      stopLoseStreakRef.current = stopLoseStreak;
      setLocalStopLoseStreak(String(stopLoseStreak));
    }
  }, [stopLoseStreak]);
  useEffect(() => { stopWinStreakRef.current = stopWinStreak; }, [stopWinStreak]);

  const handleStopProfitChange = (val: string) => {
    setStopProfit(val);
    stopProfitRef.current = parseFloat(val) || 0;
  };

  const handleStopLossChange = (val: string) => {
    setStopLoss(val);
    stopLossRef.current = parseFloat(val) || 0;
  };

  const handleMaxBetCapChange = (val: string) => {
    setMaxBetCap(val);
    maxBetCapRef.current = parseFloat(val) || 0;
  };

  const handleLocalStopLoseStreakChange = (val: string) => {
    setLocalStopLoseStreak(val);
    stopLoseStreakRef.current = parseInt(val, 10) || 0;
  };

  const handleTrailingStopChange = (val: string) => {
    setTrailingStop(val);
    trailingStopRef.current = parseFloat(val) || 0;
  };

  const handleStopWagerChange = (val: string) => {
    setStopWager(val);
    stopWagerRef.current = parseFloat(val) || 0;
  };

  const handleStopBalanceMinChange = (val: string) => {
    setStopBalanceMin(val);
    stopBalanceMinRef.current = parseFloat(val) || 0;
  };

  useEffect(() => {
    try {
      localStorage.setItem('limbo_bet_amount', betAmount);
      localStorage.setItem('limbo_target_multiplier', targetMultiplier.toString());
      localStorage.setItem('limbo_multiplier_input', multiplierInput);
      localStorage.setItem('limbo_num_bets', numberOfBets);
      localStorage.setItem('limbo_on_win_action', onWinAction);
      localStorage.setItem('limbo_on_win_percent', onWinPercent);
      localStorage.setItem('limbo_on_loss_action', onLossAction);
      localStorage.setItem('limbo_on_loss_percent', onLossPercent);
      localStorage.setItem('limbo_stop_profit', stopProfit);
      localStorage.setItem('limbo_stop_loss', stopLoss);
      localStorage.setItem('limbo_max_bet_cap', maxBetCap);
      localStorage.setItem('limbo_stop_lose_streak', localStopLoseStreak);
      localStorage.setItem('limbo_trailing_stop', trailingStop);
      localStorage.setItem('limbo_stop_wager', stopWager);
      localStorage.setItem('limbo_stop_balance_min', stopBalanceMin);
      localStorage.setItem('stake_batch_delay_ms', String(batchDelayMs));
    } catch {}
  }, [betAmount, targetMultiplier, multiplierInput, numberOfBets, onWinAction, onWinPercent, onLossAction, onLossPercent, stopProfit, stopLoss, maxBetCap, localStopLoseStreak, trailingStop, stopWager, stopBalanceMin, batchDelayMs]);

  // Provably Fair Seed state & Popover
  const [clientSeed, setClientSeed] = useState<string>(() => {
    try {
      return localStorage.getItem('stake_client_seed') || 'jstkbot_client_seed_x9a82';
    } catch {
      return 'jstkbot_client_seed_x9a82';
    }
  });
  const [serverSeedHash] = useState<string>('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  const [nonce, setNonce] = useState<number>(1);
  const [isSeedModalOpen, setIsSeedModalOpen] = useState<boolean>(false);

  const handleSaveSeed = (newSeed: string) => {
    setClientSeed(newSeed);
    try {
      localStorage.setItem('stake_client_seed', newSeed);
    } catch {}
    onShowToast?.('Seed Diperbarui', 'ON', `Client Seed berhasil diganti ke "${newSeed}"`);
  };

  const edgeFactor = (100 - houseEdgePercent) / 100;

  const winChanceDisplay = useMemo(() => {
    if (targetMultiplier <= 1.0) return '99.00%';
    const chance = (edgeFactor * 100) / targetMultiplier;
    if (chance <= 0) return '0%';
    if (chance >= 99) return '99.00%';
    if (chance >= 1) return `${chance.toFixed(2)}%`;
    if (chance >= 0.01) return `${chance.toFixed(4)}%`;
    if (chance >= 0.0001) return `${chance.toFixed(6)}%`;
    return `${chance.toFixed(8)}%`;
  }, [edgeFactor, targetMultiplier]);

  const numericInput = useMemo(() => {
    const trimmed = betAmount.trim();
    if (!trimmed) return 0;
    const isIdr = currency.toLowerCase() === 'idr';
    let clean = trimmed.replace(/\s/g, '');
    if (isIdr) {
      if (/^\d{1,3}(\.\d{3})+$/.test(clean)) {
        clean = clean.replace(/\./g, '');
      } else {
        clean = clean.replace(',', '.');
      }
    } else {
      clean = clean.replace(',', '.');
    }
    const val = parseFloat(clean);
    return isNaN(val) || val < 0 ? 0 : val;
  }, [betAmount, currency]);

  const profitCrypto = useMemo(() => {
    if (numericInput <= 0) return 0;
    return numericInput * (targetMultiplier - 1);
  }, [numericInput, targetMultiplier]);

  const commitMultiplierChange = (rawStr: string) => {
    const trimmed = rawStr.trim().replace(',', '.');
    if (!trimmed) {
      setMultiplierInput(targetMultiplier.toFixed(2));
      return;
    }
    const parsed = parseFloat(trimmed);
    if (isNaN(parsed)) {
      setMultiplierInput(targetMultiplier.toFixed(2));
      return;
    }
    const MIN_MULT = 1.01;
    const MAX_MULT = 1000000.0;
    const clamped = Math.max(MIN_MULT, Math.min(MAX_MULT, parsed));
    setTargetMultiplier(Number(clamped.toFixed(2)));
    setMultiplierInput(clamped.toString());
  };

  const handleMin = () => setBetAmount('0');
  const handleHalf = () => {
    if (numericInput <= 0) {
      setBetAmount('0');
      return;
    }
    setBetAmount(Math.max(0, Number((numericInput / 2).toFixed(8))).toString());
  };
  const handleDouble = () => {
    if (numericInput <= 0) {
      setBetAmount(currency.toLowerCase() === 'idr' ? '1000' : '0.00000001');
      return;
    }
    setBetAmount(Number((numericInput * 2).toFixed(8)).toString());
  };

  const handleSingleBet = async () => {
    if (isRolling || autobetRunning) return;
    const success = await onBet(numericInput, targetMultiplier);
    if (success !== undefined) {
      setNonce((prev) => prev + 1);
    }
  };

  const handleStartAutoBet = () => {
    const currentStrat = (activeStrategy || strategies.find(s => s.id === getActiveStrategyId('limbo')) || strategies[0]) as LimboSavedStrategy | undefined;

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : numericInput;
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(String(currentStrat.onWinEveryCount), 10) || 1
      : 1;
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(String(currentStrat.onLossEveryCount), 10) || 1
      : 1;
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const autoTargetMultiplier = (typeof currentStrat?.targetMultiplier === 'number')
      ? currentStrat.targetMultiplier
      : targetMultiplier;

    const autoConfig: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      stopLoseStreak: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || stopLoseStreakRef.current || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      batchDelayMs,
      onBetAmountChange: (amt) => setBetAmount(amt.toString()),
      switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onSwitchStrategy: (targetStrat) => {
        handleSelectStrategy(targetStrat);
      },
      getLiveTriggers: () => ({
        stopOnWin: stopOnWinRef.current,
        stopOnLoss: stopOnLossRef.current,
        stopLoseStreak: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        maxConsecutiveLosses: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        stopWinStreak: stopWinStreakRef.current,
        stopProfit: stopProfitRef.current,
        stopLoss: stopLossRef.current,
        maxBetCap: maxBetCapRef.current,
        trailingStop: trailingStopRef.current,
        stopWager: stopWagerRef.current,
        stopBalanceMin: stopBalanceMinRef.current,
        switchRules,
        switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(autoConfig, autoTargetMultiplier);
  };

  return (
    <div className="flex flex-col gap-3 font-sans">
      {/* Top Game Header Bar */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3 font-sans">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-600 text-white flex items-center justify-center shadow-xs shrink-0">
            <Rocket className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900 tracking-tight">
                LIMBO
              </h2>
              <span className="text-[9px] bg-cyan-100 text-cyan-800 border border-cyan-200 font-mono font-bold px-1.5 py-0.2 rounded">
                STAKE ORIGINAL
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-zinc-500 font-mono">
              Kejar multiplier tanpa batas • Max Win 1,000,000.00× • House Edge {houseEdgePercent}%
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3 font-mono text-zinc-900">
        {/* 1. TOP TAB PILL CONTAINER (MANUAL vs OTOMATIS) */}
        <div className="bg-zinc-200/80 p-1 rounded-full grid grid-cols-2 gap-1 w-full max-w-sm mx-auto">
        <button
          type="button"
          onClick={() => {
            if (autobetRunning) return;
            setTabMode('manual');
          }}
          disabled={autobetRunning}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'manual'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Manual</span>
        </button>

        <button
          type="button"
          onClick={() => setTabMode('auto')}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'auto'
              ? 'bg-white text-zinc-900 shadow-sm'
              : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Otomatis</span>
          {autobetRunning && <span className="w-2 h-2 rounded-full bg-cyan-500 animate-ping" />}
        </button>
      </div>

      {/* AUTO BET STATUS */}
      {autobetRunning && batchProgress && (
        <div className="bg-cyan-600 text-white rounded-xl p-3 flex items-center justify-between text-xs shadow-md">
          <div className="space-y-0.5">
            <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>Auto Bet Limbo: Putaran {batchProgress.currentRound} / {batchProgress.totalRounds || '∞'}</span>
              {batchProgress.activeStrategyName && (
                <span className="bg-cyan-700/80 px-1.5 py-0.5 rounded text-[10px] font-black border border-cyan-400/40">
                  {batchProgress.activeStrategyName}
                </span>
              )}
            </span>
            <span className="text-[10px] text-cyan-100 flex items-center gap-2 flex-wrap">
              <span>Profit: <strong>{batchProgress.runningProfit >= 0 ? `+${batchProgress.runningProfit}` : batchProgress.runningProfit} {currency.toUpperCase()}</strong></span>
              {batchProgress.peakProfit !== undefined && batchProgress.peakProfit > 0 && (
                <span>• Puncak: <strong className="text-white">+{batchProgress.peakProfit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 6)}</strong></span>
              )}
              {batchProgress.totalWagered !== undefined && (
                <span>• Wager: <strong>{batchProgress.totalWagered} {currency.toUpperCase()}</strong></span>
              )}
            </span>
          </div>
          <button
            type="button"
            onClick={onStopAutobet}
            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer transition flex items-center gap-1"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Berhenti</span>
          </button>
        </div>
      )}

      {/* MANUAL BET CONTROLS */}
      {tabMode === 'manual' && (
        <>
          <div className="flex flex-col gap-2.5 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
            <div className="flex items-center justify-between text-xs font-bold text-zinc-700">
              <span className="text-zinc-900 uppercase">Jumlah Taruhan</span>
              <span className="text-[10px] text-zinc-500 font-normal">
                Saldo: <strong className="text-zinc-900">{balance.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="0"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={autobetRunning}
                  className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 font-mono text-xs sm:text-sm font-bold text-zinc-900 outline-none focus:border-cyan-500 transition disabled:opacity-75"
                />
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={handleMin}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  0
                </button>
                <button
                  onClick={handleHalf}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  ½
                </button>
                <button
                  onClick={handleDouble}
                  disabled={autobetRunning}
                  className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold transition cursor-pointer disabled:opacity-40"
                >
                  2×
                </button>
              </div>
            </div>

            {/* Target Multiplier & Win Chance Grid */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-200">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold uppercase block mb-0.5">Target Multiplier</span>
                <div className="flex items-center gap-0.5 bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 focus-within:border-cyan-500 transition">
                  <input
                    type="text"
                    value={multiplierInput}
                    onChange={(e) => setMultiplierInput(e.target.value)}
                    onBlur={() => commitMultiplierChange(multiplierInput)}
                    disabled={autobetRunning}
                    className="w-full bg-transparent font-bold text-xs text-zinc-900 outline-none"
                  />
                  <span className="font-bold text-zinc-400 select-none text-xs">×</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-zinc-500 font-bold uppercase block mb-0.5">Win Chance</span>
                <div className="bg-white border border-zinc-200 rounded-xl px-2.5 py-1.5 flex items-center font-bold text-xs text-cyan-600 font-mono">
                  {winChanceDisplay}
                </div>
              </div>
            </div>
          </div>

          {/* ESTIMASI PROFIT BANNER */}
          <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-2.5 flex items-center justify-between text-xs">
            <span className="text-cyan-900 font-bold">ESTIMASI PROFIT JIKA MENANG:</span>
            <span className="font-bold text-cyan-700 text-sm">
              +{profitCrypto.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}
            </span>
          </div>
        </>
      )}

      {/* OTOMATIS MODE: TAMPIL HANYA LIST DAFTAR STRATEGI */}
      {tabMode === 'auto' && (
        <div className="space-y-3">
          <AutoBetStrategyManager
            game="limbo"
            currency={currency}
            strategies={strategies}
            activeStrategy={activeStrategy}
            onSelectStrategy={handleSelectStrategy}
            onSaveStrategy={handleSaveStrategy}
            onDeleteStrategy={handleDeleteStrategy}
            onImportStrategies={handleImportStrategies}
            autobetRunning={autobetRunning}
            onShowToast={onShowToast}
            stopProfit={stopProfit}
            onChangeStopProfit={handleStopProfitChange}
            stopLoss={stopLoss}
            onChangeStopLoss={handleStopLossChange}
            maxBetCap={maxBetCap}
            onChangeMaxBetCap={handleMaxBetCapChange}
            maxConsecutiveLosses={localStopLoseStreak}
            onChangeMaxConsecutiveLosses={handleLocalStopLoseStreakChange}
            trailingStop={trailingStop}
            onChangeTrailingStop={handleTrailingStopChange}
            stopWager={stopWager}
            onChangeStopWager={handleStopWagerChange}
            stopBalanceMin={stopBalanceMin}
            onChangeStopBalanceMin={handleStopBalanceMinChange}
            stopOnWin={stopOnWin}
            onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
            stopOnLoss={stopOnLoss}
            onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
            stopWinStreak={String(stopWinStreak)}
            onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
            switchRules={switchRules}
            onChangeSwitchRules={handleUpdateSwitchRules}
            switchRulesEnabled={externalSwitchRulesEnabled || switchRulesEnabled}
            onToggleSwitchRulesEnabled={handleToggleSwitchRulesEnabled}
            renderStrategyForm={(temp, setTemp) => {
              const limboStrat = temp as LimboSavedStrategy;
              const mult = limboStrat.targetMultiplier || 1.01;
              const chanceVal = (edgeFactor * 100) / mult;
              let stratWinChanceStr = '99.00%';
              if (mult > 1.0) {
                if (chanceVal <= 0) stratWinChanceStr = '0%';
                else if (chanceVal >= 99) stratWinChanceStr = '99.00%';
                else if (chanceVal >= 1) stratWinChanceStr = `${chanceVal.toFixed(2)}%`;
                else if (chanceVal >= 0.01) stratWinChanceStr = `${chanceVal.toFixed(4)}%`;
                else if (chanceVal >= 0.0001) stratWinChanceStr = `${chanceVal.toFixed(6)}%`;
                else stratWinChanceStr = `${chanceVal.toFixed(8)}%`;
              }

              return (
                <div className="space-y-3">
                  {/* 1. Base Bet Amount (Jumlah Taruhan) Pertama */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                      Jumlah Taruhan Dasar (Base Amount)
                    </label>
                    <input
                      type="text"
                      value={limboStrat.betAmount}
                      onChange={(e) => setTemp({ ...limboStrat, betAmount: e.target.value })}
                      placeholder="0.00000000"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* 2. Target Multiplier Limbo Kedua */}
                  <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-zinc-800">Target Multiplier Limbo:</span>
                      <span className="text-zinc-500 font-normal">Peluang: <strong className="text-cyan-700 font-mono">{stratWinChanceStr}</strong></span>
                    </div>

                    <div className="flex items-center bg-white border border-zinc-200 rounded-xl px-3 py-2 focus-within:border-cyan-500 transition">
                      <input
                        type="number"
                        step="0.01"
                        min="1.01"
                        max="1000000"
                        value={limboStrat.targetMultiplier ?? ''}
                        onChange={(e) => {
                          const raw = e.target.value;
                          if (raw === '') {
                            setTemp({ ...limboStrat, targetMultiplier: '' as any });
                          } else {
                            const val = parseFloat(raw);
                            setTemp({ ...limboStrat, targetMultiplier: isNaN(val) ? ('' as any) : val });
                          }
                        }}
                        onBlur={() => {
                          if (!limboStrat.targetMultiplier || Number(limboStrat.targetMultiplier) < 1.01) {
                            setTemp({ ...limboStrat, targetMultiplier: 1.01 });
                          }
                        }}
                        className="w-full bg-transparent font-bold text-xs sm:text-sm text-zinc-900 outline-none font-mono"
                        placeholder="2.00"
                      />
                      <span className="text-cyan-600 font-bold text-sm select-none">×</span>
                    </div>
                  </div>

                  {/* 3. Number of bets */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                      Jumlah Putaran (0 = Tanpa Batas)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={limboStrat.numberOfBets}
                      onChange={(e) => setTemp({ ...limboStrat, numberOfBets: e.target.value })}
                      placeholder="0"
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* Strategy Controls */}
                  <AutoBetStrategyControls
                    onWinAction={limboStrat.onWinAction}
                    onChangeOnWinAction={(val) => setTemp({ ...limboStrat, onWinAction: val })}
                    onWinPercent={limboStrat.onWinPercent}
                    onChangeOnWinPercent={(val) => setTemp({ ...limboStrat, onWinPercent: val })}
                    onWinEveryCount={limboStrat.onWinEveryCount}
                    onChangeOnWinEveryCount={(val) => setTemp({ ...limboStrat, onWinEveryCount: val })}
                    onLossAction={limboStrat.onLossAction}
                    onChangeOnLossAction={(val) => setTemp({ ...limboStrat, onLossAction: val })}
                    onLossPercent={limboStrat.onLossPercent}
                    onChangeOnLossPercent={(val: string) => setTemp({ ...limboStrat, onLossPercent: val })}
                    onLossEveryCount={limboStrat.onLossEveryCount}
                    onChangeOnLossEveryCount={(val) => setTemp({ ...limboStrat, onLossEveryCount: val })}
                    currency={currency}
                    disabled={false}
                  />
                </div>
              );
            }}
          />
        </div>
      )}

      {/* MAIN ACTION BUTTON */}
      <div className="flex flex-col gap-2 pt-1">
        {tabMode === 'manual' ? (
          <button
            type="button"
            onClick={handleSingleBet}
            disabled={isRolling}
            className="w-full py-3.5 rounded-2xl font-mono font-bold text-sm bg-cyan-600 hover:bg-cyan-700 text-white shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
          >
            <Rocket className={`w-4 h-4 ${isRolling ? 'animate-bounce' : ''}`} />
            <span>PLAY LIMBO</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (autobetRunning) {
                onStopAutobet();
                return;
              }
              if (isRolling) return; // Wait for last bet
              if (!activeStrategy || strategies.length === 0) {
                onShowToast?.('Strategi Diperlukan', 'OFF', 'Anda wajib menambahkan strategi terlebih dahulu.');
                return;
              }
              handleStartAutoBet();
            }}
            disabled={(!autobetRunning && isRolling) || (!autobetRunning && (!activeStrategy || strategies.length === 0))}
            className={`w-full py-3.5 rounded-2xl font-mono font-bold text-sm shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              autobetRunning || (isRolling && !autobetRunning)
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-cyan-600 hover:bg-cyan-700 text-white'
            }`}
          >
            {autobetRunning ? (
              <>
                <Square className="w-4 h-4 fill-current" />
                <span>HENTIKAN OTOMATIS</span>
              </>
            ) : isRolling ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>MENGHENTIKAN...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 fill-current text-amber-300" />
                <span>
                  {!activeStrategy || strategies.length === 0 
                    ? 'TAMBAH STRATEGI DAHULU' 
                    : `MULAI AUTO BET (${activeStrategy.name})`
                  }
                </span>
              </>
            )}
          </button>
        )}
      </div>

      {/* 2. UNIFIED STAKE-STYLE CONTROLS TOOLBAR */}
      <GameFooterToolbar
        batchDelayMs={batchDelayMs}
        onBatchDelayChange={setBatchDelayMs}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="cyan"
      />
    </div>
  </div>
);
};
