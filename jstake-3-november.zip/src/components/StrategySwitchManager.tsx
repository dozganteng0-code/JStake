import React, { useState } from 'react';
import {
  ArrowRightLeft,
  Plus,
  Trash2,
  Pencil,
  Check,
  X,
  TrendingUp,
  TrendingDown,
  Flame,
  Snowflake,
  RotateCw,
  Coins,
  AlertCircle,
  HelpCircle,
  Sparkles,
} from 'lucide-react';
import {
  GameType,
  SavedStrategy,
  StrategySwitchConditionType,
  StrategySwitchRule,
} from '../types/stake';

interface StrategySwitchManagerProps {
  game: GameType;
  currency: string;
  strategies: SavedStrategy[];
  activeStrategyId?: string;
  switchRules: StrategySwitchRule[];
  onChangeSwitchRules: (rules: StrategySwitchRule[]) => void;
  switchRulesEnabled: boolean;
  onToggleSwitchRulesEnabled: (val: boolean) => void;
  disabled?: boolean;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
}

const BADGE_MAP: Record<string, { bg: string; text: string; symbol: string }> = {
  btc: { bg: 'bg-[#f7931a]', text: 'text-white', symbol: 'BTC' },
  eth: { bg: 'bg-[#627eea]', text: 'text-white', symbol: 'ETH' },
  ltc: { bg: 'bg-[#345d9d]', text: 'text-white', symbol: 'LTC' },
  usdt: { bg: 'bg-[#26a17b]', text: 'text-white', symbol: 'USDT' },
  doge: { bg: 'bg-[#c2a633]', text: 'text-white', symbol: 'DOGE' },
  trx: { bg: 'bg-[#eb0029]', text: 'text-white', symbol: 'TRX' },
  idr: { bg: 'bg-emerald-600', text: 'text-white', symbol: 'IDR' },
};

const CONDITION_INFO: Record<
  StrategySwitchConditionType,
  { label: string; icon: React.FC<{ className?: string }>; unit: 'currency' | 'count'; description: string }
> = {
  profit_gte: {
    label: 'Jika Profit Lebih Dari (≥)',
    icon: TrendingUp,
    unit: 'currency',
    description: 'Pindah strategi saat profit di strategi saat ini mencapai nominal target.',
  },
  loss_gte: {
    label: 'Jika Kerugian Lebih Dari (≥)',
    icon: TrendingDown,
    unit: 'currency',
    description: 'Pindah strategi saat drawdown / rugi di strategi saat ini mencapai batas.',
  },
  win_streak_gte: {
    label: 'Jika Win Streak Mencapai (≥)',
    icon: Flame,
    unit: 'count',
    description: 'Pindah strategi saat meraih kemenangan beruntun sebanyak target kali.',
  },
  loss_streak_gte: {
    label: 'Jika Lose Streak Mencapai (≥)',
    icon: Snowflake,
    unit: 'count',
    description: 'Pindah strategi (recovery) saat mengalami kekalahan beruntun sebanyak target kali.',
  },
  bets_count_gte: {
    label: 'Jika Jumlah Putaran Mencapai (≥)',
    icon: RotateCw,
    unit: 'count',
    description: 'Pindah strategi setelah sejumlah putaran taruhan selesai dijalankan.',
  },
  wager_gte: {
    label: 'Jika Total Wager Mencapai (≥)',
    icon: Coins,
    unit: 'currency',
    description: 'Pindah strategi saat total nominal taruhan yang dipertaruhkan mencapai target.',
  },
};

export const StrategySwitchManager: React.FC<StrategySwitchManagerProps> = ({
  game,
  currency,
  strategies,
  activeStrategyId,
  switchRules,
  onChangeSwitchRules,
  switchRulesEnabled,
  onToggleSwitchRulesEnabled,
  disabled = false,
  onShowToast,
}) => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);

  // Form states
  const [tempConditionType, setTempConditionType] = useState<StrategySwitchConditionType>('profit_gte');
  const [tempThreshold, setTempThreshold] = useState<string>('0.0001');
  const [tempTargetId, setTempTargetId] = useState<string>('');
  const [tempResetCounters, setTempResetCounters] = useState<boolean>(true);
  const [formError, setFormError] = useState<string | null>(null);

  const curLower = currency.toLowerCase();
  const isIdr = curLower === 'idr';
  const badgeInfo = BADGE_MAP[curLower] || {
    bg: 'bg-[#f7931a]',
    text: 'text-white',
    symbol: currency.slice(0, 3).toUpperCase(),
  };

  const handleOpenCreate = () => {
    if (disabled) return;
    if (strategies.length < 2) {
      onShowToast?.(
        'Perlu Minimal 2 Strategi',
        'OFF',
        'Tambahkan minimal 2 strategi tersimpan untuk mengaktifkan perpindahan otomatis.'
      );
      return;
    }

    // Default target: choose a strategy different from currently active if possible
    const otherStrat = strategies.find((s) => s.id !== activeStrategyId) || strategies[0];
    setModalMode('create');
    setEditingRuleId(null);
    setTempConditionType('profit_gte');
    setTempThreshold(isIdr ? '1000' : '0.00001');
    setTempTargetId(otherStrat ? otherStrat.id : '');
    setTempResetCounters(true);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rule: StrategySwitchRule) => {
    if (disabled) return;
    setModalMode('edit');
    setEditingRuleId(rule.id);
    setTempConditionType(rule.conditionType);
    setTempThreshold(rule.threshold.toString());
    setTempTargetId(rule.targetStrategyId);
    setTempResetCounters(rule.resetCountersOnSwitch ?? true);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSaveRule = () => {
    setFormError(null);
    const parsedVal = parseFloat(tempThreshold);
    if (isNaN(parsedVal) || parsedVal <= 0) {
      setFormError('Masukkan nominal / jumlah target yang valid dan lebih dari 0.');
      return;
    }

    if (!tempTargetId) {
      setFormError('Pilih strategi tujuan untuk berpindah.');
      return;
    }

    const targetStrat = strategies.find((s) => s.id === tempTargetId);
    const targetName = targetStrat ? targetStrat.name : 'Strategi Tujuan';

    if (modalMode === 'create') {
      const newRule: StrategySwitchRule = {
        id: `switch_rule_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        enabled: true,
        conditionType: tempConditionType,
        threshold: parsedVal,
        targetStrategyId: tempTargetId,
        targetStrategyName: targetName,
        resetCountersOnSwitch: tempResetCounters,
      };

      const nextRules = [...switchRules, newRule];
      onChangeSwitchRules(nextRules);
      // Auto enable master switch if it was off
      if (!switchRulesEnabled) {
        onToggleSwitchRulesEnabled(true);
      }
      onShowToast?.(
        'Aturan Pindah Ditambahkan',
        'ON',
        `Pindah ke "${targetName}" saat ${CONDITION_INFO[tempConditionType].label} ${parsedVal}`
      );
    } else if (editingRuleId) {
      const nextRules = switchRules.map((r) =>
        r.id === editingRuleId
          ? {
              ...r,
              conditionType: tempConditionType,
              threshold: parsedVal,
              targetStrategyId: tempTargetId,
              targetStrategyName: targetName,
              resetCountersOnSwitch: tempResetCounters,
            }
          : r
      );
      onChangeSwitchRules(nextRules);
      onShowToast?.('Aturan Diperbarui', 'ON', 'Perubahan aturan pindah strategi disimpan.');
    }

    setIsModalOpen(false);
  };

  const handleDeleteRule = (id: string) => {
    if (disabled) return;
    const nextRules = switchRules.filter((r) => r.id !== id);
    onChangeSwitchRules(nextRules);
    onShowToast?.('Aturan Dihapus', 'INFO', 'Aturan pindah strategi dihapus.');
  };

  const handleToggleRuleEnabled = (id: string) => {
    if (disabled) return;
    const nextRules = switchRules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    onChangeSwitchRules(nextRules);
  };

  const activeRulesCount = switchRules.filter((r) => r.enabled).length;

  return (
    <div className="bg-zinc-50/80 border border-zinc-200/90 rounded-2xl p-3 sm:p-3.5 flex flex-col gap-2.5 font-mono shadow-2xs">
      {/* 1. Header with Master Toggle */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${
            switchRulesEnabled && activeRulesCount > 0 ? 'bg-emerald-600 text-white' : 'bg-zinc-200 text-zinc-600'
          }`}>
            <ArrowRightLeft className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] sm:text-xs font-black text-zinc-900 uppercase tracking-tight">
                Pindah Strategi Otomatis
              </span>
              <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                switchRulesEnabled && activeRulesCount > 0
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-zinc-200 text-zinc-600'
              }`}>
                {switchRulesEnabled ? `${activeRulesCount} Aktif` : 'Mati'}
              </span>
            </div>
            <p className="text-[10px] text-zinc-500 font-normal">
              Otomatis berpindah strategi saat profit / loss mencapai target
            </p>
          </div>
        </div>

        {/* Master ON/OFF Switch & Add Button */}
        <div className="flex items-center gap-1.5 ml-auto">
          <button
            type="button"
            onClick={() => {
              const next = !switchRulesEnabled;
              onToggleSwitchRulesEnabled(next);
              onShowToast?.(
                'Pindah Strategi Otomatis',
                next ? 'ON' : 'OFF',
                next ? 'Pindah strategi otomatis diaktifkan.' : 'Pindah strategi otomatis dinonaktifkan.'
              );
            }}
            disabled={disabled}
            className={`px-2.5 py-1 rounded-xl text-[10px] sm:text-[11px] font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50 ${
              switchRulesEnabled
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs'
                : 'bg-zinc-200 hover:bg-zinc-300 text-zinc-700'
            }`}
          >
            <span>{switchRulesEnabled ? 'Aktif' : 'Nonaktif'}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenCreate}
            disabled={disabled || strategies.length < 2}
            title={strategies.length < 2 ? 'Perlu minimal 2 strategi tersimpan' : 'Tambah Aturan Kondisi Baru'}
            className="px-2.5 py-1 rounded-xl bg-white hover:bg-zinc-100 border border-zinc-200 text-zinc-800 text-[10px] sm:text-[11px] font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-40 shadow-2xs"
          >
            <Plus className="w-3 h-3 text-emerald-600 stroke-[3]" />
            <span>+ Aturan</span>
          </button>
        </div>
      </div>

      {/* 2. Notice if user has less than 2 strategies */}
      {strategies.length < 2 && (
        <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-2.5 text-[11px] text-amber-800 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="leading-snug">
            <strong>Perlu Minimal 2 Strategi:</strong> Tambahkan 1 strategi lagi di atas agar game dapat berpindah otomatis antar-strategi (contoh: Strategi A untuk profit hunting, Strategi B untuk recovery drawdown).
          </div>
        </div>
      )}

      {/* 3. Rules List */}
      {strategies.length >= 2 && switchRules.length === 0 ? (
        <div className="bg-white border border-dashed border-zinc-200 rounded-xl p-3 text-center space-y-1.5">
          <span className="text-[11px] text-zinc-500 font-bold block">
            Belum ada aturan pindah strategi
          </span>
          <p className="text-[10px] text-zinc-400 max-w-sm mx-auto">
            Klik tombol <strong>"+ Aturan"</strong> untuk membuat kondisi seperti: <em>"Jika Profit ≥ 0.001 ➔ Pindah ke Strategi B"</em> atau <em>"Jika Lose ≥ 0.0005 ➔ Pindah ke Strategi Recovery"</em>.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-1.5">
          {switchRules.map((rule) => {
            const condInfo = CONDITION_INFO[rule.conditionType];
            const CondIcon = condInfo.icon;
            const targetStrat = strategies.find((s) => s.id === rule.targetStrategyId);
            const targetDisplayName = targetStrat?.name || rule.targetStrategyName || 'Strategi Tujuan';
            const isTargetActive = targetStrat?.id === activeStrategyId;

            return (
              <div
                key={rule.id}
                className={`p-2 rounded-xl border transition flex items-center justify-between gap-2 ${
                  rule.enabled && switchRulesEnabled
                    ? 'bg-white border-zinc-200/90 shadow-2xs'
                    : 'bg-zinc-100/70 border-zinc-200 opacity-60'
                }`}
              >
                {/* Checkbox toggle */}
                <button
                  type="button"
                  onClick={() => handleToggleRuleEnabled(rule.id)}
                  disabled={disabled}
                  className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 transition cursor-pointer ${
                    rule.enabled
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'border-zinc-300 bg-white hover:border-zinc-400'
                  }`}
                >
                  {rule.enabled && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </button>

                {/* Condition & Target summary */}
                <div className="flex-1 min-w-0 flex items-center gap-1.5 flex-wrap text-[11px]">
                  <div className="flex items-center gap-1 font-bold text-zinc-800">
                    <CondIcon className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                    <span>
                      {rule.conditionType === 'profit_gte' && 'Jika Profit ≥'}
                      {rule.conditionType === 'loss_gte' && 'Jika Rugi ≥'}
                      {rule.conditionType === 'win_streak_gte' && 'Jika Win Streak ≥'}
                      {rule.conditionType === 'loss_streak_gte' && 'Jika Lose Streak ≥'}
                      {rule.conditionType === 'bets_count_gte' && 'Jika Putaran ≥'}
                      {rule.conditionType === 'wager_gte' && 'Jika Total Wager ≥'}
                    </span>
                    <span className="text-zinc-950 font-black">
                      {condInfo.unit === 'currency'
                        ? `${rule.threshold} ${currency.toUpperCase()}`
                        : `${rule.threshold}×`}
                    </span>
                  </div>

                  <ArrowRightLeft className="w-3 h-3 text-zinc-400 shrink-0" />

                  {/* Target Strategy Badge */}
                  <div className="flex items-center gap-1 bg-emerald-50 border border-emerald-200 rounded-lg px-2 py-0.5 truncate">
                    <span className="text-[10px] text-emerald-600 font-bold">Pindah ke:</span>
                    <span className="text-[10px] text-emerald-950 font-black truncate max-w-[120px]">
                      {targetDisplayName}
                    </span>
                    {isTargetActive && (
                      <span className="text-[8px] px-1 py-0.2 rounded bg-emerald-600 text-white font-bold uppercase">
                        Aktif
                      </span>
                    )}
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(rule)}
                    disabled={disabled}
                    className="p-1 rounded-lg bg-zinc-50 hover:bg-zinc-200 text-zinc-600 cursor-pointer disabled:opacity-40"
                    title="Ubah Aturan"
                  >
                    <Pencil className="w-3 h-3" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteRule(rule.id)}
                    disabled={disabled}
                    className="p-1 rounded-lg bg-zinc-50 hover:bg-rose-50 hover:text-rose-600 text-zinc-400 cursor-pointer disabled:opacity-40"
                    title="Hapus Aturan"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 4. MODAL ADD / EDIT RULE */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150 font-mono text-zinc-900">
          <div className="bg-white border border-zinc-200 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden my-auto flex flex-col">
            <div className="px-4 py-3 border-b border-zinc-200 flex items-center justify-between bg-zinc-50 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700">
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-zinc-900">
                    {modalMode === 'create' ? 'Tambah Aturan Pindah Strategi' : 'Edit Aturan Pindah'}
                  </h3>
                  <p className="text-[10px] text-zinc-500">
                    Otomatis beralih ke strategi lain saat kondisi tercapai
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 flex-1 overflow-y-auto">
              {/* 1. Condition Selector */}
              <div className="space-y-1">
                <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                  Kondisi Pemicu
                </label>
                <select
                  value={tempConditionType}
                  onChange={(e) => setTempConditionType(e.target.value as StrategySwitchConditionType)}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-bold text-zinc-900 outline-none focus:border-emerald-500"
                >
                  <option value="profit_gte">📈 Jika Profit Lebih Dari (≥)</option>
                  <option value="loss_gte">📉 Jika Kerugian Lebih Dari (≥)</option>
                  <option value="win_streak_gte">🔥 Jika Win Streak (≥)</option>
                  <option value="loss_streak_gte">❄️ Jika Lose Streak (≥)</option>
                  <option value="bets_count_gte">🎲 Jika Jumlah Putaran (≥)</option>
                  <option value="wager_gte">💰 Jika Total Wager (≥)</option>
                </select>
                <p className="text-[10px] text-zinc-500 italic">
                  {CONDITION_INFO[tempConditionType].description}
                </p>
              </div>

              {/* 2. Target Threshold Input */}
              <div className="space-y-1">
                <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                  {CONDITION_INFO[tempConditionType].unit === 'currency'
                    ? `Nominal Target (${currency.toUpperCase()})`
                    : 'Jumlah Target (Kali)'}
                </label>
                <div className="bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 flex items-center justify-between gap-2 focus-within:border-emerald-500 focus-within:bg-white transition">
                  <input
                    type="text"
                    inputMode="decimal"
                    value={tempThreshold}
                    onChange={(e) => setTempThreshold(e.target.value)}
                    placeholder={
                      CONDITION_INFO[tempConditionType].unit === 'currency'
                        ? (isIdr ? '1000' : '0.00010000')
                        : '5'
                    }
                    className="w-full bg-transparent text-xs font-mono font-bold text-zinc-900 outline-none"
                  />
                  {CONDITION_INFO[tempConditionType].unit === 'currency' ? (
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 font-sans text-[10px] font-black ${badgeInfo.bg} ${badgeInfo.text}`}
                    >
                      {badgeInfo.symbol}
                    </div>
                  ) : (
                    <span className="text-zinc-500 font-bold text-xs select-none">×</span>
                  )}
                </div>
              </div>

              {/* 3. Target Strategy Selector */}
              <div className="space-y-1">
                <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                  Pindah ke Strategi Tujuan
                </label>
                <select
                  value={tempTargetId}
                  onChange={(e) => setTempTargetId(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-bold text-zinc-900 outline-none focus:border-emerald-500"
                >
                  <option value="" disabled>
                    -- Pilih Strategi Tujuan --
                  </option>
                  {strategies.map((strat) => (
                    <option key={strat.id} value={strat.id}>
                      {strat.name || 'Strategi Tanpa Nama'} {strat.id === activeStrategyId ? '(Sedang Aktif)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Reset Cycle Counter Checkbox */}
              <div className="pt-2 border-t border-zinc-100">
                <label className="flex items-start gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={tempResetCounters}
                    onChange={(e) => setTempResetCounters(e.target.checked)}
                    className="mt-0.5 rounded text-emerald-600 border-zinc-300 accent-emerald-600 cursor-pointer"
                  />
                  <div className="leading-tight">
                    <span className="text-[11px] font-bold text-zinc-800 block">
                      Reset Acuan Profit/Loss Saat Berpindah
                    </span>
                    <span className="text-[10px] text-zinc-500 block mt-0.5">
                      Direkomendasikan (ON). Menghitung profit/loss dari 0 kembali pada strategi baru agar tidak langsung memicu aturan berikutnya.
                    </span>
                  </div>
                </label>
              </div>

              {formError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}
            </div>

            <div className="px-4 py-3 border-t border-zinc-200 flex items-center justify-between bg-zinc-50 shrink-0">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 text-xs font-bold transition cursor-pointer"
              >
                Batal
              </button>

              <button
                type="button"
                onClick={handleSaveRule}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Simpan Aturan</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
