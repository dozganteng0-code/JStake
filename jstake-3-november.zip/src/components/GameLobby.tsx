import React from 'react';
import { Dices, Rocket, Sparkles, Trophy, Zap, Key, RefreshCw, LogOut, CircleDot, Flame, Bomb, Gem, Grid } from 'lucide-react';
import { GameType } from '../types/stake';

interface GameLobbyProps {
  username?: string;
  currency: string;
  balance: number;
  onSelectGame: (game: GameType) => void;
  onRefreshBalance: () => void;
  isRefreshingBalance: boolean;
  onDisconnect: () => void;
  onOpenSettings: () => void;
}

export const GameLobby: React.FC<GameLobbyProps> = ({
  username,
  currency,
  balance,
  onSelectGame,
  onRefreshBalance,
  isRefreshingBalance,
  onDisconnect,
  onOpenSettings,
}) => {
  return (
    <div className="flex flex-col gap-4 sm:gap-6 max-w-5xl w-full mx-auto font-sans">
      {/* Welcome Banner */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3.5 sm:p-5 text-zinc-900 shadow-xs relative overflow-hidden">
        <div className="flex flex-col xs:flex-row items-start xs:items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-center justify-center font-mono font-bold text-xs sm:text-sm shadow-xs shrink-0">
              {username ? username.charAt(0).toUpperCase() : 'U'}
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900">
                  {username ? `@${username}` : 'Akun Terhubung'}
                </h2>
                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-300 px-1.5 py-0.5 rounded-full text-[9px] sm:text-[10px] font-mono font-bold uppercase">
                  Aktif
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-zinc-500 font-mono mt-0.5">
                Pilih game untuk mulai bertaruh (Semua game instan tanpa animasi berat)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 self-end xs:self-auto">
            <button
              onClick={onRefreshBalance}
              disabled={isRefreshingBalance}
              className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-zinc-50 hover:bg-zinc-100 text-zinc-600 hover:text-zinc-900 border border-zinc-200 transition cursor-pointer"
              title="Refresh Saldo"
            >
              <RefreshCw className={`w-3.5 h-3.5 sm:w-4 h-4 ${isRefreshingBalance ? 'animate-spin text-emerald-600' : ''}`} />
            </button>
            <button
              onClick={onOpenSettings}
              className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-zinc-50 hover:bg-zinc-100 text-zinc-600 hover:text-zinc-900 border border-zinc-200 transition cursor-pointer"
              title="Pengaturan"
            >
              <Key className="w-3.5 h-3.5 sm:w-4 h-4" />
            </button>
            <button
              onClick={onDisconnect}
              className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition cursor-pointer"
              title="Putus Koneksi Token"
            >
              <LogOut className="w-3.5 h-3.5 sm:w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Balance bar */}
        <div className="mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between font-mono text-[10px] sm:text-xs">
          <span className="text-zinc-500 font-bold uppercase">Saldo Aktif:</span>
          <div className="flex items-center gap-2">
            <span className="font-bold text-emerald-700 text-xs sm:text-sm">
              {balance.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8)} {currency.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* Lobby Title */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold font-mono text-zinc-900 tracking-tight flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            STAKE ORIGINALS LOBBY
          </h3>
          <p className="text-xs text-zinc-500 font-mono">
            Pilih game Stake Originals untuk bertaruh instan tanpa animasi berat
          </p>
        </div>
      </div>

      {/* Game Cards Grid (Dice, Limbo, Plinko, Mines, Diamonds, Keno) */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4 w-full max-w-4xl mx-auto">
        {/* DICE CARD */}
        <div
          onClick={() => onSelectGame('dice')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-emerald-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <Dices className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-emerald-700 transition text-center">DICE</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Tebak angka roll dadu di atas atau di bawah target
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>

        {/* LIMBO CARD */}
        <div
          onClick={() => onSelectGame('limbo')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-cyan-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-cyan-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <Rocket className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-cyan-700 transition text-center">LIMBO</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Target roket multiplier instan hingga 1.000.000×
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>

        {/* PLINKO CARD */}
        <div
          onClick={() => onSelectGame('plinko')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-amber-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <CircleDot className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-amber-700 transition text-center">PLINKO</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Jatuhkan bola pin dengan pilihan risiko & baris beragam
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-600 hover:to-rose-700 text-white font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>

        {/* MINES CARD */}
        <div
          onClick={() => onSelectGame('mines')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-amber-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-amber-500 text-zinc-950 flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <Bomb className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-amber-700 transition text-center">MINES</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Buka petak keberuntungan dan hindari ranjau
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-zinc-950 font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>

        {/* DIAMONDS CARD */}
        <div
          onClick={() => onSelectGame('diamonds')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-cyan-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-cyan-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <Gem className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-cyan-700 transition text-center">DIAMONDS</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Kombinasi warna permata poker bernilai tinggi
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>

        {/* KENO CARD */}
        <div
          onClick={() => onSelectGame('keno')}
          className="group relative bg-white border border-zinc-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-purple-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between overflow-hidden"
        >
          <div className="flex flex-col items-center gap-2.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <Grid className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <h4 className="text-sm font-bold font-mono text-zinc-900 group-hover:text-purple-700 transition text-center">KENO</h4>
            <p className="text-[11px] text-zinc-500 font-sans text-center leading-snug line-clamp-2">
              Pilih 1-10 angka dari papan 40 petak Keno
            </p>
          </div>
          <button type="button" className="mt-3.5 w-full py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-mono font-bold text-xs shadow-xs cursor-pointer transition">
            MAIN
          </button>
        </div>
      </div>
    </div>
  );
};



