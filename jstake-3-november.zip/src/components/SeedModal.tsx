import React, { useState } from 'react';
import { ShieldCheck, X, RefreshCw, Check } from 'lucide-react';

interface SeedModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeClientSeed: string;
  activeServerSeedHash: string;
  nonce: number;
  onSaveNewSeed: (newSeed: string) => void;
}

export const SeedModal: React.FC<SeedModalProps> = ({
  isOpen,
  onClose,
  activeClientSeed,
  activeServerSeedHash,
  nonce,
  onSaveNewSeed,
}) => {
  const [newSeed, setNewSeed] = useState(activeClientSeed);

  if (!isOpen) return null;

  const handleRandomize = () => {
    const generated = 'jstkbot_' + Math.random().toString(36).substring(2, 12);
    setNewSeed(generated);
  };

  const handleSave = () => {
    const trimmed = newSeed.trim();
    if (trimmed) {
      onSaveNewSeed(trimmed);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-white text-zinc-900 border border-zinc-200 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col font-mono text-xs animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="font-bold text-sm text-zinc-900">PROVABLY FAIR & SEED</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <p className="text-zinc-500 text-[11px] leading-relaxed">
            Provably Fair memastikan hasil acak permainan tidak dapat dimanipulasi oleh siapapun. Anda dapat memperbarui Client Seed kapan saja.
          </p>

          <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 space-y-2">
            <span className="text-[10px] text-zinc-400 font-bold uppercase block">
              Seed Aktif Saat Ini
            </span>

            <div className="space-y-1">
              <span className="text-[10px] text-zinc-500 font-bold">Client Seed:</span>
              <div className="bg-white border border-zinc-200 rounded-lg p-2 font-bold text-zinc-800 text-xs break-all">
                {activeClientSeed}
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-zinc-500 font-bold">Server Seed (Hashed):</span>
              <div className="bg-white border border-zinc-200 rounded-lg p-2 font-mono text-[10px] text-zinc-600 break-all">
                {activeServerSeedHash}
              </div>
            </div>

            <div className="flex items-center justify-between text-zinc-600 pt-1">
              <span className="text-[10px] font-bold">Total Taruhan (Nonce):</span>
              <span className="font-bold text-emerald-600">{nonce}</span>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-zinc-100">
            <label className="text-xs font-bold text-zinc-800 block">
              Ubah Client Seed Baru:
            </label>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={newSeed}
                onChange={(e) => setNewSeed(e.target.value)}
                placeholder="Masukkan seed baru..."
                className="flex-1 bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-bold text-zinc-900 outline-none focus:border-emerald-500 transition"
              />
              <button
                type="button"
                onClick={handleRandomize}
                className="p-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-zinc-700 transition cursor-pointer flex items-center gap-1"
                title="Acak Seed Baru"
              >
                <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-[11px] font-bold">Acak</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white border border-zinc-200 text-zinc-700 font-bold text-xs hover:bg-zinc-100 transition cursor-pointer"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs transition cursor-pointer flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Simpan Seed Baru</span>
          </button>
        </div>
      </div>
    </div>
  );
};
