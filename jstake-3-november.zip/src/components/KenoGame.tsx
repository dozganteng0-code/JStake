import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Grid,
  Sparkles,
  RotateCcw,
  Wand2,
  Trophy,
  Play,
  Square,
  CheckCircle2,
  Info,
  Layers,
  Zap,
} from 'lucide-react';
import {
  KenoRisk,
  StakeConfig,
  BetResult,
  AutobetConfig,
  SavedStrategy,
  BatchProgress,
  StrategySwitchRule,
  KenoSavedStrategy,
} from '../types/stake';
import { KENO_PAYTABLES, getKenoMultiplier } from '../services/stakeApi';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import { GameFooterToolbar } from './GameFooterToolbar';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface KenoGameProps {
  userBalance: number;
  currency: string;
  config: StakeConfig;
  isRolling: boolean;
  lastBet: BetResult | null;
  onPlayKeno: (amount: number, numbers: number[], risk: KenoRisk) => Promise<boolean>;
  autobetRunning?: boolean;
  onToggleAutobet?: (config: AutobetConfig, numbers: number[], risk: KenoRisk) => void;
  onStopAutobet?: () => void;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  batchProgress?: BatchProgress | null;
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin?: boolean;
  stopOnLoss?: boolean;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

export const KenoGame: React.FC<KenoGameProps> = ({
  userBalance,
  currency,
  config,
  isRolling,
  lastBet,
  onPlayKeno,
  autobetRunning = false,
  onToggleAutobet,
  onStopAutobet,
  onShowToast,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin = false,
  stopOnLoss = false,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: switchRulesEnabledProp,
}) => {
  // Mode: Manual or Otomatis (Auto)
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies State
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() =>
    loadSavedStrategies('keno')
  );

  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('keno');
    const activeId = getActiveStrategyId('keno');
    if (activeId) {
      const found = list.find((s) => s.id === activeId);
      if (found) return found;
    }
    return list.length > 0 ? list[0] : null;
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const handleImportStrategies = (imported: SavedStrategy[]) => {
    setStrategies((prev) => {
      const existingIds = new Set(prev.map((s) => s.id));
      const newItems = imported.filter((s) => !existingIds.has(s.id));
      const updated = [...newItems, ...prev];
      saveSavedStrategies('keno', updated);
      if (imported[0]) {
        handleSelectStrategy(imported[0]);
      }
      return updated;
    });
  };

  // Selection & Risk
  const [risk, setRisk] = useState<KenoRisk>(() => (activeStrategy as KenoSavedStrategy)?.risk || 'classic');
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>(
    () => (activeStrategy as KenoSavedStrategy)?.selectedNumbers || [1, 5, 10, 15, 20, 25, 30, 35, 38, 40]
  );
  const [lastDrawnNumbers, setLastDrawnNumbers] = useState<number[]>([]);
  const [lastHitsCount, setLastHitsCount] = useState<number | null>(null);

  // Bet Amount
  const [betAmount, setBetAmount] = useState<string>(() => {
    const saved = localStorage.getItem('keno_bet_amount');
    return activeStrategy?.betAmount || saved || '0';
  });

  // Auto Bet Parameters
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('keno_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('keno_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('keno_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('keno_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('keno_on_loss_percent') || '0');

  // Safeguard Stops
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('keno_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('keno_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('keno_max_bet_cap') || '0');
  const [maxConsecutiveLosses, setMaxConsecutiveLosses] = useState<string>(() => activeStrategy?.maxConsecutiveLosses || localStorage.getItem('keno_max_consec_losses') || '0');
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('keno_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => activeStrategy?.stopWager || localStorage.getItem('keno_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => activeStrategy?.stopBalanceMin || localStorage.getItem('keno_stop_balance_min') || '0');

  // Switch Strategy Rules
  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('keno'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('keno'));

  const handleSelectStrategy = (strat: SavedStrategy | null) => {
    setActiveStrategy(strat);
    if (strat) {
      setActiveStrategyId('keno', strat.id);
      setBetAmount(strat.betAmount || '0');
      setNumberOfBets(strat.numberOfBets || '0');
      setOnWinAction(strat.onWinAction || 'reset');
      setOnWinPercent(strat.onWinPercent || '0');
      setOnLossAction(strat.onLossAction || 'reset');
      setOnLossPercent(strat.onLossPercent || '0');
      setStopProfit(strat.stopProfit || '0');
      setStopLoss(strat.stopLoss || '0');
      setMaxBetCap(strat.maxBetCap || '0');
      setMaxConsecutiveLosses(strat.maxConsecutiveLosses || '0');
      setTrailingStop(strat.trailingStop || '0');
      setStopWager(strat.stopWager || '0');
      setStopBalanceMin(strat.stopBalanceMin || '0');
      const kStrat = strat as KenoSavedStrategy;
      if (kStrat.risk) setRisk(kStrat.risk);
      if (kStrat.selectedNumbers && kStrat.selectedNumbers.length > 0) {
        setSelectedNumbers(kStrat.selectedNumbers);
      }
      onShowToast?.('Strategi Dipilih', 'INFO', `Menggunakan strategi: "${strat.name}"`);
    } else {
      localStorage.removeItem('stake_active_strategy_keno');
    }
  };

  const handleSaveStrategy = (strat: SavedStrategy) => {
    setStrategies((prev) => {
      const idx = prev.findIndex((s) => s.id === strat.id);
      let updated: SavedStrategy[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = strat;
      } else {
        updated = [strat, ...prev];
      }
      saveSavedStrategies('keno', updated);
      return updated;
    });
    handleSelectStrategy(strat);
  };

  const handleDeleteStrategy = (id: string) => {
    setStrategies((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveSavedStrategies('keno', updated);
      return updated;
    });
    if (activeStrategy?.id === id) {
      handleSelectStrategy(null);
    }
    onShowToast?.('Strategi Dihapus', 'OFF', 'Strategi berhasil dihapus.');
  };

  // Sync last bet result if from Keno
  useEffect(() => {
    if (lastBet && lastBet.game === 'keno') {
      if (lastBet.kenoDrawnNumbers && lastBet.kenoDrawnNumbers.length > 0) {
        setLastDrawnNumbers(lastBet.kenoDrawnNumbers);
      }
      if (typeof lastBet.kenoHitsCount === 'number') {
        setLastHitsCount(lastBet.kenoHitsCount);
      }
    }
  }, [lastBet]);

  const numSelected = selectedNumbers.length;

  // Toggle selection on tile
  const handleToggleTile = (num: number) => {
    if (isRolling || autobetRunning) return;
    if (selectedNumbers.includes(num)) {
      setSelectedNumbers(selectedNumbers.filter((n) => n !== num));
    } else {
      if (selectedNumbers.length >= 10) return; // Max 10 picks
      setSelectedNumbers([...selectedNumbers, num].sort((a, b) => a - b));
    }
  };

  // Quick Auto Pick 10 random numbers
  const handleAutoPick = () => {
    if (isRolling || autobetRunning) return;
    const pool = Array.from({ length: 40 }, (_, i) => i + 1);
    const shuffled = pool.sort(() => Math.random() - 0.5);
    const picked = shuffled.slice(0, 10).sort((a, b) => a - b);
    setSelectedNumbers(picked);
  };

  // Clear selections
  const handleClearPicks = () => {
    if (isRolling || autobetRunning) return;
    setSelectedNumbers([]);
  };

  // Calculate current paytable multipliers for selected count
  const currentPaytable = useMemo(() => {
    if (numSelected === 0) return [];
    return KENO_PAYTABLES[risk]?.[numSelected] || [];
  }, [risk, numSelected]);

  // Max multiplier available for current selection
  const maxMultiplier = useMemo(() => {
    if (currentPaytable.length === 0) return 0;
    return Math.max(...currentPaytable);
  }, [currentPaytable]);

  // Handle Manual Bet submit
  const handleBetSubmit = async () => {
    if (isRolling || numSelected === 0 || autobetRunning) return;
    const amountNum = parseFloat(betAmount) || 0;
    await onPlayKeno(amountNum, selectedNumbers, risk);
  };

  // Handle Start Autobet
  const handleStartAutobet = () => {
    if (!onToggleAutobet) return;
    if (numSelected === 0) {
      onShowToast?.('Pilih Angka', 'OFF', 'Pilih minimal 1 angka sebelum menjalankan taruhan otomatis.');
      return;
    }

    const currentStrat = (activeStrategy || strategies.find(s => s.id === getActiveStrategyId('keno')) || strategies[0]) as KenoSavedStrategy | undefined;

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : (parseFloat(betAmount) || 0);
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(String(currentStrat.onWinEveryCount), 10) || 1
      : 1;
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(String(currentStrat.onLossEveryCount), 10) || 1
      : 1;
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const autoRisk = currentStrat?.risk || risk;

    const autoConfig: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      maxConsecutiveLosses: parseInt(maxConsecutiveLosses, 10) || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopOnWin,
      stopOnLoss,
      stopLoseStreak,
      stopWinStreak,
      switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onBetAmountChange: (amt) => setBetAmount(amt.toString()),
      onSwitchStrategy: (targetStrat) => handleSelectStrategy(targetStrat),
      getLiveTriggers: () => ({
        stopOnWin,
        stopOnLoss,
        stopLoseStreak,
        stopWinStreak,
        stopProfit: parseFloat(stopProfit) || 0,
        stopLoss: parseFloat(stopLoss) || 0,
        stopWager: parseFloat(stopWager) || 0,
        stopBalanceMin: parseFloat(stopBalanceMin) || 0,
        maxBetCap: parseFloat(maxBetCap) || 0,
        maxConsecutiveLosses: parseInt(maxConsecutiveLosses, 10) || 0,
        trailingStop: parseFloat(trailingStop) || 0,
        switchRules,
        switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(autoConfig, selectedNumbers, autoRisk);
  };

  const parsedBet = parseFloat(betAmount) || 0;
  const isZeroBet = parsedBet === 0;

  return (
    <div className="flex flex-col gap-4 max-w-4xl mx-auto w-full font-sans">
      {/* Top Banner Header */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold shadow-xs">
            <Grid className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-zinc-900 tracking-tight flex items-center gap-2">
              KENO ORIGINALS
              <span className="text-[10px] font-normal px-2 py-0.5 bg-purple-50 text-purple-700 border border-purple-200 rounded-full">
                Fast Zero-Animation Mode
              </span>
            </h2>
            <p className="text-xs text-zinc-500 font-mono">
              Pilih 1 - 10 angka dari 40 petak Keno. Sistem otomatis & strategi cepat tanpa animasi lambat.
            </p>
          </div>
        </div>

        {/* Selected count info */}
        <div className="flex items-center gap-2 font-mono text-xs bg-zinc-50 border border-zinc-200 px-3 py-1.5 rounded-xl">
          <span className="text-zinc-500">Petak Dipilih:</span>
          <span className={`font-bold ${numSelected > 0 ? 'text-purple-600' : 'text-zinc-400'}`}>
            {numSelected} / 10
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* LEFT COLUMN: Controls & Settings Panel */}
        <div className="md:col-span-5 bg-white border border-zinc-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between gap-4">
          <div className="flex flex-col gap-3.5">
            {/* Mode Switcher Tabs: Manual vs Otomatis */}
            <div className="grid grid-cols-2 gap-1 p-1 bg-zinc-100 rounded-xl font-mono text-xs">
              <button
                type="button"
                onClick={() => setTabMode('manual')}
                disabled={autobetRunning}
                className={`py-1.5 rounded-lg font-bold transition ${
                  tabMode === 'manual'
                    ? 'bg-white text-zinc-900 shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900'
                }`}
              >
                Manual
              </button>
              <button
                type="button"
                onClick={() => setTabMode('auto')}
                disabled={autobetRunning}
                className={`py-1.5 rounded-lg font-bold transition ${
                  tabMode === 'auto'
                    ? 'bg-purple-600 text-white shadow-2xs'
                    : 'text-zinc-500 hover:text-zinc-900'
                }`}
              >
                Otomatis
              </button>
            </div>

            {/* TAB CONTENT: MANUAL MODE */}
            {tabMode === 'manual' && (
              <>
                {/* Bet Amount */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold font-mono text-zinc-700 uppercase">
                      Jumlah Taruhan ({currency.toUpperCase()})
                    </label>
                    {isZeroBet && (
                      <span className="text-[10px] font-mono text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                        Mode Test Bet 0
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      placeholder="0"
                      disabled={isRolling || autobetRunning}
                      className="w-full bg-zinc-50 border border-zinc-300 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 rounded-xl px-3 py-2 text-sm font-mono font-bold text-zinc-900 outline-none transition"
                    />
                  </div>

                  {/* Quick Bet Buttons */}
                  <div className="grid grid-cols-5 gap-1.5 mt-1.5">
                    <button
                      type="button"
                      onClick={() => setBetAmount('0')}
                      disabled={isRolling || autobetRunning}
                      className="py-1 px-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs rounded-lg transition font-bold"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      onClick={() => setBetAmount('0')}
                      disabled={isRolling || autobetRunning}
                      className="py-1 px-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs rounded-lg transition font-bold"
                    >
                      Min
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const val = parseFloat(betAmount) || 0;
                        setBetAmount((val / 2).toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
                      }}
                      disabled={isRolling || autobetRunning}
                      className="py-1 px-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs rounded-lg transition font-bold"
                    >
                      ½
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const val = parseFloat(betAmount) || 0;
                        setBetAmount((val * 2).toFixed(currency.toLowerCase() === 'idr' ? 2 : 8));
                      }}
                      disabled={isRolling || autobetRunning}
                      className="py-1 px-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs rounded-lg transition font-bold"
                    >
                      2×
                    </button>
                    <button
                      type="button"
                      onClick={() => setBetAmount(userBalance.toFixed(currency.toLowerCase() === 'idr' ? 2 : 8))}
                      disabled={isRolling || autobetRunning}
                      className="py-1 px-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 font-mono text-xs rounded-lg transition font-bold"
                    >
                      Max
                    </button>
                  </div>
                </div>

                {/* Risk Selection */}
                <div>
                  <label className="text-xs font-bold font-mono text-zinc-700 uppercase block mb-1">
                    Tingkat Risiko (Risk)
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['classic', 'low', 'medium', 'high'] as KenoRisk[]).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRisk(r)}
                        disabled={isRolling || autobetRunning}
                        className={`py-2 px-1 text-xs font-mono font-bold capitalize rounded-xl border transition ${
                          risk === r
                            ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                            : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quick Pick Actions */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-zinc-100">
                  <button
                    type="button"
                    onClick={handleAutoPick}
                    disabled={isRolling || autobetRunning}
                    className="py-2 px-3 bg-zinc-100 hover:bg-purple-50 hover:text-purple-700 hover:border-purple-300 text-zinc-800 border border-zinc-200 font-mono text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Wand2 className="w-3.5 h-3.5 text-purple-600" />
                    Pilih Acak (10)
                  </button>
                  <button
                    type="button"
                    onClick={handleClearPicks}
                    disabled={isRolling || autobetRunning || numSelected === 0}
                    className="py-2 px-3 bg-zinc-100 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-300 text-zinc-800 border border-zinc-200 font-mono text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-rose-500" />
                    Hapus Pilihan
                  </button>
                </div>
              </>
            )}

            {/* TAB CONTENT: OTOMATIS MODE & STRATEGY SYSTEM */}
            {tabMode === 'auto' && (
              <div className="space-y-3 font-mono text-xs">
                {/* Strategy Selector & Manager Button */}
                <AutoBetStrategyManager
                  game="keno"
                  currency={currency}
                  strategies={strategies}
                  activeStrategy={activeStrategy}
                  onSelectStrategy={handleSelectStrategy}
                  onSaveStrategy={handleSaveStrategy}
                  onDeleteStrategy={handleDeleteStrategy}
                  onImportStrategies={handleImportStrategies}
                  autobetRunning={autobetRunning}
                  onShowToast={onShowToast}
                  stopProfit={stopProfit}
                  onChangeStopProfit={setStopProfit}
                  stopLoss={stopLoss}
                  onChangeStopLoss={setStopLoss}
                  maxBetCap={maxBetCap}
                  onChangeMaxBetCap={setMaxBetCap}
                  maxConsecutiveLosses={maxConsecutiveLosses}
                  onChangeMaxConsecutiveLosses={setMaxConsecutiveLosses}
                  trailingStop={trailingStop}
                  onChangeTrailingStop={setTrailingStop}
                  stopWager={stopWager}
                  onChangeStopWager={setStopWager}
                  stopBalanceMin={stopBalanceMin}
                  onChangeStopBalanceMin={setStopBalanceMin}
                  stopOnWin={stopOnWin}
                  onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
                  stopOnLoss={stopOnLoss}
                  onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
                  stopWinStreak={stopWinStreak ? stopWinStreak.toString() : '0'}
                  onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
                  switchRules={switchRules}
                  onChangeSwitchRules={(rules) => {
                    setSwitchRules(rules);
                    saveSwitchRules('keno', rules);
                  }}
                  switchRulesEnabled={switchRulesEnabled}
                  onToggleSwitchRulesEnabled={(enabled) => {
                    setSwitchRulesEnabledState(enabled);
                    setSwitchRulesEnabled('keno', enabled);
                  }}
                  renderStrategyForm={(temp, setTemp) => {
                    const kTemp = temp as KenoSavedStrategy;
                    const currentPicks = Array.isArray(kTemp.selectedNumbers) && kTemp.selectedNumbers.length > 0
                      ? kTemp.selectedNumbers
                      : [1, 5, 10, 15, 20, 25, 30, 35, 38, 40];

                    const toggleStratNum = (num: number) => {
                      if (currentPicks.includes(num)) {
                        setTemp({ ...kTemp, selectedNumbers: currentPicks.filter((n) => n !== num) });
                      } else {
                        if (currentPicks.length >= 10) return;
                        setTemp({ ...kTemp, selectedNumbers: [...currentPicks, num].sort((a, b) => a - b) });
                      }
                    };

                    const handleStratAutoPick = () => {
                      const pool = Array.from({ length: 40 }, (_, i) => i + 1);
                      const shuffled = pool.sort(() => Math.random() - 0.5);
                      const picked = shuffled.slice(0, 10).sort((a, b) => a - b);
                      setTemp({ ...kTemp, selectedNumbers: picked });
                    };

                    const handleStratClearPicks = () => {
                      setTemp({ ...kTemp, selectedNumbers: [] });
                    };

                    return (
                      <div className="space-y-3 pt-2 border-t border-zinc-100 font-mono">
                        {/* 1. Base Bet Amount */}
                        <div className="space-y-1">
                          <label className="text-[11px] text-zinc-600 font-bold uppercase block">
                            Jumlah Taruhan Dasar (Base Amount)
                          </label>
                          <input
                            type="text"
                            value={kTemp.betAmount}
                            onChange={(e) => setTemp({ ...kTemp, betAmount: e.target.value })}
                            placeholder="0.00000000"
                            className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-purple-500"
                          />
                        </div>

                        {/* 2. Keno Risk */}
                        <div>
                          <label className="text-[10px] text-zinc-500 font-bold uppercase block mb-1">
                            Tingkat Risiko Strategi
                          </label>
                          <div className="grid grid-cols-4 gap-1">
                            {(['classic', 'low', 'medium', 'high'] as KenoRisk[]).map((r) => (
                              <button
                                key={r}
                                type="button"
                                onClick={() => setTemp({ ...kTemp, risk: r })}
                                className={`py-1 text-[11px] font-bold rounded-lg border capitalize transition cursor-pointer ${
                                  kTemp.risk === r
                                    ? 'bg-purple-600 text-white border-purple-600'
                                    : 'bg-zinc-50 text-zinc-700 border-zinc-200'
                                }`}
                              >
                                {r}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* 3. 40 Keno Grid Selector inside Strategy Editor */}
                        <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-3 space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-zinc-700">
                              Pilih Angka Strategi ({currentPicks.length}/10):
                            </span>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={handleStratAutoPick}
                                className="px-2 py-0.5 bg-purple-100 hover:bg-purple-200 text-purple-800 text-[10px] font-bold rounded-lg cursor-pointer"
                              >
                                Acak (10)
                              </button>
                              <button
                                type="button"
                                onClick={handleStratClearPicks}
                                className="px-2 py-0.5 bg-rose-100 hover:bg-rose-200 text-rose-800 text-[10px] font-bold rounded-lg cursor-pointer"
                              >
                                Hapus
                              </button>
                            </div>
                          </div>

                          <div className="grid grid-cols-8 gap-1 pt-1">
                            {Array.from({ length: 40 }, (_, i) => i + 1).map((num) => {
                              const isSelected = currentPicks.includes(num);
                              return (
                                <button
                                  key={num}
                                  type="button"
                                  onClick={() => toggleStratNum(num)}
                                  className={`aspect-square rounded-lg font-mono text-[10px] sm:text-xs font-bold border flex items-center justify-center transition cursor-pointer ${
                                    isSelected
                                      ? 'bg-purple-600 text-white border-purple-700 shadow-2xs'
                                      : 'bg-white text-zinc-600 border-zinc-200 hover:bg-zinc-100'
                                  }`}
                                >
                                  {num}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* 4. Number of bets */}
                        <div className="space-y-1">
                          <label className="text-[11px] text-zinc-500 font-bold uppercase block">
                            Jumlah Putaran (0 = Tanpa Batas)
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={kTemp.numberOfBets}
                            onChange={(e) => setTemp({ ...kTemp, numberOfBets: e.target.value })}
                            placeholder="0"
                            className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 outline-none focus:border-purple-500"
                          />
                        </div>

                        {/* 5. Strategy Controls */}
                        <AutoBetStrategyControls
                          onWinAction={kTemp.onWinAction}
                          onChangeOnWinAction={(val) => setTemp({ ...kTemp, onWinAction: val })}
                          onWinPercent={kTemp.onWinPercent}
                          onChangeOnWinPercent={(val) => setTemp({ ...kTemp, onWinPercent: val })}
                          onWinEveryCount={kTemp.onWinEveryCount}
                          onChangeOnWinEveryCount={(val) => setTemp({ ...kTemp, onWinEveryCount: val })}
                          onLossAction={kTemp.onLossAction}
                          onChangeOnLossAction={(val) => setTemp({ ...kTemp, onLossAction: val })}
                          onLossPercent={kTemp.onLossPercent}
                          onChangeOnLossPercent={(val) => setTemp({ ...kTemp, onLossPercent: val })}
                          onLossEveryCount={kTemp.onLossEveryCount}
                          onChangeOnLossEveryCount={(val) => setTemp({ ...kTemp, onLossEveryCount: val })}
                          currency={currency}
                          disabled={false}
                        />
                      </div>
                    );
                  }}
                />
              </div>
            )}
          </div>

          {/* MAIN BUTTON: Manual Submit OR Autobet Start/Stop */}
          {tabMode === 'manual' ? (
            <button
              type="button"
              onClick={handleBetSubmit}
              disabled={isRolling || numSelected === 0}
              className={`w-full py-3.5 rounded-xl font-mono font-bold text-sm tracking-wide shadow-md transition cursor-pointer flex items-center justify-center gap-2 ${
                isRolling || numSelected === 0
                  ? 'bg-zinc-200 text-zinc-400 cursor-not-allowed shadow-none'
                  : isZeroBet
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200'
                  : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'
              }`}
            >
              {isRolling ? (
                'MENARIK ANGKA...'
              ) : numSelected === 0 ? (
                'PILIH MIN. 1 ANGKA'
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  {isZeroBet ? 'TARUHAN KENO (BET 0)' : 'TARUHAN KENO'}
                </>
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={autobetRunning ? onStopAutobet : handleStartAutobet}
              disabled={!autobetRunning && (!activeStrategy && strategies.length === 0)}
              className={`w-full py-3.5 rounded-xl font-mono font-bold text-sm tracking-wide shadow-md transition cursor-pointer flex items-center justify-center gap-2 ${
                autobetRunning
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-200'
                  : (!activeStrategy && strategies.length === 0)
                  ? 'bg-zinc-200 text-zinc-400 cursor-not-allowed shadow-none'
                  : 'bg-purple-600 hover:bg-purple-700 text-white shadow-purple-200'
              }`}
            >
              {autobetRunning ? (
                <>
                  <Square className="w-4 h-4 fill-current" />
                  HENTIKAN TARUHAN OTOMATIS
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  {!activeStrategy && strategies.length === 0
                    ? 'TAMBAH STRATEGI DAHULU'
                    : `MULAI AUTO BET KENO (${activeStrategy?.name || 'STRATEGI'})`}
                </>
              )}
            </button>
          )}
        </div>

        {/* RIGHT COLUMN */}
        <div className="md:col-span-7 bg-white border border-zinc-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between gap-4 font-mono">
          {tabMode === 'manual' ? (
            <>
              {/* Manual Mode: Header info */}
              <div className="flex items-center justify-between text-xs font-mono border-b border-zinc-100 pb-2">
                <div className="text-zinc-500">
                  Maks Multiplier:{' '}
                  <span className="font-bold text-purple-600">
                    {maxMultiplier > 0 ? `${maxMultiplier}×` : '-'}
                  </span>
                </div>
                {lastHitsCount !== null && (
                  <div className="flex items-center gap-1 font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {lastHitsCount} / {numSelected} Cocok!
                  </div>
                )}
              </div>

              {/* 40 Keno Tiles Grid for Manual Mode */}
              <div className="grid grid-cols-8 gap-1.5 sm:gap-2">
                {Array.from({ length: 40 }, (_, i) => i + 1).map((num) => {
                  const isSelected = selectedNumbers.includes(num);
                  const isDrawn = lastDrawnNumbers.includes(num);
                  const isHit = isSelected && isDrawn;

                  let tileClass = 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100 hover:border-purple-300';
                  if (isHit) {
                    tileClass = 'bg-emerald-500 text-white border-emerald-600 font-black ring-2 ring-emerald-300';
                  } else if (isDrawn && !isSelected) {
                    tileClass = 'bg-purple-100 text-purple-900 border-purple-300 font-bold';
                  } else if (isSelected) {
                    tileClass = 'bg-purple-600 text-white border-purple-700 font-bold';
                  }

                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleToggleTile(num)}
                      disabled={isRolling || autobetRunning}
                      className={`aspect-square rounded-xl font-mono text-xs sm:text-sm border flex items-center justify-center relative cursor-pointer ${tileClass}`}
                    >
                      {num}
                      {isHit && (
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-yellow-400 text-zinc-900 rounded-full flex items-center justify-center text-[8px] font-bold">
                          ✓
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Multiplier Paytable Bar */}
              <div>
                <div className="text-[11px] font-mono font-bold text-zinc-500 mb-1 flex items-center justify-between">
                  <span>TABEL MULTIPLIER ({numSelected} PETAK DIPILIH):</span>
                  {numSelected === 0 && (
                    <span className="text-zinc-400 font-normal">Pilih angka di papan untuk melihat multiplier</span>
                  )}
                </div>

                {numSelected > 0 ? (
                  <div className="grid grid-flow-col auto-cols-fr gap-1 font-mono text-center overflow-x-auto pb-1">
                    {currentPaytable.map((mult, hits) => {
                      const isCurrentHit = lastHitsCount === hits;
                      return (
                        <div
                          key={hits}
                          className={`p-1.5 rounded-xl border flex flex-col items-center justify-center ${
                            isCurrentHit
                              ? 'bg-emerald-500 text-white border-emerald-600 ring-2 ring-emerald-300'
                              : mult > 0
                              ? 'bg-purple-50 text-purple-900 border-purple-200'
                              : 'bg-zinc-50 text-zinc-400 border-zinc-200'
                          }`}
                        >
                          <span className="text-[10px] opacity-75">{hits} Hit</span>
                          <span className="text-xs font-bold">{mult}×</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-center text-xs font-mono text-zinc-400">
                    Pilih antara 1 sampai 10 angka untuk menampilkan multiplier
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Auto Mode: Clean Result Card without the 40 Keno Grid */
            <div className="flex flex-col gap-3.5">
              {/* Active Strategy Header Info */}
              <div className="bg-purple-50/80 border border-purple-200/80 rounded-2xl p-3 flex flex-col gap-2">
                <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded border border-purple-200">
                      Strategi Aktif
                    </span>
                    <strong className="text-purple-950 font-bold text-sm">
                      {activeStrategy?.name || 'Tanpa Strategi (Default)'}
                    </strong>
                  </div>
                  <span className="text-[11px] font-bold text-zinc-500 uppercase">
                    Risiko: <strong className="text-purple-700">{((activeStrategy as KenoSavedStrategy)?.risk || risk).toUpperCase()}</strong>
                  </span>
                </div>

                {/* Strategy Selected Numbers Pill List */}
                <div className="space-y-1 pt-1 border-t border-purple-200/50">
                  <span className="text-[10px] text-zinc-500 font-bold uppercase block">
                    Angka Strategi ({((activeStrategy as KenoSavedStrategy)?.selectedNumbers || selectedNumbers).length} Angka):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {((activeStrategy as KenoSavedStrategy)?.selectedNumbers || selectedNumbers).map((num) => (
                      <span
                        key={num}
                        className="px-2 py-0.5 rounded-lg bg-purple-600 text-white text-[11px] font-bold shadow-2xs"
                      >
                        #{num}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Live Bet Result Box */}
              {(() => {
                const currentStratNumbers = (activeStrategy as KenoSavedStrategy)?.selectedNumbers || selectedNumbers;
                const activeDrawn = (lastBet && lastBet.game === 'keno' && lastBet.kenoDrawnNumbers)
                  ? lastBet.kenoDrawnNumbers
                  : lastDrawnNumbers;
                const activeSelected = (lastBet && lastBet.game === 'keno' && lastBet.kenoSelectedNumbers)
                  ? lastBet.kenoSelectedNumbers
                  : currentStratNumbers;
                const hitNumbers = activeSelected.filter((n) => activeDrawn.includes(n));
                const hitsCount = (lastBet && lastBet.game === 'keno' && typeof lastBet.kenoHitsCount === 'number')
                  ? lastBet.kenoHitsCount
                  : hitNumbers.length;
                const mult = lastBet && lastBet.game === 'keno' ? lastBet.multiplier : 0;
                const won = lastBet && lastBet.game === 'keno' ? lastBet.won : false;
                const profit = lastBet && lastBet.game === 'keno' ? lastBet.profit : 0;

                return (
                  <div className="bg-white border-2 border-zinc-200 rounded-2xl p-4 space-y-3.5 shadow-xs">
                    <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                      <span className="text-xs font-bold text-zinc-800 uppercase flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-purple-600" />
                        HASIL TARUHAN OTOMATIS
                      </span>
                      {lastBet && lastBet.game === 'keno' && (
                        <span className={`text-xs font-black px-2.5 py-0.5 rounded-full border ${
                          won
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                            : 'bg-rose-50 text-rose-700 border-rose-300'
                        }`}>
                          {won ? 'MENANG' : 'KALAH'}
                        </span>
                      )}
                    </div>

                    {/* Prominent Hit Numbers Display */}
                    <div className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="text-zinc-700 uppercase">Angka yang Di-hit (Cocok):</span>
                        <span className="text-emerald-600 font-black">
                          {hitsCount} / {activeSelected.length} Cocok
                        </span>
                      </div>

                      {hitNumbers.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {hitNumbers.map((num) => (
                            <span
                              key={num}
                              className="px-3 py-1 rounded-xl bg-emerald-500 text-white font-extrabold text-sm shadow-xs flex items-center gap-1 ring-2 ring-emerald-300"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                              <span>{num}</span>
                            </span>
                          ))}
                        </div>
                      ) : (
                        <div className="text-xs text-zinc-400 font-semibold py-1">
                          {lastBet ? 'Tidak ada angka yang cocok pada putaran ini.' : 'Belum ada hasil taruhan otomatis.'}
                        </div>
                      )}
                    </div>

                    {/* Stats Summary Grid: Multiplier, Profit, Wager */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="bg-purple-50 border border-purple-200 rounded-xl p-2.5">
                        <span className="text-[10px] text-purple-700 font-bold uppercase block">Multiplier:</span>
                        <span className="text-lg font-black text-purple-900">{mult.toFixed(2)}×</span>
                      </div>

                      <div className={`border rounded-xl p-2.5 ${
                        profit > 0
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : profit < 0
                          ? 'bg-rose-50 border-rose-200 text-rose-900'
                          : 'bg-zinc-50 border-zinc-200 text-zinc-700'
                      }`}>
                        <span className="text-[10px] font-bold uppercase block opacity-75">Profit Putaran:</span>
                        <span className="text-lg font-black font-mono">
                          {profit > 0 ? `+${profit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)}` : profit.toFixed(currency.toLowerCase() === 'idr' ? 0 : 8)} {currency.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {/* Drawn Numbers Chips */}
                    {activeDrawn.length > 0 && (
                      <div className="space-y-1 pt-1 border-t border-zinc-100">
                        <span className="text-[10px] text-zinc-400 font-bold uppercase block">
                          Angka Ditarik Stake (20 Angka):
                        </span>
                        <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                          {activeDrawn.map((num) => {
                            const isHit = activeSelected.includes(num);
                            return (
                              <span
                                key={num}
                                className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                                  isHit
                                    ? 'bg-emerald-500 text-white font-black'
                                    : 'bg-zinc-100 text-zinc-500 border border-zinc-200'
                                }`}
                              >
                                {num}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Multiplier Paytable Bar for strategy */}
              {(() => {
                const currentStratNumbers = (activeStrategy as KenoSavedStrategy)?.selectedNumbers || selectedNumbers;
                const stratRisk = (activeStrategy as KenoSavedStrategy)?.risk || risk;
                const paytable = KENO_PAYTABLES[stratRisk]?.[currentStratNumbers.length] || [];
                if (paytable.length === 0) return null;

                return (
                  <div>
                    <div className="text-[11px] font-mono font-bold text-zinc-500 mb-1 flex items-center justify-between">
                      <span>TABEL MULTIPLIER STRATEGI ({currentStratNumbers.length} ANGKA DIPILIH):</span>
                      <span className="text-purple-600 font-bold">Maks {Math.max(...paytable)}×</span>
                    </div>

                    <div className="grid grid-flow-col auto-cols-fr gap-1 font-mono text-center overflow-x-auto pb-1">
                      {paytable.map((mVal, hits) => {
                        const isCurrentHit = lastHitsCount === hits;
                        return (
                          <div
                            key={hits}
                            className={`p-1.5 rounded-xl border flex flex-col items-center justify-center ${
                              isCurrentHit
                                ? 'bg-emerald-500 text-white border-emerald-600 ring-2 ring-emerald-300'
                                : mVal > 0
                                ? 'bg-purple-50 text-purple-900 border-purple-200'
                                : 'bg-zinc-50 text-zinc-400 border-zinc-200'
                            }`}
                          >
                            <span className="text-[10px] opacity-75">{hits} Hit</span>
                            <span className="text-xs font-bold">{mVal}×</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* Game Footer Toolbar */}
      <GameFooterToolbar
        batchDelayMs={400}
        onBatchDelayChange={() => {}}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="purple"
      />
    </div>
  );
};
