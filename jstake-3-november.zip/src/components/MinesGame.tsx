import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Bomb,
  Diamond,
  Play,
  Square,
  Settings,
  BarChart2,
  Zap,
} from 'lucide-react';
import {
  AutobetConfig,
  BatchProgress,
  BetResult,
  MinesSavedStrategy,
  SavedStrategy,
  StakeConfig,
  StrategySwitchRule,
} from '../types/stake';
import {
  playMinesBet,
  revealMinesTile,
  cashoutMines,
  fetchActiveMines,
} from '../services/stakeApi';
import { AutoBetStrategyControls } from './AutoBetStrategyControls';
import { AutoBetStrategyManager } from './AutoBetStrategyManager';
import { GameFooterToolbar } from './GameFooterToolbar';
import {
  loadSavedStrategies,
  saveSavedStrategies,
  getActiveStrategyId,
  setActiveStrategyId,
  loadSwitchRules,
  saveSwitchRules,
  getSwitchRulesEnabled,
  setSwitchRulesEnabled,
} from '../utils/strategyStorage';

interface MinesGameProps {
  balance: number;
  currency: string;
  isRolling: boolean;
  onBetFinished: (result: BetResult) => void;
  houseEdgePercent?: number;
  onShowToast?: (title: string, status: 'ON' | 'OFF' | 'INFO', message?: string) => void;
  config: StakeConfig;
  onRefreshBalance?: () => void;
  autobetRunning?: boolean;
  onToggleAutobet?: (config: AutobetConfig, minesCount: number, autoFields: number[]) => void;
  onStopAutobet?: () => void;
  batchProgress?: BatchProgress | null;
  stopLoseStreak?: number;
  stopWinStreak?: number;
  stopOnWin?: boolean;
  stopOnLoss?: boolean;
  lastBet?: BetResult | null;
  showHistoryStats?: boolean;
  onToggleShowStats?: () => void;
  onUpdateTriggers?: (triggers: { stopOnWin?: boolean; stopOnLoss?: boolean; stopLoseStreak?: number; stopWinStreak?: number }) => void;
  switchRulesEnabled?: boolean;
}

export const MinesGame: React.FC<MinesGameProps> = ({
  balance,
  currency,
  isRolling = false,
  onBetFinished,
  houseEdgePercent = 1.0,
  onShowToast,
  config,
  onRefreshBalance,
  autobetRunning = false,
  onToggleAutobet,
  onStopAutobet,
  batchProgress,
  stopLoseStreak = 0,
  stopWinStreak = 0,
  stopOnWin = false,
  stopOnLoss = false,
  showHistoryStats = true,
  onToggleShowStats,
  onUpdateTriggers,
  switchRulesEnabled: externalSwitchRulesEnabled = false,
}) => {
  const [tabMode, setTabMode] = useState<'manual' | 'auto'>('manual');

  // Saved Strategies
  const [strategies, setStrategies] = useState<SavedStrategy[]>(() => loadSavedStrategies('mines'));
  const [activeStrategy, setActiveStrategy] = useState<SavedStrategy | null>(() => {
    const list = loadSavedStrategies('mines');
    const activeId = getActiveStrategyId('mines');
    return list.find((s) => s.id === activeId) || (list.length > 0 ? list[0] : null);
  });

  const activeStrategyRef = useRef<SavedStrategy | null>(activeStrategy);
  useEffect(() => {
    activeStrategyRef.current = activeStrategy;
  }, [activeStrategy]);

  const [betAmount, setBetAmount] = useState<string>(() => {
    if (activeStrategy?.betAmount) return activeStrategy.betAmount;
    try {
      const saved = localStorage.getItem('mines_bet_amount');
      return (saved === '0.00000001' ? '0' : saved) || '0';
    } catch {
      return '0';
    }
  });

  const [minesCount, setMinesCount] = useState<number>(() => {
    const s = activeStrategy as MinesSavedStrategy;
    if (s?.minesCount) return s.minesCount;
    try {
      const saved = parseInt(localStorage.getItem('mines_count') || '3', 10);
      return saved >= 1 && saved <= 24 ? saved : 3;
    } catch {
      return 3;
    }
  });

  // Auto Bet Parameters
  const [autoSelectedFields, setAutoSelectedFields] = useState<number[]>(() => {
    const s = activeStrategy as MinesSavedStrategy;
    if (Array.isArray(s?.autoFields) && s.autoFields.length > 0) return s.autoFields;
    return [0, 1, 2];
  });
  const [numberOfBets, setNumberOfBets] = useState<string>(() => activeStrategy?.numberOfBets || localStorage.getItem('mines_num_bets') || '0');
  const [onWinAction, setOnWinAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onWinAction || (localStorage.getItem('mines_on_win_action') as 'reset' | 'increase') || 'reset');
  const [onWinPercent, setOnWinPercent] = useState<string>(() => activeStrategy?.onWinPercent || localStorage.getItem('mines_on_win_percent') || '0');
  const [onLossAction, setOnLossAction] = useState<'reset' | 'increase'>(() => activeStrategy?.onLossAction || (localStorage.getItem('mines_on_loss_action') as 'reset' | 'increase') || 'reset');
  const [onLossPercent, setOnLossPercent] = useState<string>(() => activeStrategy?.onLossPercent || localStorage.getItem('mines_on_loss_percent') || '0');
  const [stopProfit, setStopProfit] = useState<string>(() => activeStrategy?.stopProfit || localStorage.getItem('mines_stop_profit') || '0');
  const [stopLoss, setStopLoss] = useState<string>(() => activeStrategy?.stopLoss || localStorage.getItem('mines_stop_loss') || '0');
  const [maxBetCap, setMaxBetCap] = useState<string>(() => activeStrategy?.maxBetCap || localStorage.getItem('mines_max_bet_cap') || '0');
  const [localStopLoseStreak, setLocalStopLoseStreak] = useState<string>(() => activeStrategy?.stopLoseStreak || (stopLoseStreak > 0 ? String(stopLoseStreak) : localStorage.getItem('mines_stop_lose_streak') || '0'));
  const [trailingStop, setTrailingStop] = useState<string>(() => activeStrategy?.trailingStop || localStorage.getItem('mines_trailing_stop') || '0');
  const [stopWager, setStopWager] = useState<string>(() => localStorage.getItem('mines_stop_wager') || '0');
  const [stopBalanceMin, setStopBalanceMin] = useState<string>(() => localStorage.getItem('mines_stop_balance_min') || '0');

  const [switchRules, setSwitchRules] = useState<StrategySwitchRule[]>(() => loadSwitchRules('mines'));
  const [switchRulesEnabled, setSwitchRulesEnabledState] = useState<boolean>(() => getSwitchRulesEnabled('mines'));

  // Active Game State (Manual)
  const [isGameActive, setIsGameActive] = useState<boolean>(false);
  const [activeIdentifier, setActiveIdentifier] = useState<string>(() => {
    try {
      return localStorage.getItem('active_mines_identifier') || '';
    } catch {
      return '';
    }
  });
  const [revealedFields, setRevealedFields] = useState<number[]>([]);
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [currentMultiplier, setCurrentMultiplier] = useState<number>(1.0);
  const [activeAmount, setActiveAmount] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [batchDelayMs, setBatchDelayMs] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('stake_batch_delay_ms'));
      return saved ? Math.max(100, saved) : 100;
    } catch {
      return 100;
    }
  });

  const stopOnWinRef = useRef<boolean>(stopOnWin);
  const stopOnLossRef = useRef<boolean>(stopOnLoss);
  const stopLoseStreakRef = useRef<number>(stopLoseStreak);
  const stopWinStreakRef = useRef<number>(stopWinStreak);

  useEffect(() => { stopOnWinRef.current = stopOnWin; }, [stopOnWin]);
  useEffect(() => { stopOnLossRef.current = stopOnLoss; }, [stopOnLoss]);
  useEffect(() => {
    if (stopLoseStreak > 0) {
      stopLoseStreakRef.current = stopLoseStreak;
      setLocalStopLoseStreak(String(stopLoseStreak));
    }
  }, [stopLoseStreak]);
  useEffect(() => { stopWinStreakRef.current = stopWinStreak; }, [stopWinStreak]);

  // Strategy switching handler
  const handleSelectStrategy = (strat: SavedStrategy) => {
    const m = strat as MinesSavedStrategy;
    activeStrategyRef.current = strat;
    setActiveStrategy(strat);
    setActiveStrategyId('mines', strat.id);

    if (m.minesCount) setMinesCount(m.minesCount);
    if (Array.isArray(m.autoFields) && m.autoFields.length > 0) {
      setAutoSelectedFields(m.autoFields);
    }
    setBetAmount(strat.betAmount !== undefined ? strat.betAmount : '0');
    setNumberOfBets(strat.numberOfBets !== undefined ? strat.numberOfBets : '0');
    setOnWinAction(strat.onWinAction || 'reset');
    setOnWinPercent(strat.onWinPercent !== undefined ? strat.onWinPercent : '0');
    setOnLossAction(strat.onLossAction || 'reset');
    setOnLossPercent(strat.onLossPercent !== undefined ? strat.onLossPercent : '0');
    setStopProfit(strat.stopProfit !== undefined ? strat.stopProfit : '0');
    setStopLoss(strat.stopLoss !== undefined ? strat.stopLoss : '0');
    setMaxBetCap(strat.maxBetCap !== undefined ? strat.maxBetCap : '0');
    setLocalStopLoseStreak(strat.stopLoseStreak !== undefined ? strat.stopLoseStreak : '0');
    setTrailingStop(strat.trailingStop !== undefined ? strat.trailingStop : '0');
    setStopWager(strat.stopWager !== undefined ? strat.stopWager : '0');
    setStopBalanceMin(strat.stopBalanceMin !== undefined ? strat.stopBalanceMin : '0');

    // Unconditionally update triggers so Strategy 2 resets Strategy 1's stop triggers
    onUpdateTriggers?.({
      stopOnWin: !!strat.stopOnWin,
      stopOnLoss: !!strat.stopOnLoss,
      stopLoseStreak: parseInt(strat.stopLoseStreak || '0', 10) || 0,
      stopWinStreak: parseInt(strat.stopWinStreak || '0', 10) || 0,
    });

    onShowToast?.('Strategi Dipilih', 'ON', `Mengaktifkan strategi "${strat.name}"`);
  };

  const handleStartAutoBet = () => {
    if (!onToggleAutobet) return;
    const currentStrat = (activeStrategy || strategies.find((s) => s.id === getActiveStrategyId('mines')) || strategies[0]) as MinesSavedStrategy | undefined;

    const stratBaseAmount = currentStrat?.betAmount !== undefined && currentStrat.betAmount !== ''
      ? parseFloat(currentStrat.betAmount) || 0
      : (parseFloat(betAmount) || 0);
    const stratOnWinAction = currentStrat?.onWinAction || onWinAction || 'reset';
    const stratOnWinPercent = currentStrat?.onWinPercent !== undefined
      ? parseFloat(String(currentStrat.onWinPercent)) || 0
      : (parseFloat(onWinPercent) || 0);
    const stratOnWinEveryCount = currentStrat?.onWinEveryCount !== undefined
      ? parseInt(String(currentStrat.onWinEveryCount), 10) || 1
      : 1;
    const stratOnLossAction = currentStrat?.onLossAction || onLossAction || 'reset';
    const stratOnLossPercent = currentStrat?.onLossPercent !== undefined
      ? parseFloat(String(currentStrat.onLossPercent)) || 0
      : (parseFloat(onLossPercent) || 0);
    const stratOnLossEveryCount = currentStrat?.onLossEveryCount !== undefined
      ? parseInt(String(currentStrat.onLossEveryCount), 10) || 1
      : 1;
    const numBets = currentStrat?.numberOfBets !== undefined
      ? parseInt(currentStrat.numberOfBets, 10) || 0
      : (parseInt(numberOfBets, 10) || 0);

    const autoMinesCount = currentStrat?.minesCount || minesCount || 3;
    const autoFields = Array.isArray(currentStrat?.autoFields) && currentStrat.autoFields.length > 0
      ? currentStrat.autoFields
      : autoSelectedFields;

    const autoConfig: AutobetConfig = {
      enabled: true,
      baseAmount: stratBaseAmount,
      numberOfBets: Math.max(0, numBets),
      betsPlaced: 0,
      onWinAction: stratOnWinAction,
      onWinPercent: stratOnWinPercent,
      onWinEveryCount: stratOnWinEveryCount,
      onLossAction: stratOnLossAction,
      onLossPercent: stratOnLossPercent,
      onLossEveryCount: stratOnLossEveryCount,
      stopProfit: parseFloat(stopProfit) || 0,
      stopLoss: parseFloat(stopLoss) || 0,
      maxBetCap: parseFloat(maxBetCap) || 0,
      stopLoseStreak: parseInt(localStopLoseStreak, 10) || stopLoseStreak || 0,
      maxConsecutiveLosses: parseInt(localStopLoseStreak, 10) || stopLoseStreak || 0,
      trailingStop: parseFloat(trailingStop) || 0,
      stopWager: parseFloat(stopWager) || 0,
      stopBalanceMin: parseFloat(stopBalanceMin) || 0,
      batchDelayMs,
      onBetAmountChange: (amt) => setBetAmount(amt.toString()),
      switchRulesEnabled: externalSwitchRulesEnabled || switchRulesEnabled,
      switchRules,
      savedStrategies: strategies,
      activeStrategyId: currentStrat?.id || activeStrategy?.id,
      onSwitchStrategy: (targetStrat) => {
        handleSelectStrategy(targetStrat);
      },
      getLiveTriggers: () => ({
        stopOnWin: stopOnWinRef.current,
        stopOnLoss: stopOnLossRef.current,
        stopLoseStreak: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        maxConsecutiveLosses: stopLoseStreakRef.current > 0 ? stopLoseStreakRef.current : (parseInt(localStopLoseStreak, 10) || 0),
        stopWinStreak: stopWinStreakRef.current,
        stopProfit: parseFloat(stopProfit) || 0,
        stopLoss: parseFloat(stopLoss) || 0,
        maxBetCap: parseFloat(maxBetCap) || 0,
        trailingStop: parseFloat(trailingStop) || 0,
        stopWager: parseFloat(stopWager) || 0,
        stopBalanceMin: parseFloat(stopBalanceMin) || 0,
        switchRules,
        switchRulesEnabled: externalSwitchRulesEnabled || switchRulesEnabled,
        activeStrategy: activeStrategyRef.current,
      }),
    };

    onToggleAutobet(autoConfig, autoMinesCount, autoFields);
  };

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('mines_bet_amount', betAmount);
      localStorage.setItem('mines_count', String(minesCount));
      localStorage.setItem('mines_num_bets', numberOfBets);
      localStorage.setItem('mines_on_win_action', onWinAction);
      localStorage.setItem('mines_on_win_percent', onWinPercent);
      localStorage.setItem('mines_on_loss_action', onLossAction);
      localStorage.setItem('mines_on_loss_percent', onLossPercent);
      localStorage.setItem('mines_stop_profit', stopProfit);
      localStorage.setItem('mines_stop_loss', stopLoss);
      localStorage.setItem('stake_batch_delay_ms', String(batchDelayMs));
    } catch {}
  }, [betAmount, minesCount, numberOfBets, onWinAction, onWinPercent, onLossAction, onLossPercent, stopProfit, stopLoss, batchDelayMs]);

  // Check active mines bet on mount
  useEffect(() => {
    if (!config?.token) return;
    fetchActiveMines(config)
      .then((active) => {
        if (active && active.active) {
          setIsGameActive(true);
          setRevealedFields(active.revealedFields);
          setCurrentMultiplier(active.payoutMultiplier);
          setActiveAmount(active.amount);
          setMinesCount(active.minesCount);
          onShowToast?.('Sesi Mines Aktif Ditemukan', 'INFO', `Melanjutkan sesi aktif (${active.revealedFields.length} petak dibuka)`);
        }
      })
      .catch(() => {});
  }, [config?.token]);

  const parsedAmount = useMemo(() => {
    const val = parseFloat(betAmount.replace(',', '.'));
    return isNaN(val) || val < 0 ? 0 : val;
  }, [betAmount]);

  const currentProfit = useMemo(() => {
    if (!isGameActive || currentMultiplier <= 1) return 0;
    return activeAmount * currentMultiplier - activeAmount;
  }, [isGameActive, currentMultiplier, activeAmount]);

  // Start manual bet
  const handleStartManualGame = async () => {
    if (!config.token) {
      onShowToast?.('Token Diperlukan', 'OFF', 'Masukkan Stake Session Token di Pengaturan.');
      return;
    }
    if (parsedAmount > balance) {
      onShowToast?.('Saldo Tidak Cukup', 'OFF', 'Jumlah taruhan melebihi saldo koin aktif.');
      return;
    }

    try {
      setIsProcessing(true);
      const id = Math.random().toString(36).substring(2, 15);
      setActiveIdentifier(id);
      try {
        localStorage.setItem('active_mines_identifier', id);
      } catch {}
      const res = await playMinesBet(parsedAmount, currency, minesCount, id, config);
      setIsGameActive(res.active);
      setActiveAmount(parsedAmount);
      setRevealedFields(res.revealedFields || []);
      setMinePositions([]);
      setCurrentMultiplier(res.payoutMultiplier || 1.0);
      onRefreshBalance?.();
    } catch (err: any) {
      onShowToast?.('Gagal Memulai Mines', 'OFF', err.message || 'Error memulai permainan');
    } finally {
      setIsProcessing(false);
    }
  };

  // Step on a tile
  const handleTileClick = async (index: number) => {
    if (!isGameActive || isProcessing || revealedFields.includes(index)) return;

    try {
      setIsProcessing(true);
      const res = await revealMinesTile(index, activeIdentifier, config);
      setRevealedFields(res.revealedFields || []);
      setCurrentMultiplier(res.payoutMultiplier || 1.0);

      if (!res.active) {
        // Round ended (hit mine or cashed out)
        setIsGameActive(false);
        setMinePositions(res.minePositions || []);
        if (res.hitMineIndex !== undefined) {
          onShowToast?.('Boom! Kena Ranjau', 'OFF', `Anda menginjak ranjau pada petak #${index + 1}.`);
          onBetFinished({
            id: res.id,
            game: 'mines',
            currency,
            betAmount: activeAmount,
            target: minesCount,
            multiplier: 0,
            rollResult: res.revealedFields.length,
            won: false,
            profit: -activeAmount,
            timestamp: Date.now(),
            durationMs: res.executionMs,
            isLiveStake: true,
          });
        }
        onRefreshBalance?.();
      }
    } catch (err: any) {
      onShowToast?.('Gagal Membuka Petak', 'OFF', err.message || 'Error membuka petak');
    } finally {
      setIsProcessing(false);
    }
  };

  // Cashout manual
  const handleCashout = async () => {
    if (!isGameActive || isProcessing || revealedFields.length === 0) return;

    try {
      setIsProcessing(true);
      const res = await cashoutMines(activeIdentifier, config);
      setIsGameActive(false);
      setMinePositions(res.minePositions || []);
      const profit = res.payout - activeAmount;
      onShowToast?.('Cashout Berhasil!', 'ON', `Menang: +${profit.toFixed(8)} ${currency.toUpperCase()} (${res.payoutMultiplier.toFixed(2)}×)`);
      onBetFinished({
        id: res.id,
        game: 'mines',
        currency,
        betAmount: activeAmount,
        target: minesCount,
        multiplier: res.payoutMultiplier,
        rollResult: res.revealedFields.length,
        won: true,
        profit,
        timestamp: Date.now(),
        durationMs: res.executionMs,
        isLiveStake: true,
      });
      onRefreshBalance?.();
    } catch (err: any) {
      onShowToast?.('Gagal Cashout', 'OFF', err.message || 'Error cashout');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 font-sans">
      {/* Top Game Header Bar */}
      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-xs flex items-center justify-between gap-3 font-sans">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs shrink-0">
            <Bomb className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-bold font-mono text-zinc-900 tracking-tight">
                MINES
              </h2>
              <span className="text-[9px] bg-rose-100 text-rose-800 border border-rose-200 font-mono font-bold px-1.5 py-0.2 rounded">
                STAKE ORIGINAL
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-zinc-500 font-mono">
              Buka petak aman hindari ranjau • Max Win 5,000,000.00× • House Edge {houseEdgePercent}%
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-5 shadow-xs flex flex-col gap-3 font-mono text-zinc-900">
        {/* MODE TABS */}
        <div className="bg-zinc-200/80 p-1 rounded-full grid grid-cols-2 gap-1 w-full max-w-sm mx-auto">
        <button
          type="button"
          onClick={() => !autobetRunning && setTabMode('manual')}
          disabled={autobetRunning}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'manual' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Manual</span>
        </button>
        <button
          type="button"
          onClick={() => setTabMode('auto')}
          className={`py-2 px-6 rounded-full text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            tabMode === 'auto' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-600 hover:text-zinc-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>Otomatis</span>
          {autobetRunning && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
        </button>
      </div>

      {/* AUTO BET PROGRESS BANNER */}
      {autobetRunning && batchProgress && (
        <div className="bg-emerald-600 text-white rounded-xl p-3 flex items-center justify-between text-xs shadow-md">
          <div className="space-y-0.5">
            <span className="font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>Auto Bet Mines: Putaran {batchProgress.currentRound} / {batchProgress.totalRounds || '∞'}</span>
              {batchProgress.activeStrategyName && (
                <span className="bg-emerald-700/80 px-1.5 py-0.5 rounded text-[10px] font-black border border-emerald-400/40">
                  {batchProgress.activeStrategyName}
                </span>
              )}
            </span>
            <span className="text-[10px] text-emerald-100 flex items-center gap-2 flex-wrap">
              <span>Profit: <strong>{batchProgress.runningProfit >= 0 ? `+${batchProgress.runningProfit}` : batchProgress.runningProfit} {currency.toUpperCase()}</strong></span>
              {batchProgress.totalWagered !== undefined && <span>• Wager: <strong>{batchProgress.totalWagered} {currency.toUpperCase()}</strong></span>}
            </span>
          </div>
          <button
            type="button"
            onClick={onStopAutobet}
            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer transition flex items-center gap-1"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Berhenti</span>
          </button>
        </div>
      )}

      {/* 5x5 MINES GRID (ONLY IN MANUAL MODE) */}
      {tabMode === 'manual' && (
        <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 flex flex-col items-center justify-center gap-3">
          <div className="w-full flex items-center justify-between text-xs">
            <span className="text-zinc-500 font-bold uppercase">
              Ranjau: <strong className="text-zinc-900">{minesCount}</strong>
            </span>
            <span className="text-zinc-500 font-bold uppercase">
              Pengali: <strong className="text-emerald-600">{currentMultiplier.toFixed(2)}×</strong>
            </span>
          </div>

          <div className="grid grid-cols-5 gap-2 sm:gap-2.5 w-full max-w-[340px]">
            {Array.from({ length: 25 }).map((_, idx) => {
              const isRevealed = revealedFields.includes(idx);
              const isMine = minePositions.includes(idx);

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleTileClick(idx)}
                  disabled={isProcessing || !isGameActive}
                  className={`aspect-square rounded-xl flex items-center justify-center text-sm font-bold transition shadow-xs cursor-pointer border ${
                    isRevealed
                      ? 'bg-emerald-500 border-emerald-600 text-white'
                      : isMine
                      ? 'bg-rose-600 border-rose-700 text-white animate-bounce'
                      : 'bg-white hover:bg-zinc-100 border-zinc-200 text-zinc-400'
                  }`}
                >
                  {isRevealed ? (
                    <Diamond className="w-5 h-5 text-white" />
                  ) : isMine ? (
                    <Bomb className="w-5 h-5 text-white" />
                  ) : (
                    <span className="text-[10px] text-zinc-300 font-mono">{idx + 1}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* MANUAL BET CONTROLS */}
      {tabMode === 'manual' && (
        <div className="space-y-3">
          <div className="flex flex-col gap-2.5 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
            <div className="flex items-center justify-between text-xs font-bold text-zinc-700">
              <span className="text-zinc-900 uppercase">Jumlah Taruhan</span>
              <span className="text-[10px] text-zinc-500 font-normal">
                Saldo: <strong className="text-zinc-900">{balance.toFixed(8)} {currency.toUpperCase()}</strong>
              </span>
            </div>
            <div className="flex items-center gap-1">
              <input
                type="text"
                placeholder="0"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                disabled={isGameActive || autobetRunning}
                className="w-full bg-white border border-zinc-200 rounded-xl px-3 py-2 font-mono text-xs font-bold text-zinc-900 outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={() => setBetAmount('0')}
                disabled={isGameActive || autobetRunning}
                className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold cursor-pointer"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => setBetAmount((prev) => (Math.max(0, (parseFloat(prev) || 0) / 2)).toFixed(8))}
                disabled={isGameActive || autobetRunning}
                className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold cursor-pointer"
              >
                ½
              </button>
              <button
                type="button"
                onClick={() => setBetAmount((prev) => ((parseFloat(prev) || 0) * 2).toFixed(8))}
                disabled={isGameActive || autobetRunning}
                className="px-2.5 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-100 text-xs font-bold cursor-pointer"
              >
                2×
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
            <label className="text-[10px] text-zinc-500 font-bold uppercase block">
              Jumlah Ranjau (1-24)
            </label>
            <select
              value={minesCount}
              onChange={(e) => setMinesCount(parseInt(e.target.value, 10))}
              disabled={isGameActive || autobetRunning}
              className="bg-white border border-zinc-200 rounded-xl px-3 py-2 text-xs font-bold font-mono outline-none focus:border-emerald-500"
            >
              {Array.from({ length: 24 }).map((_, i) => (
                <option key={i + 1} value={i + 1}>
                  {i + 1} Ranjau ({25 - (i + 1)} Berlian)
                </option>
              ))}
            </select>
          </div>

          {/* MAIN ACTION BUTTON */}
          {!isGameActive ? (
            <button
              type="button"
              onClick={handleStartManualGame}
              disabled={isProcessing}
              className="w-full py-3.5 rounded-2xl font-mono font-bold text-sm bg-amber-500 hover:bg-amber-600 text-zinc-950 shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
            >
              <Bomb className="w-4 h-4 fill-current" />
              <span>MULAI PERMAINAN MINES</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleCashout}
              disabled={isProcessing || revealedFields.length === 0}
              className="w-full py-3.5 rounded-2xl font-mono font-bold text-sm bg-emerald-600 hover:bg-emerald-700 text-white shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
            >
              <span>CASHOUT: +{currentProfit.toFixed(8)} {currency.toUpperCase()} ({currentMultiplier.toFixed(2)}×)</span>
            </button>
          )}
        </div>
      )}

      {/* AUTO BET STRATEGY MANAGER */}
      {tabMode === 'auto' && (
        <AutoBetStrategyManager
          game="mines"
          currency={currency}
          strategies={strategies}
          activeStrategy={activeStrategy}
          onSelectStrategy={handleSelectStrategy}
          onSaveStrategy={(s) => {
            const list = strategies.filter((item) => item.id !== s.id);
            const updated = [...list, s];
            setStrategies(updated);
            saveSavedStrategies('mines', updated);
            setActiveStrategy(s);
          }}
          onDeleteStrategy={(id) => {
            const updated = strategies.filter((item) => item.id !== id);
            setStrategies(updated);
            saveSavedStrategies('mines', updated);
            if (activeStrategy?.id === id) {
              setActiveStrategy(updated[0] || null);
            }
          }}
          onImportStrategies={(imported) => {
            const updated = [...strategies, ...imported];
            setStrategies(updated);
            saveSavedStrategies('mines', updated);
          }}
          autobetRunning={autobetRunning}
          onShowToast={onShowToast}
          stopProfit={stopProfit}
          onChangeStopProfit={setStopProfit}
          stopLoss={stopLoss}
          onChangeStopLoss={setStopLoss}
          maxBetCap={maxBetCap}
          onChangeMaxBetCap={setMaxBetCap}
          maxConsecutiveLosses={localStopLoseStreak}
          onChangeMaxConsecutiveLosses={setLocalStopLoseStreak}
          trailingStop={trailingStop}
          onChangeTrailingStop={setTrailingStop}
          stopWager={stopWager}
          onChangeStopWager={setStopWager}
          stopBalanceMin={stopBalanceMin}
          onChangeStopBalanceMin={setStopBalanceMin}
          stopOnWin={stopOnWin}
          onChangeStopOnWin={(val) => onUpdateTriggers?.({ stopOnWin: val })}
          stopOnLoss={stopOnLoss}
          onChangeStopOnLoss={(val) => onUpdateTriggers?.({ stopOnLoss: val })}
          stopWinStreak={String(stopWinStreak)}
          onChangeStopWinStreak={(val) => onUpdateTriggers?.({ stopWinStreak: parseInt(val, 10) || 0 })}
          switchRules={switchRules}
          onChangeSwitchRules={setSwitchRules}
          switchRulesEnabled={externalSwitchRulesEnabled || switchRulesEnabled}
          onToggleSwitchRulesEnabled={setSwitchRulesEnabledState}
          renderStrategyForm={(temp, setTemp) => {
            const mStrat = temp as MinesSavedStrategy;
            const currentMines = mStrat.minesCount || 3;
            const currentAutoFields = Array.isArray(mStrat.autoFields) && mStrat.autoFields.length > 0 ? mStrat.autoFields : [0, 1, 2];
            const diamondsCount = currentAutoFields.length;

            let prob = 1.0;
            for (let i = 0; i < diamondsCount; i++) {
              prob *= (25 - currentMines - i) / (25 - i);
            }
            const edgeFactor = (100 - houseEdgePercent) / 100;
            const stratMultiplier = prob > 0 ? (edgeFactor / prob).toFixed(2) : '1.00';

            const toggleField = (fieldIdx: number) => {
              let nextFields: number[];
              if (currentAutoFields.includes(fieldIdx)) {
                if (currentAutoFields.length <= 1) return;
                nextFields = currentAutoFields.filter((f) => f !== fieldIdx);
              } else {
                if (currentAutoFields.length >= 25 - currentMines) return;
                nextFields = [...currentAutoFields, fieldIdx];
              }
              setTemp({ ...mStrat, autoFields: nextFields });
            };

            const handleDiamondsCountChange = (count: number) => {
              const validCount = Math.max(1, Math.min(25 - currentMines, count));
              const newFields = Array.from({ length: validCount }, (_, i) => i);
              setTemp({ ...mStrat, autoFields: newFields });
            };

            return (
              <div className="space-y-3 font-mono">
                {/* Base Bet Amount */}
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500 font-bold uppercase block">
                    Base Bet Amount
                  </label>
                  <input
                    type="text"
                    value={mStrat.betAmount}
                    onChange={(e) => setTemp({ ...mStrat, betAmount: e.target.value })}
                    placeholder="0.00000000"
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-1.5 text-xs font-bold text-zinc-900 outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                {/* Grid: Jumlah Ranjau & Diamond Count */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 font-bold uppercase block">
                      Jumlah Ranjau
                    </label>
                    <select
                      value={currentMines}
                      onChange={(e) => {
                        const newMines = parseInt(e.target.value, 10);
                        const maxSafe = 25 - newMines;
                        const safeFields = currentAutoFields.filter((f) => f < maxSafe).slice(0, maxSafe);
                        const finalFields = safeFields.length > 0 ? safeFields : [0];
                        setTemp({ ...mStrat, minesCount: newMines, autoFields: finalFields });
                      }}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-zinc-900 outline-none focus:border-amber-500"
                    >
                      {Array.from({ length: 24 }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1} Ranjau
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 font-bold uppercase block">
                      Jumlah Diamond (Pola)
                    </label>
                    <select
                      value={diamondsCount}
                      onChange={(e) => handleDiamondsCountChange(parseInt(e.target.value, 10))}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-zinc-900 outline-none focus:border-amber-500"
                    >
                      {Array.from({ length: 25 - currentMines }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1} Diamond
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Multiplier Info Box */}
                <div className="bg-amber-50/80 border border-amber-200/80 rounded-xl p-2.5 flex items-center justify-between gap-2">
                  <div className="text-[11px] text-amber-950 font-semibold">
                    <span className="text-zinc-600 block text-[10px]">Multiplier Target Strategi:</span>
                    <strong>{currentMines} Ranjau</strong> + <strong>{diamondsCount} Diamond</strong>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-black text-amber-600 font-mono">{stratMultiplier}×</span>
                  </div>
                </div>

                {/* Mini 5x5 Pattern Selector */}
                <div className="space-y-1 pt-1 border-t border-zinc-100">
                  <div className="flex items-center justify-between text-[10px] font-bold text-zinc-600">
                    <span>Tentukan Pola Petak ({currentAutoFields.length} Dipilih):</span>
                    <button
                      type="button"
                      onClick={() => handleDiamondsCountChange(3)}
                      className="text-amber-600 hover:underline cursor-pointer"
                    >
                      Reset (3 Petak)
                    </button>
                  </div>
                  <div className="grid grid-cols-5 gap-1 max-w-[190px] mx-auto py-1">
                    {Array.from({ length: 25 }).map((_, idx) => {
                      const isSelected = currentAutoFields.includes(idx);
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => toggleField(idx)}
                          className={`w-7 h-7 rounded-lg font-mono text-[10px] font-extrabold flex items-center justify-center transition cursor-pointer ${
                            isSelected
                              ? 'bg-amber-500 text-zinc-950 border border-amber-600 shadow-2xs scale-105'
                              : 'bg-zinc-100 text-zinc-400 hover:bg-zinc-200 border border-zinc-200'
                          }`}
                          title={`Petak ${idx + 1}`}
                        >
                          {isSelected ? '💎' : idx + 1}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <AutoBetStrategyControls
                  onWinAction={mStrat.onWinAction}
                  onChangeOnWinAction={(val) => setTemp({ ...mStrat, onWinAction: val })}
                  onWinPercent={mStrat.onWinPercent}
                  onChangeOnWinPercent={(val) => setTemp({ ...mStrat, onWinPercent: val })}
                  onWinEveryCount={mStrat.onWinEveryCount}
                  onChangeOnWinEveryCount={(val) => setTemp({ ...mStrat, onWinEveryCount: val })}
                  onLossAction={mStrat.onLossAction}
                  onChangeOnLossAction={(val) => setTemp({ ...mStrat, onLossAction: val })}
                  onLossPercent={mStrat.onLossPercent}
                  onChangeOnLossPercent={(val) => setTemp({ ...mStrat, onLossPercent: val })}
                  onLossEveryCount={mStrat.onLossEveryCount}
                  onChangeOnLossEveryCount={(val) => setTemp({ ...mStrat, onLossEveryCount: val })}
                  currency={currency}
                />
              </div>
            );
          }}
        />
      )}

      {/* AUTO BET ACTION BUTTON */}
      {tabMode === 'auto' && (
        <button
          type="button"
          onClick={() => {
            if (autobetRunning) {
              onStopAutobet?.();
              return;
            }
            if (isRolling) return; // Wait for last bet
            if (!activeStrategy || strategies.length === 0) {
              onShowToast?.('Strategi Diperlukan', 'OFF', 'Pilih atau tambahkan strategi terlebih dahulu.');
              return;
            }
            handleStartAutoBet();
          }}
          disabled={(!autobetRunning && isRolling) || (!autobetRunning && (!activeStrategy || strategies.length === 0))}
          className={`w-full py-3.5 rounded-2xl font-mono font-bold text-sm shadow-md flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
            autobetRunning || (isRolling && !autobetRunning) ? 'bg-rose-600 text-white hover:bg-rose-700' : 'bg-emerald-600 text-white hover:bg-emerald-700'
          }`}
        >
          {autobetRunning ? (
            <>
              <Square className="w-4 h-4 fill-current" />
              <span>HENTIKAN OTOMATIS</span>
            </>
          ) : isRolling ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>MENGHENTIKAN...</span>
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 fill-current text-amber-300" />
              <span>{!activeStrategy || strategies.length === 0 ? 'TAMBAH STRATEGI DAHULU' : 'JALANKAN'}</span>
            </>
          )}
        </button>
      )}

      {/* FOOTER CONTROLS TOOLBAR */}
      <GameFooterToolbar
        batchDelayMs={batchDelayMs}
        onBatchDelayChange={setBatchDelayMs}
        autobetRunning={autobetRunning}
        showHistoryStats={showHistoryStats}
        onToggleShowStats={onToggleShowStats}
        accentColor="emerald"
      />
    </div>
  </div>
);
};
