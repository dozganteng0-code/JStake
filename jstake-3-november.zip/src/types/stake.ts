export type RoutingMode = 'direct' | 'cors-proxy' | 'proxy';

export type GameType = 'dice' | 'limbo' | 'plinko' | 'mines' | 'diamonds' | 'keno' | 'dragontower';

export type DiceCondition = 'above' | 'below';

export type PlinkoRisk = 'low' | 'medium' | 'high' | 'expert';
export type PlinkoRows = 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16;

export type KenoRisk = 'low' | 'classic' | 'medium' | 'high';

export interface StakeConfig {
  token: string;
  endpoint: string;
  cookie: string;
  currency: string;
  routingMode: RoutingMode;
  corsProxyUrl?: string; // Optional custom CORS proxy URL, defaults to https://corsproxy.io/?url=
  houseEdgePercent: number; // default 1.0%
  hideZeroBalances: boolean; // Toggle: Sembunyikan saldo nol
  customHeadersJson?: string;
  diceQueryOverride?: string;
  limboQueryOverride?: string;
  plinkoQueryOverride?: string;
  minesQueryOverride?: string;
  diamondsQueryOverride?: string;
  kenoQueryOverride?: string;
  balanceQueryOverride?: string;
  historyLimit?: 10 | 20;
}

export interface UserBalance {
  currency: string;
  amount: number;
}

export interface BetResult {
  id: string;
  game: GameType;
  currency: string;
  betAmount: number;
  target: number; // Dice target number (0-100) or Limbo target multiplier (1.01x+)
  condition?: DiceCondition; // For dice
  multiplier: number; // Effective payout multiplier on win
  rollResult: number; // Number rolled or crash multiplier
  won: boolean;
  profit: number; // Positive if won, negative (equals -betAmount) if lost
  timestamp: number;
  durationMs: number;
  betId?: string;
  iid?: string;
  clientSeed?: string;
  serverSeedHash?: string;
  nonce?: number;
  isLiveStake?: boolean;
  minesCount?: number;
  diamondsCount?: number;
  revealedFields?: number[];
  minePositions?: number[];
  diamonds?: string[];
  combinationName?: string;
  kenoSelectedNumbers?: number[];
  kenoDrawnNumbers?: number[];
  kenoRisk?: KenoRisk;
  kenoHitsCount?: number;
}

export interface SessionStats {
  totalBets: number;
  wins: number;
  losses: number;
  totalWagered: number;
  totalWonCurrency: number;
  totalLostCurrency: number;
  netProfit: number;
  winRate: number;
}

export interface BatchProgress {
  currentRound: number;
  totalRounds: number; // 0 for infinite
  runningProfit: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  isActive: boolean;
  activeStrategyName?: string;
  strategyProfit?: number;
  totalWagered?: number;
  peakProfit?: number; // Puncak profit tertinggi selama batch berjalan
}

export type StrategySwitchConditionType =
  | 'profit_gte'      // Jika profit pada strategi saat ini >= nominal
  | 'loss_gte'        // Jika kerugian (drawdown) pada strategi saat ini >= nominal
  | 'win_streak_gte'  // Jika win streak >= jumlah
  | 'loss_streak_gte' // Jika lose streak >= jumlah
  | 'bets_count_gte'  // Jika jumlah putaran taruhan pada strategi saat ini >= jumlah
  | 'wager_gte';      // Jika akumulasi total wager pada strategi saat ini >= nominal

export interface StrategySwitchRule {
  id: string;
  enabled: boolean;
  conditionType: StrategySwitchConditionType;
  threshold: number; // Nilai target (nominal koin atau hitungan streak)
  targetStrategyId: string; // ID strategi tujuan untuk berpindah
  targetStrategyName?: string;
  resetCountersOnSwitch: boolean; // Reset acuan hitungan profit/loss saat berpindah (default: true)
}

export interface AutobetConfig {
  enabled: boolean;
  baseAmount: number;
  numberOfBets: number; // 0 for infinite, or 20, 50, 100, etc.
  betsPlaced: number;
  onWinAction: 'reset' | 'increase';
  onWinPercent: number;
  onWinEveryCount?: number; // default 1 (Setiap N kali menang)
  onLossAction: 'reset' | 'increase';
  onLossPercent: number;
  onLossEveryCount?: number; // default 1 (Setiap N kali kalah)
  stopProfit: number; // 0 for none
  stopLoss: number; // 0 for none
  stopWager?: number; // 0 for none: Stop if total wagered reaches this amount
  stopBalanceMin?: number; // 0 for none: Stop if balance <= this amount
  stopBalanceMax?: number; // 0 for none: Stop if balance >= this amount
  maxBetCap?: number; // 0 for none: Pagu taruhan tertinggi, nominal bet tidak akan melebihi angka ini
  maxConsecutiveLosses?: number; // 0 for none: Batas kalah beruntun darurat
  trailingStop?: number; // 0 for none: Jika profit turun sebesar nilai ini dari puncak tertinggi, bot berhenti mengunci profit
  stopOnWin?: boolean; // Quick live trigger: stop on win
  stopOnLoss?: boolean; // Quick live trigger: stop on loss
  stopLoseStreak?: number; // 0 for disabled, e.g. 10
  stopWinStreak?: number; // 0 for disabled, e.g. 5
  stopHitMultiplier?: number; // 0 for disabled; stops if plinko lands on this multiplier or higher
  batchDelayMs?: number; // Delay between rounds in ms to prevent rate limiting (e.g. 400ms)
  onBetAmountChange?: (amount: number) => void;
  // Dynamic Strategy Switching
  switchRulesEnabled?: boolean;
  switchRules?: StrategySwitchRule[];
  savedStrategies?: SavedStrategy[];
  activeStrategyId?: string;
  onSwitchStrategy?: (targetStrategy: SavedStrategy, rule: StrategySwitchRule) => void;
  getLiveTriggers?: () => {
    stopOnWin: boolean;
    stopOnLoss: boolean;
    stopLoseStreak: number;
    stopWinStreak: number;
    stopHitMultiplier?: number;
    stopProfit?: number;
    stopLoss?: number;
    stopWager?: number;
    stopBalanceMin?: number;
    stopBalanceMax?: number;
    maxBetCap?: number;
    maxConsecutiveLosses?: number;
    trailingStop?: number;
    switchRules?: StrategySwitchRule[];
    switchRulesEnabled?: boolean;
    activeStrategy?: SavedStrategy | null;
  };
}

export interface BaseSavedStrategy {
  id: string;
  name: string;
  game: GameType;
  createdAt: number;
  updatedAt: number;
  betAmount: string;
  numberOfBets: string;
  onWinAction: 'reset' | 'increase';
  onWinPercent: string;
  onWinEveryCount?: string; // default '1'
  onLossAction: 'reset' | 'increase';
  onLossPercent: string;
  onLossEveryCount?: string; // default '1'
  stopProfit: string;
  stopLoss: string;
  maxBetCap?: string;
  stopLoseStreak?: string;
  stopWinStreak?: string;
  stopOnWin?: boolean;
  stopOnLoss?: boolean;
  trailingStop?: string;
  stopWager?: string;
  stopBalanceMin?: string;
  maxConsecutiveLosses?: string;
}

export interface DiceSavedStrategy extends BaseSavedStrategy {
  game: 'dice';
  condition: DiceCondition;
  target: number;
}

export interface LimboSavedStrategy extends BaseSavedStrategy {
  game: 'limbo';
  targetMultiplier: number;
}

export interface PlinkoSavedStrategy extends BaseSavedStrategy {
  game: 'plinko';
  risk: PlinkoRisk;
  rows: PlinkoRows;
  stopHitMultiplier?: number;
}

export interface MinesSavedStrategy extends BaseSavedStrategy {
  game: 'mines';
  minesCount: number;
  autoFields: number[];
}

export interface DiamondsSavedStrategy extends BaseSavedStrategy {
  game: 'diamonds';
}

export interface KenoSavedStrategy extends BaseSavedStrategy {
  game: 'keno';
  risk: KenoRisk;
  selectedNumbers: number[];
}

export type SavedStrategy =
  | DiceSavedStrategy
  | LimboSavedStrategy
  | PlinkoSavedStrategy
  | MinesSavedStrategy
  | DiamondsSavedStrategy
  | KenoSavedStrategy;

