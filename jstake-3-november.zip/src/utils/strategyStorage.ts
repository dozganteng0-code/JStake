import { GameType, SavedStrategy, StrategySwitchRule } from '../types/stake';

const STRATEGIES_PREFIX = 'stake_strategies_';
const ACTIVE_STRATEGY_PREFIX = 'stake_active_strategy_';
const SWITCH_RULES_PREFIX = 'stake_switch_rules_';
const SWITCH_RULES_ENABLED_PREFIX = 'stake_switch_rules_enabled_';

function getStrategiesKey(game: GameType): string {
  return `${STRATEGIES_PREFIX}${game}`;
}

function getActiveStrategyKey(game: GameType): string {
  return `${ACTIVE_STRATEGY_PREFIX}${game}`;
}

function getSwitchRulesKey(game: GameType): string {
  return `${SWITCH_RULES_PREFIX}${game}`;
}

function getSwitchRulesEnabledKey(game: GameType): string {
  return `${SWITCH_RULES_ENABLED_PREFIX}${game}`;
}

export function loadSwitchRules(game: GameType): StrategySwitchRule[] {
  try {
    const raw = localStorage.getItem(getSwitchRulesKey(game));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveSwitchRules(game: GameType, rules: StrategySwitchRule[]): void {
  try {
    localStorage.setItem(getSwitchRulesKey(game), JSON.stringify(rules));
  } catch {
    // ignore
  }
}

export function getSwitchRulesEnabled(game: GameType): boolean {
  try {
    const val = localStorage.getItem(getSwitchRulesEnabledKey(game));
    return val ? val === 'true' : false;
  } catch {
    return false;
  }
}

export function setSwitchRulesEnabled(game: GameType, enabled: boolean): void {
  try {
    localStorage.setItem(getSwitchRulesEnabledKey(game), String(enabled));
  } catch {
    // ignore
  }
}

export function loadSavedStrategies(game: GameType): SavedStrategy[] {
  try {
    const raw = localStorage.getItem(getStrategiesKey(game));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter((s) => typeof s === 'object' && !!s && !s.id?.includes('_preset_'));
      }
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveSavedStrategies(game: GameType, list: SavedStrategy[]): void {
  try {
    localStorage.setItem(getStrategiesKey(game), JSON.stringify(list));
  } catch {
    // ignore
  }
}

export function getActiveStrategyId(game: GameType): string | null {
  try {
    return localStorage.getItem(getActiveStrategyKey(game));
  } catch {
    return null;
  }
}

export function setActiveStrategyId(game: GameType, id: string): void {
  try {
    localStorage.setItem(getActiveStrategyKey(game), id);
  } catch {
    // ignore
  }
}

export function exportStrategiesToJson(strategies: SavedStrategy[] | SavedStrategy): string {
  const payload = {
    version: '1.0',
    app: 'JStkBot',
    exportedAt: new Date().toISOString(),
    strategies: Array.isArray(strategies) ? strategies : [strategies],
  };
  return JSON.stringify(payload, null, 2);
}

export function downloadStrategiesJson(json: string, filename: string): void {
  try {
    const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error('Failed to download JSON file', err);
  }
}

export function importStrategiesFromJson(
  jsonText: string,
  defaultGame?: GameType
): { valid: boolean; strategies: SavedStrategy[]; error?: string } {
  try {
    const text = jsonText.trim();
    if (!text) {
      return { valid: false, strategies: [], error: 'Teks JSON tidak boleh kosong.' };
    }

    const parsed = JSON.parse(text);
    let items: any[] = [];

    if (Array.isArray(parsed)) {
      items = parsed;
    } else if (parsed && typeof parsed === 'object') {
      if (Array.isArray(parsed.strategies)) {
        items = parsed.strategies;
      } else if (parsed.name && parsed.game) {
        items = [parsed];
      } else {
        return { valid: false, strategies: [], error: 'Format JSON tidak memiliki struktur strategi yang valid.' };
      }
    }

    if (items.length === 0) {
      return { valid: false, strategies: [], error: 'Tidak ditemukan data strategi dalam file JSON.' };
    }

    const validated: SavedStrategy[] = [];
    for (const item of items) {
      if (!item || typeof item !== 'object' || !item.name || typeof item.name !== 'string') {
        continue;
      }

      const g = (item.game || defaultGame || 'dice') as GameType;
      const now = Date.now();
      const base = {
        id: item.id && typeof item.id === 'string' ? item.id : `strat_import_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        name: String(item.name).trim(),
        game: g,
        createdAt: typeof item.createdAt === 'number' ? item.createdAt : now,
        updatedAt: now,
        betAmount: typeof item.betAmount === 'string' || typeof item.betAmount === 'number' ? String(item.betAmount) : '0',
        numberOfBets: typeof item.numberOfBets === 'string' || typeof item.numberOfBets === 'number' ? String(item.numberOfBets) : '0',
        onWinAction: (item.onWinAction === 'increase' ? 'increase' : 'reset') as 'reset' | 'increase',
        onWinPercent: typeof item.onWinPercent === 'string' || typeof item.onWinPercent === 'number' ? String(item.onWinPercent) : '0',
        onLossAction: (item.onLossAction === 'reset' ? 'reset' : 'increase') as 'reset' | 'increase',
        onLossPercent: typeof item.onLossPercent === 'string' || typeof item.onLossPercent === 'number' ? String(item.onLossPercent) : '0',
        stopProfit: typeof item.stopProfit === 'string' || typeof item.stopProfit === 'number' ? String(item.stopProfit) : '0',
        stopLoss: typeof item.stopLoss === 'string' || typeof item.stopLoss === 'number' ? String(item.stopLoss) : '0',
        maxBetCap: typeof item.maxBetCap === 'string' || typeof item.maxBetCap === 'number' ? String(item.maxBetCap) : '0',
        stopLoseStreak: typeof item.stopLoseStreak === 'string' || typeof item.stopLoseStreak === 'number' ? String(item.stopLoseStreak) : '0',
        stopWinStreak: typeof item.stopWinStreak === 'string' || typeof item.stopWinStreak === 'number' ? String(item.stopWinStreak) : '0',
        stopOnWin: typeof item.stopOnWin === 'boolean' ? item.stopOnWin : !!item.stopOnWin,
        stopOnLoss: typeof item.stopOnLoss === 'boolean' ? item.stopOnLoss : !!item.stopOnLoss,
        trailingStop: typeof item.trailingStop === 'string' || typeof item.trailingStop === 'number' ? String(item.trailingStop) : '0',
        stopWager: typeof item.stopWager === 'string' || typeof item.stopWager === 'number' ? String(item.stopWager) : '0',
        stopBalanceMin: typeof item.stopBalanceMin === 'string' || typeof item.stopBalanceMin === 'number' ? String(item.stopBalanceMin) : '0',
      };

      if (g === 'dice') {
        validated.push({
          ...base,
          game: 'dice',
          condition: item.condition === 'below' ? 'below' : 'above',
          target: typeof item.target === 'number' ? item.target : 50.5,
        });
      } else if (g === 'limbo') {
        validated.push({
          ...base,
          game: 'limbo',
          targetMultiplier: typeof item.targetMultiplier === 'number' ? item.targetMultiplier : 2,
        });
      } else if (g === 'plinko') {
        validated.push({
          ...base,
          game: 'plinko',
          risk: ['low', 'medium', 'high', 'expert'].includes(item.risk) ? item.risk : 'medium',
          rows: [8, 9, 10, 11, 12, 13, 14, 15, 16].includes(item.rows) ? item.rows : 16,
          stopHitMultiplier: typeof item.stopHitMultiplier === 'number' ? item.stopHitMultiplier : 0,
        });
      } else if (g === 'mines') {
        validated.push({
          ...base,
          game: 'mines',
          minesCount: typeof item.minesCount === 'number' ? Math.min(Math.max(1, item.minesCount), 24) : 3,
          autoFields: Array.isArray(item.autoFields) ? item.autoFields : [0, 1, 2],
        });
      } else if (g === 'diamonds') {
        validated.push({
          ...base,
          game: 'diamonds',
        });
      }
    }

    if (validated.length === 0) {
      return { valid: false, strategies: [], error: 'Semua item dalam JSON tidak memenuhi skema strategi yang valid.' };
    }

    return { valid: true, strategies: validated };
  } catch (err: any) {
    return { valid: false, strategies: [], error: `Gagal membaca format JSON: ${err.message || 'Syntax Error'}` };
  }
}
