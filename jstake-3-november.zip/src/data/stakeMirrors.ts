/**
 * Daftar Mirror Resmi Stake yang diambil langsung dari playstake.io/#mirrors
 * Terdiri dari domain mirror resmi, seri 1000, dan seri 3000.
 */

export interface StakeMirrorItem {
  domain: string;
  url: string;
  graphqlUrl: string;
  category: 'recommended' | 'official' | 'series1000' | 'series3000';
  label: string;
  notes?: string;
}

export const OFFICIAL_STAKE_MIRRORS: StakeMirrorItem[] = [
  // Rekomendasi & Populer
  {
    domain: 'stake.bet',
    url: 'https://stake.bet',
    graphqlUrl: 'https://stake.bet/_api/graphql',
    category: 'recommended',
    label: 'stake.bet (Mirror Utama)',
    notes: 'Mirror resmi global paling populer'
  },
  {
    domain: 'stake.games',
    url: 'https://stake.games',
    graphqlUrl: 'https://stake.games/_api/graphql',
    category: 'recommended',
    label: 'stake.games (Mirror Gaming)',
    notes: 'Mirror resmi khusus games'
  },
  {
    domain: 'stake.ac',
    url: 'https://stake.ac',
    graphqlUrl: 'https://stake.ac/_api/graphql',
    category: 'recommended',
    label: 'stake.ac',
    notes: 'Mirror resmi alternatif cepat'
  },
  {
    domain: 'stake.ceo',
    url: 'https://stake.ceo',
    graphqlUrl: 'https://stake.ceo/_api/graphql',
    category: 'recommended',
    label: 'stake.ceo',
    notes: 'Mirror resmi resmi Stake'
  },
  {
    domain: 'stake.com',
    url: 'https://stake.com',
    graphqlUrl: 'https://stake.com/_api/graphql',
    category: 'official',
    label: 'stake.com (Domain Pusat)',
    notes: 'Domain utama Stake'
  },
  {
    domain: 'stake.jp',
    url: 'https://stake.jp',
    graphqlUrl: 'https://stake.jp/_api/graphql',
    category: 'official',
    label: 'stake.jp (Mirror Asia/Jepang)',
    notes: 'Optimasi region Asia'
  },
  {
    domain: 'stake.mba',
    url: 'https://stake.mba',
    graphqlUrl: 'https://stake.mba/_api/graphql',
    category: 'official',
    label: 'stake.mba',
  },
  {
    domain: 'stake.bz',
    url: 'https://stake.bz',
    graphqlUrl: 'https://stake.bz/_api/graphql',
    category: 'official',
    label: 'stake.bz',
  },
  {
    domain: 'stake.pet',
    url: 'https://stake.pet',
    graphqlUrl: 'https://stake.pet/_api/graphql',
    category: 'official',
    label: 'stake.pet',
  },
  {
    domain: 'staketr.com',
    url: 'https://staketr.com',
    graphqlUrl: 'https://staketr.com/_api/graphql',
    category: 'official',
    label: 'staketr.com',
  },
  {
    domain: 'stkmirror.com',
    url: 'https://stkmirror.com',
    graphqlUrl: 'https://stkmirror.com/_api/graphql',
    category: 'official',
    label: 'stkmirror.com',
  },

  // Seri 1000
  {
    domain: 'stake1020.com',
    url: 'https://stake1020.com',
    graphqlUrl: 'https://stake1020.com/_api/graphql',
    category: 'series1000',
    label: 'stake1020.com',
  },
  {
    domain: 'stake1021.com',
    url: 'https://stake1021.com',
    graphqlUrl: 'https://stake1021.com/_api/graphql',
    category: 'series1000',
    label: 'stake1021.com',
  },
  {
    domain: 'stake1022.com',
    url: 'https://stake1022.com',
    graphqlUrl: 'https://stake1022.com/_api/graphql',
    category: 'series1000',
    label: 'stake1022.com',
  },
  {
    domain: 'stake1034.com',
    url: 'https://stake1034.com',
    graphqlUrl: 'https://stake1034.com/_api/graphql',
    category: 'series1000',
    label: 'stake1034.com',
  },
  {
    domain: 'stake1048.com',
    url: 'https://stake1048.com',
    graphqlUrl: 'https://stake1048.com/_api/graphql',
    category: 'series1000',
    label: 'stake1048.com',
  },
  {
    domain: 'stake1080.com',
    url: 'https://stake1080.com',
    graphqlUrl: 'https://stake1080.com/_api/graphql',
    category: 'series1000',
    label: 'stake1080.com',
  },

  // Seri 3000
  {
    domain: 'stake3000.com',
    url: 'https://stake3000.com',
    graphqlUrl: 'https://stake3000.com/_api/graphql',
    category: 'series3000',
    label: 'stake3000.com',
  },
  {
    domain: 'stake3001.com',
    url: 'https://stake3001.com',
    graphqlUrl: 'https://stake3001.com/_api/graphql',
    category: 'series3000',
    label: 'stake3001.com',
  },
  {
    domain: 'stake3010.com',
    url: 'https://stake3010.com',
    graphqlUrl: 'https://stake3010.com/_api/graphql',
    category: 'series3000',
    label: 'stake3010.com',
  },
  {
    domain: 'stake3020.com',
    url: 'https://stake3020.com',
    graphqlUrl: 'https://stake3020.com/_api/graphql',
    category: 'series3000',
    label: 'stake3020.com',
  },
  {
    domain: 'stake3083.com',
    url: 'https://stake3083.com',
    graphqlUrl: 'https://stake3083.com/_api/graphql',
    category: 'series3000',
    label: 'stake3083.com',
  },
  {
    domain: 'stake3099.com',
    url: 'https://stake3099.com',
    graphqlUrl: 'https://stake3099.com/_api/graphql',
    category: 'series3000',
    label: 'stake3099.com',
  },
];

export const DEFAULT_GRAPHQL_ENDPOINT = 'https://stake.bet/_api/graphql';
