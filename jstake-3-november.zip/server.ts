import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '2mb' }));

  // Active Stake Official GraphQL Mirrors
  const STAKE_MIRRORS = [
    'https://stake.bet/_api/graphql',
    'https://stake.games/_api/graphql',
    'https://stake.com/_api/graphql',
    'https://stake.icu/_api/graphql',
    'https://stk.bet/_api/graphql',
    'https://stake.ac/_api/graphql',
    'https://stake.jp/_api/graphql',
  ];

  // In-memory cache for fastest responding mirror
  let cachedFastestMirror: string | null = null;

  // Helper to fetch GraphQL from a single URL with tight 3.5s timeout
  async function fetchGraphQLFromTarget(
    targetUrl: string,
    query: string,
    variables: any,
    token?: string,
    cookie?: string,
    customHeaders?: Record<string, string>,
    userAgent?: string,
    timeoutMs = 3500
  ) {
    let origin = 'https://stake.bet';
    try {
      const parsed = new URL(targetUrl);
      origin = `${parsed.protocol}//${parsed.host}`;
    } catch {
      // fallback
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/plain, */*',
      'User-Agent':
        userAgent ||
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
      'Origin': origin,
      'Referer': `${origin}/`,
      'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'accept-language': 'en-US,en;q=0.9,id;q=0.8',
      ...(token ? { 'x-access-token': token.trim(), 'authorization': `Bearer ${token.trim()}` } : {}),
      ...(cookie ? { 'Cookie': cookie.trim() } : {}),
      ...(customHeaders || {}),
    };

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({ query, variables }),
        signal: controller.signal,
      });

      const responseText = await response.text();
      let data: any = null;
      try {
        data = JSON.parse(responseText);
      } catch {
        data = null;
      }

      return { response, responseText, data };
    } finally {
      clearTimeout(timer);
    }
  }

  // Helper to fetch direct REST endpoints from target URL with tight timeout
  async function fetchRestFromTarget(
    targetUrl: string,
    payload: any,
    method = 'POST',
    token?: string,
    cookie?: string,
    customHeaders?: Record<string, string>,
    userAgent?: string,
    timeoutMs = 4000
  ) {
    let origin = 'https://stake.com';
    try {
      const parsed = new URL(targetUrl);
      origin = `${parsed.protocol}//${parsed.host}`;
    } catch {
      // fallback
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/plain, */*',
      'User-Agent':
        userAgent ||
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
      'Origin': origin,
      'Referer': `${origin}/`,
      'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'accept-language': 'en-US,en;q=0.9,id;q=0.8',
      ...(token ? { 'x-access-token': token.trim(), 'authorization': `Bearer ${token.trim()}` } : {}),
      ...(cookie ? { 'Cookie': cookie.trim() } : {}),
      ...(customHeaders || {}),
    };

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(targetUrl, {
        method,
        headers,
        body: payload !== undefined && method !== 'GET' ? JSON.stringify(payload) : undefined,
        signal: controller.signal,
      });

      const responseText = await response.text();
      let data: any = null;
      try {
        data = JSON.parse(responseText);
      } catch {
        data = { rawText: responseText };
      }

      return { response, responseText, data };
    } finally {
      clearTimeout(timer);
    }
  }

  // Stake Direct REST Bet & Proxy Endpoints (/api/bet, /api/proxy-stake, /api/stake-rest)
  app.post(['/api/bet', '/api/proxy-stake', '/api/stake-rest'], async (req, res) => {
    try {
      const headerToken = (req.headers['x-access-token'] as string) || (req.headers['authorization'] ? (req.headers['authorization'] as string).replace(/^Bearer\s+/i, '') : '');
      const token = (headerToken || req.body?.token || '').trim();
      const cookie = ((req.headers['x-stake-cookie'] as string) || req.body?.cookie || '').trim();
      const userAgent = (req.headers['user-agent'] as string) || req.body?.userAgent;

      const { endpoint, url, method = 'POST', payload, body, startCard, amount, currency, identifier, customHeaders } = req.body || {};

      // If body itself is the direct bet payload: { amount, currency, identifier, startCard }
      let actualPayload = payload !== undefined ? payload : body;
      if (!actualPayload && (amount !== undefined || identifier !== undefined || startCard !== undefined)) {
        actualPayload = {
          amount: amount ?? 0,
          currency: currency ?? 'usdt',
          identifier: identifier,
          startCard: startCard,
        };
      }

      const targetPath = url || endpoint || '/_api/bet';
      let primaryHost = 'https://stake.com';
      try {
        if (targetPath.startsWith('http')) {
          const parsed = new URL(targetPath);
          primaryHost = `${parsed.protocol}//${parsed.host}`;
        }
      } catch {}

      const candidateUrls = [
        targetPath.startsWith('http') ? targetPath : `${primaryHost}${targetPath.startsWith('/') ? targetPath : '/' + targetPath}`,
        'https://stake.com/_api/bet',
        'https://stake.bet/_api/bet',
        'https://stake.games/_api/bet',
        'https://stake.icu/_api/bet',
        'https://stk.bet/_api/bet',
      ];
      const uniqueUrls = Array.from(new Set(candidateUrls));

      for (const curUrl of uniqueUrls) {
        try {
          const { response, data } = await fetchRestFromTarget(
            curUrl,
            actualPayload,
            method,
            token,
            cookie,
            customHeaders,
            userAgent,
            3500
          );

          if (response.ok && data && !data.rawText) {
            return res.json({ ...data, usedUrl: curUrl });
          }
          if (data && !data.rawText && (data.id || data.bet || data.state || data.amount !== undefined)) {
            return res.json({ ...data, usedUrl: curUrl });
          }
          if (data && !data.rawText && (data.error || data.message || data.errors)) {
            return res.status(response.status >= 400 ? response.status : 400).json(data);
          }
        } catch {
          // try next candidate
        }
      }

      // If direct requests to mirrors encounter network/cloudflare blocking, try public CORS relays
      const publicRelays = [
        `https://corsproxy.io/?url=${encodeURIComponent('https://stake.com/_api/bet')}`,
        `https://api.allorigins.win/raw?url=${encodeURIComponent('https://stake.com/_api/bet')}`,
      ];

      for (const pUrl of publicRelays) {
        try {
          const proxyRes = await fetchRestFromTarget(pUrl, actualPayload, method, token, cookie, customHeaders, userAgent, 4500);
          if (proxyRes.data && !proxyRes.data.rawText && (proxyRes.data.id || proxyRes.data.state || proxyRes.data.bet || !proxyRes.data.error)) {
            return res.json(proxyRes.data);
          }
        } catch {}
      }

      return res.status(502).json({
        error: 'Gagal menghubungi server Stake',
        message: 'Endpoint Stake tidak merespon atau token sesi tidak valid.',
      });
    } catch (err: any) {
      return res.status(502).json({
        error: 'Proxy Connection Error',
        message: err.message || 'Gagal menghubungi server proxy backend',
      });
    }
  });

  // Stake GraphQL Proxy Endpoint with Ultra-Fast Parallel Mirror Racing
  app.post('/api/stake-graphql', async (req, res) => {
    try {
      const { endpoint, query, variables, token, cookie, customHeaders, userAgent } = req.body;
      const primaryUrl = endpoint || cachedFastestMirror || 'https://stake.bet/_api/graphql';

      // 1. If we have a cached fastest mirror, test it first with tight timeout
      if (cachedFastestMirror) {
        try {
          const { response, data } = await fetchGraphQLFromTarget(
            cachedFastestMirror,
            query,
            variables,
            token,
            cookie,
            customHeaders,
            userAgent,
            3000
          );
          if (response.ok && data && (data.data || !data.errors)) {
            return res.json({ ...data, usedEndpoint: cachedFastestMirror });
          }
          if (data && Array.isArray(data.errors) && data.errors.length > 0) {
            return res.json({ ...data, usedEndpoint: cachedFastestMirror });
          }
        } catch {
          cachedFastestMirror = null; // Invalidate cache on failure
        }
      }

      // 2. Parallel Race across all mirrors for sub-300ms speed
      const candidateMirrors = Array.from(new Set([primaryUrl, ...STAKE_MIRRORS]));

      const racePromises = candidateMirrors.map(async (targetUrl) => {
        try {
          const { response, data } = await fetchGraphQLFromTarget(
            targetUrl,
            query,
            variables,
            token,
            cookie,
            customHeaders,
            userAgent,
            3500
          );

          if (response.ok && data && (data.data || !data.errors)) {
            cachedFastestMirror = targetUrl; // Cache winning mirror for instant subsequent bets
            return { data, usedEndpoint: targetUrl };
          }

          if (data && Array.isArray(data.errors) && data.errors.length > 0) {
            return { data, usedEndpoint: targetUrl };
          }
          throw new Error(`Mirror ${targetUrl} failed with status ${response.status}`);
        } catch (err: any) {
          throw new Error(`Mirror ${targetUrl} error: ${err.message}`);
        }
      });

      try {
        const winningData = await Promise.any(racePromises);
        if (winningData.data) {
          return res.json(winningData.data);
        }
      } catch {
        // Parallel direct fetch race failed, fallback to public CORS relays
      }

      // 3. Fallback: Fast Public CORS Proxy Relays
      const publicProxies = [
        `https://corsproxy.io/?url=${encodeURIComponent(primaryUrl)}`,
        `https://api.allorigins.win/raw?url=${encodeURIComponent(primaryUrl)}`,
      ];

      const proxyPromises = publicProxies.map(async (proxyUrl) => {
        const proxyRes = await fetchGraphQLFromTarget(proxyUrl, query, variables, token, cookie, customHeaders, userAgent, 4000);
        if (proxyRes.data && (proxyRes.data.data || proxyRes.data.errors)) {
          return proxyRes.data;
        }
        throw new Error('Proxy failed');
      });

      try {
        const winningProxyData = await Promise.any(proxyPromises);
        return res.json(winningProxyData);
      } catch {
        // All options failed
      }

      return res.status(403).json({
        error: 'Gagal menghubungkan ke Stake',
        message: 'Stake Session Token Anda tidak valid atau ter-logout. Silakan ambil token baru di stake.com / stake.bet.',
      });
    } catch (err: any) {
      return res.status(502).json({
        error: 'Proxy Connection Error',
        message: err.message || 'Gagal menghubungi endpoint Stake dari server proxy',
      });
    }
  });

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Stake Minimal Client Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
